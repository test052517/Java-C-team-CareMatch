
package DAO;

import DB.DBConnect;
import DTO.VisitReservationDTO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 기능 수정만 반영:
 * - created_at이 아니라 visit_date를 정확히 매핑
 * - userId + (animal_name OR animal_id)로 최근 예약 1건 조회
 * - 상태 업데이트/목록 조회/추가 포함
 * - 디자인(UI)에는 일절 손대지 않음
 */
public class VisitReservationDAO {

    /** 최신 예약 1건 조회 (userId + animalKey) */
    public VisitReservationDTO findLatestByUserAndAnimalLoose(int userId, String animalKey) throws SQLException {
        final String sql =
                "SELECT vr.* " +
                "FROM visit_reservations vr " +
                "LEFT JOIN animals a ON a.animal_name = vr.animal_name " +
                "WHERE vr.user_id = ? " +
                "  AND (vr.animal_name = ? OR a.animal_id = ?) " +
                "ORDER BY vr.created_at DESC " +
                "LIMIT 1";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setString(2, animalKey);
            ps.setString(3, animalKey);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs); // ✅ visit_date 매핑
            }
        }
        return null;
    }

    /** 사용자 전체 예약 목록 (최신순) */
    public List<VisitReservationDTO> findReservationsByUserId(int userId) throws SQLException {
        final String sql = "SELECT * FROM visit_reservations WHERE user_id = ? ORDER BY created_at DESC";
        List<VisitReservationDTO> list = new ArrayList<>();
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    /** 상태값 업데이트 (승인/거절 등) */
    public boolean updateStatus(int reservationId, String status) throws SQLException {
        final String sql = "UPDATE visit_reservations SET status = ? WHERE reservation_id = ?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, reservationId);
            return ps.executeUpdate() > 0;
        }
    }

    /** 예약 추가 (필요시 사용) */
    public boolean addReservation(VisitReservationDTO v) throws SQLException {
        final String sql = "INSERT INTO visit_reservations " +
                "(user_id, animal_name, visit_date, visit_time, contact, reason, status, created_at) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, safeInt(get(v, "getUserId")));
            ps.setString(2, safeString(get(v, "getAnimalName")));
            ps.setDate(3, toSqlDate(get(v, "getVisitDate")));   // ✅ 핵심
            ps.setString(4, safeString(get(v, "getVisitTime")));
            ps.setString(5, safeString(get(v, "getContact")));
            ps.setString(6, safeString(get(v, "getReason")));
            ps.setString(7, safeString(get(v, "getStatus")));
            return ps.executeUpdate() > 0;
        }
    }

    // ------------------------- 내부 유틸 -------------------------

    private static VisitReservationDTO mapRow(ResultSet rs) throws SQLException {
        VisitReservationDTO dto = new VisitReservationDTO();
        call(dto, "setReservationId", rs.getInt("reservation_id"));
        call(dto, "setUserId", rs.getInt("user_id"));
        call(dto, "setAnimalName", rs.getString("animal_name"));
        call(dto, "setVisitDate", rs.getDate("visit_date"));   // ✅ visit_date 매핑
        call(dto, "setVisitTime", rs.getString("visit_time"));
        call(dto, "setContact", rs.getString("contact"));
        call(dto, "setReason", rs.getString("reason"));
        call(dto, "setStatus", rs.getString("status"));
        // 필요하면 created_at도 매핑 가능
        // call(dto, "setCreatedAt", rs.getTimestamp("created_at"));
        return dto;
    }

    private static void call(Object o, String method, Object arg) {
        try {
            if (arg == null) {
                for (var m : o.getClass().getMethods()) {
                    if (m.getName().equals(method) && m.getParameterCount() == 1) {
                        m.invoke(o, new Object[]{null});
                        return;
                    }
                }
                return;
            }
            if (arg instanceof java.sql.Date) {
                try {
                    o.getClass().getMethod(method, java.sql.Date.class).invoke(o, arg);
                    return;
                } catch (NoSuchMethodException ignore) {}
            }
            if (arg instanceof java.sql.Timestamp) {
                try {
                    o.getClass().getMethod(method, java.sql.Timestamp.class).invoke(o, arg);
                    return;
                } catch (NoSuchMethodException ignore) {}
            }
            for (var m : o.getClass().getMethods()) {
                if (m.getName().equals(method) && m.getParameterCount() == 1) {
                    try { m.invoke(o, arg); return; }
                    catch (IllegalArgumentException ignore) {}
                }
            }
        } catch (Exception ignore) {}
    }

    private static Object get(Object o, String getter) {
        try { return o.getClass().getMethod(getter).invoke(o); }
        catch (Exception e) { return null; }
    }

    private static int safeInt(Object o) { return (o instanceof Number) ? ((Number) o).intValue() : 0; }
    private static String safeString(Object o) { return o != null ? String.valueOf(o) : null; }

    private static java.sql.Date toSqlDate(Object o) {
        if (o == null) return null;
        if (o instanceof java.sql.Date d) return d;
        if (o instanceof java.util.Date d) return new java.sql.Date(d.getTime());
        if (o instanceof java.time.LocalDate ld) return java.sql.Date.valueOf(ld);
        return null;
    }
}
