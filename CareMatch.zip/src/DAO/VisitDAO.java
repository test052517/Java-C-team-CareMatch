package DAO;

import DTO.VisitDTO;
import DB.DBConnect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VisitDAO {

    /**
     * 새로운 방문 기록을 추가합니다. (visit_id는 DB에서 자동 생성)
     * @param visit 추가할 방문 정보가 담긴 VisitDTO 객체
     * @return 추가 성공 시 true, 실패 시 false
     */
    public boolean addVisit(VisitDTO visit) {
        String sql = "INSERT INTO visit (purpose, status, visit_date, submitted_date, user_id, animal_id, application_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, visit.getPurpose());
            pstmt.setString(2, visit.getStatus());
            pstmt.setDate(3, visit.getVisitDate());
            pstmt.setDate(4, visit.getSubmittedDate());
            pstmt.setInt(5, visit.getUserId());
            pstmt.setString(6, visit.getAnimalId());
            pstmt.setInt(7, visit.getApplicationId());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("방문 기록 추가 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * visit_id를 기준으로 특정 방문 기록을 조회합니다. (기능 통합)
     * @param visitId 조회할 방문의 ID
     * @return 조회된 VisitDTO 객체, 없을 경우 null
     */
    public VisitDTO findVisitById(int visitId) {
        String sql = "SELECT * FROM visit WHERE visit_id = ?";
        return getVisitFromQuery(sql, visitId);
    }

    /**
     * application_id를 기준으로 특정 방문 기록을 조회합니다.
     * @param applicationId 조회할 신청의 ID
     * @return 조회된 VisitDTO 객체, 없을 경우 null
     */
    public VisitDTO findVisitByApplicationId(int applicationId) {
        String sql = "SELECT * FROM visit WHERE application_id = ?";
        return getVisitFromQuery(sql, applicationId);
    }

    // 공통 조회 헬퍼 메서드
    private VisitDTO getVisitFromQuery(String sql, int id) {
        VisitDTO visit = null;
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    visit = new VisitDTO();
                    visit.setVisitId(rs.getInt("visit_id"));
                    visit.setPurpose(rs.getString("purpose"));
                    visit.setStatus(rs.getString("status"));
                    visit.setVisitDate(rs.getDate("visit_date"));
                    visit.setSubmittedDate(rs.getDate("submitted_date"));
                    visit.setUserId(rs.getInt("user_id"));
                    visit.setAnimalId(rs.getString("animal_id"));
                    visit.setApplicationId(rs.getInt("application_id"));
                }
            }
        } catch (SQLException e) {
            System.err.println("방문 기록 조회 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
        }
        return visit;
    }
    
    /**
     * 특정 사용자의 모든 방문 기록 목록을 조회합니다.
     * @param userId 조회할 사용자의 ID
     * @return 해당 사용자의 VisitDTO 리스트
     */
    public List<VisitDTO> findVisitsByUserId(int userId) {
        String sql = "SELECT * FROM visit WHERE user_id = ? ORDER BY visit_date DESC";
        List<VisitDTO> visits = new ArrayList<>();
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, userId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    VisitDTO visit = new VisitDTO();
                    visit.setVisitId(rs.getInt("visit_id"));
                    visit.setPurpose(rs.getString("purpose"));
                    visit.setStatus(rs.getString("status"));
                    visit.setVisitDate(rs.getDate("visit_date"));
                    visit.setSubmittedDate(rs.getDate("submitted_date"));
                    visit.setUserId(rs.getInt("user_id"));
                    visit.setAnimalId(rs.getString("animal_id"));
                    visit.setApplicationId(rs.getInt("application_id"));
                    visits.add(visit);
                }
            }
        } catch (SQLException e) {
            System.err.println("사용자 ID로 방문 기록 목록 조회 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
        }
        return visits;
    }
    
    /**
     * 방문 기록의 상태를 수정합니다.
     * @param visitId 상태를 수정할 방문의 ID
     * @param newStatus 새로운 상태 값
     * @return 수정 성공 시 true, 실패 시 false
     */
    public boolean updateVisitStatus(int visitId, String newStatus) {
        String sql = "UPDATE visit SET status = ? WHERE visit_id = ?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, newStatus);
            pstmt.setInt(2, visitId);
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("방문 기록 상태 수정 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 특정 방문 기록을 삭제합니다.
     * @param visitId 삭제할 방문의 ID
     * @return 삭제 성공 시 true, 실패 시 false
     */
    public boolean deleteVisit(int visitId) {
        String sql = "DELETE FROM visit WHERE visit_id = ?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, visitId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("방문 기록 삭제 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}