package DAO;

import DB.DBConnect;
import DTO.ReviewImageDTO;

import java.sql.*;

public class ReviewImageDAO {
    public boolean save(ReviewImageDTO dto) {
        String sql = "INSERT INTO review_image (review_image_id, review_id, file_name, mime_type, image_data) VALUES (?,?,?,?,?)";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, dto.getReviewImageId());
            ps.setString(2, dto.getReviewId());
            ps.setString(3, dto.getFileName());
            ps.setString(4, dto.getMimeType());
            ps.setBytes(5, dto.getImageData());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public ReviewImageDTO findByReviewId(String reviewId) {
        String sql = "SELECT review_image_id, review_id, file_name, mime_type, image_data FROM review_image WHERE review_id=? ORDER BY created_at DESC LIMIT 1";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, reviewId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    ReviewImageDTO d = new ReviewImageDTO();
                    d.setReviewImageId(rs.getString(1));
                    d.setReviewId(rs.getString(2));
                    d.setFileName(rs.getString(3));
                    d.setMimeType(rs.getString(4));
                    d.setImageData(rs.getBytes(5));
                    return d;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
