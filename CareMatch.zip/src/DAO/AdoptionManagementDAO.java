package DAO;

import DB.DBConnect;
import DTO.AnimalsDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 입양 관리와 관련된 복합적인 데이터베이스 작업을 처리하는 DAO 클래스입니다.
 * (예: 여러 테이블을 조인하는 조회)
 */
public class AdoptionManagementDAO {

    /**
     * 현재 입양 신청이 없는 '보호중' 상태인 동물들의 목록을 조회합니다.
     * Adoption 테이블에 해당 animal_id가 없는 동물을 찾습니다.
     *
     * @return 입양 가능한 동물의 DTO 리스트
     */
    public List<AnimalsDTO> findAdoptableAnimals() {
        // SQL 쿼리: Animals 테이블을 기준으로 Adoption 테이블에 존재하지 않는 동물을 찾습니다.
        // LEFT JOIN을 사용하여 Animals 테이블의 모든 '보호중' 동물을 포함하고,
        // Adoption 테이블에 일치하는 animal_id가 없는 (ad.application_id IS NULL) 동물만 선택합니다.
        String sql = "SELECT an.* FROM Animals an " +
                     "LEFT JOIN Adoption ad ON an.animal_id = ad.animal_id " +
                     "WHERE an.status = '보호중' AND ad.application_id IS NULL";

        List<AnimalsDTO> adoptableAnimals = new ArrayList<>();

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                AnimalsDTO animal = new AnimalsDTO();
                animal.setAnimalId(rs.getString("animal_id"));
                animal.setAge(rs.getInt("age"));
                animal.setWeight(rs.getDouble("weight"));
                animal.setSex(rs.getString("sex"));
                animal.setNeutered(rs.getString("neutered"));
                animal.setHappenDate(rs.getDate("happenDate"));
                animal.setKindId(rs.getString("kind_id"));
                animal.setShelterId(rs.getString("shelter_id"));
                animal.setStatus(rs.getString("status"));
                animal.setImageId(rs.getString("image_id"));
                animal.setAnimalName(rs.getString("animal_name"));
                adoptableAnimals.add(animal);
            }
        } catch (SQLException e) {
            System.err.println("입양 가능 동물 목록 조회 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
        }
        System.out.println("[DEBUG] AdoptionManagementDAO: " + adoptableAnimals.size() + "마리의 입양 가능한 동물을 조회했습니다.");
        return adoptableAnimals;
    }

    /**
     * 입양 신청을 승인하는 트랜잭션 메서드입니다.
     * 1. Adoption 테이블의 상태를 '승인'으로 변경합니다.
     * 2. Animals 테이블의 상태를 '입양 완료'로 변경합니다.
     * @param applicationId 승인할 입양 신청 ID
     * @param animalId 입양될 동물의 ID
     * @return 모든 작업이 성공하면 true, 하나라도 실패하면 false
     */
    public boolean approveAdoption(int applicationId, String animalId) {
        Connection conn = null;
        try {
            conn = DBConnect.getConnection();
            conn.setAutoCommit(false); // 트랜잭션 시작 (자동 커밋 비활성화)

            AdoptionDAO adoptionDAO = new AdoptionDAO();
            AnimalsDAO animalsDAO = new AnimalsDAO();

            // 1. 입양 신청 상태 '승인'으로 변경
            boolean adoptionUpdated = adoptionDAO.updateAdoptionStatus(applicationId, "승인", conn);
            
            // 2. 동물 상태 '입양 완료'로 변경
            boolean animalUpdated = animalsDAO.updateAnimalStatus(animalId, "종료(입양)", conn);

            // 두 작업이 모두 성공했을 때만 최종 반영 (commit)
            if (adoptionUpdated && animalUpdated) {
                conn.commit();
                return true;
            } else {
                conn.rollback(); // 하나라도 실패하면 모든 작업 되돌리기 (rollback)
                return false;
            }
        } catch (SQLException e) {
            System.err.println("입양 승인 트랜잭션 중 오류 발생");
            if (conn != null) {
                try {
                    conn.rollback(); // 예외 발생 시 롤백
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            e.printStackTrace();
            return false;
        } finally {
            // 트랜잭션 종료 후 리소스 정리
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 입양 신청을 거절하는 트랜잭션 메서드입니다.
     * 1. Adoption 테이블의 상태를 '거절'로 변경합니다.
     * 2. Animals 테이블의 상태를 '보호중'으로 되돌립니다.
     * @param applicationId 거절할 입양 신청 ID
     * @param animalId 보호 상태로 되돌릴 동물의 ID
     * @return 모든 작업이 성공하면 true, 하나라도 실패하면 false
     */
    public boolean rejectAdoption(int applicationId, String animalId) {
        Connection conn = null;
        try {
            conn = DBConnect.getConnection();
            conn.setAutoCommit(false);

            AdoptionDAO adoptionDAO = new AdoptionDAO();
            AnimalsDAO animalsDAO = new AnimalsDAO();

            boolean adoptionUpdated = adoptionDAO.updateAdoptionStatus(applicationId, "거절", conn);
            boolean animalUpdated = animalsDAO.updateAnimalStatus(animalId, "보호중", conn);

            if (adoptionUpdated && animalUpdated) {
                conn.commit();
                return true;
            } else {
                conn.rollback();
                return false;
            }
        } catch (SQLException e) {
            System.err.println("입양 거절 트랜잭션 중 오류 발생");
            if (conn != null) { try { conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); } }
            e.printStackTrace();
            return false;
        } finally {
            if (conn != null) { try { conn.setAutoCommit(true); conn.close(); } catch (SQLException e) { e.printStackTrace(); } }
        }
    }
}