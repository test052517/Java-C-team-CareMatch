package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import DTO.ImageDTO;
import DB.DBConnect;

public class ImageDAO {

    // 기존 메서드 (변경 없음)
    public boolean addImage(ImageDTO image) {
        String sql = "INSERT INTO Image (image_id, image_url, image_data) VALUES (?, ?, ?)";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, image.getImageId());
            pstmt.setString(2, image.getImageUrl());
            pstmt.setBytes(3, image.getImageData());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 트랜잭션용으로 추가된 메서드
    public boolean addImage(ImageDTO image, Connection conn) throws SQLException {
        String sql = "INSERT INTO Image (image_id, image_url, image_data) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, image.getImageId());
            pstmt.setString(2, image.getImageUrl());
            pstmt.setBytes(3, image.getImageData());
            return pstmt.executeUpdate() > 0;
        }
    }

    // findImageById, deleteImage 메서드는 기존과 동일
    public ImageDTO findImageById(String imageId) {
        String sql = "SELECT * FROM Image WHERE image_id = ?";
        ImageDTO image = null;
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, imageId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    image = new ImageDTO();
                    image.setImageId(rs.getString("image_id"));
                    image.setImageUrl(rs.getString("image_url"));
                    image.setImageData(rs.getBytes("image_data"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return image;
    }

    public boolean deleteImage(String imageId) {
        String sql = "DELETE FROM Image WHERE image_id = ?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, imageId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}