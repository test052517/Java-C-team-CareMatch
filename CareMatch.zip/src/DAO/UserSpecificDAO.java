package DAO;

import DB.DBConnect;
import DTO.UserSpecificDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserSpecificDAO {

    // userId로 사용자 상세 정보 조회
    public UserSpecificDTO findUserByUserId(int userId) {
        String sql = "SELECT * FROM userspecific WHERE userid = ?";
        UserSpecificDTO userSpecific = null;

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    userSpecific = new UserSpecificDTO(
                        rs.getString("phone"),
                        rs.getString("name"),
                        rs.getString("e_mail"),
                        rs.getInt("userid")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userSpecific;
    }

    public boolean addUser(UserSpecificDTO user) {
        String sql = "INSERT INTO userspecific (phone, name, e_mail, userid) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, user.getPhone());
            pstmt.setString(2, user.getName());
            pstmt.setString(3, user.getEmail());
            pstmt.setInt(4, user.getUserId());
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updatePhone(int userId, String newPhone) {
        String sql = "UPDATE userspecific SET phone = ? WHERE userid = ?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, newPhone);
            pstmt.setInt(2, userId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateEmail(int userId, String newEmail) {
        String sql = "UPDATE userspecific SET e_mail = ? WHERE userid = ?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, newEmail);
            pstmt.setInt(2, userId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}