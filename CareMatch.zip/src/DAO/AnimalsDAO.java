package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import DTO.AnimalsDTO;
import DTO.SpeciesDTO;
import DB.DBConnect;

public class AnimalsDAO {

    // 수정된 addAnimal 메서드
    public boolean addAnimal(AnimalsDTO animal) {
        String sql;
        boolean hasApplicantId = (animal.getApplicantId() != 0);

        if (hasApplicantId) {
            sql = "INSERT INTO Animals (animal_id, age, weight, sex, neutered, happenDate, kind_id, shelter_id, status, image_id, animal_name, applicant_id) " +
                  "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        } else {
            sql = "INSERT INTO Animals (animal_id, age, weight, sex, neutered, happenDate, kind_id, shelter_id, status, image_id, animal_name) " +
                  "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        }

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, animal.getAnimalId());
            pstmt.setInt(2, animal.getAge());
            pstmt.setDouble(3, animal.getWeight());
            pstmt.setString(4, animal.getSex());
            pstmt.setString(5, animal.getNeutered());
            pstmt.setDate(6, animal.getHappenDate());
            pstmt.setString(7, animal.getKindId());
            pstmt.setString(8, animal.getShelterId());
            pstmt.setString(9, animal.getStatus());
            pstmt.setString(10, animal.getImageId());
            pstmt.setString(11, animal.getAnimalName());

            if (hasApplicantId) {
                pstmt.setInt(12, animal.getApplicantId());
            }

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("동물 정보 추가 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    // 트랜잭션용으로 수정된 addAnimal 메서드
    public boolean addAnimal(AnimalsDTO animal, Connection conn) throws SQLException {
        String sql;
        boolean hasApplicantId = (animal.getApplicantId() != 0);

        if (hasApplicantId) {
            sql = "INSERT INTO Animals (animal_id, age, weight, sex, neutered, happenDate, kind_id, shelter_id, status, image_id, animal_name, applicant_id) " +
                  "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        } else {
            sql = "INSERT INTO Animals (animal_id, age, weight, sex, neutered, happenDate, kind_id, shelter_id, status, image_id, animal_name) " +
                  "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        }

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, animal.getAnimalId());
            pstmt.setInt(2, animal.getAge());
            pstmt.setDouble(3, animal.getWeight());
            pstmt.setString(4, animal.getSex());
            pstmt.setString(5, animal.getNeutered());
            pstmt.setDate(6, animal.getHappenDate());
            pstmt.setString(7, animal.getKindId());
            pstmt.setString(8, animal.getShelterId());
            pstmt.setString(9, animal.getStatus());
            pstmt.setString(10, animal.getImageId());
            pstmt.setString(11, animal.getAnimalName());

            if (hasApplicantId) {
                pstmt.setInt(12, animal.getApplicantId());
            }

            return pstmt.executeUpdate() > 0;
        }
    }

    // find, update, delete 등 나머지 메서드는 기존과 동일
    public AnimalsDTO findAnimalById(String animalId) {
        String sql = "SELECT a.*, s.type_name, s.kind_name " +
                     "FROM Animals a " +
                     "JOIN Species s ON a.kind_id = s.kind_id " +
                     "WHERE a.animal_id = ?";

        AnimalsDTO animal = null;
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, animalId);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    animal = mapResultSetToAnimal(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("동물 정보 조회 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
        }
        return animal;
    }

    public List<AnimalsDTO> findAllAnimals() {
        String sql = "SELECT a.*, s.type_name, s.kind_name " +
                     "FROM Animals a " +
                     "JOIN Species s ON a.kind_id = s.kind_id";

        List<AnimalsDTO> animalList = new ArrayList<>();
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                AnimalsDTO animal = mapResultSetToAnimal(rs);
                animalList.add(animal);
            }
        } catch (SQLException e) {
            System.err.println("전체 동물 목록 조회 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
        }
        return animalList;
    }

    public boolean updateAnimal(AnimalsDTO animal) {
        String sql = "UPDATE Animals SET age = ?, weight = ?, sex = ?, neutered = ?, happenDate = ?, kind_id = ?, shelter_id = ?, status = ?, image_id = ?, animal_name = ?, applicant_id = ? " +
                     "WHERE animal_id = ?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, animal.getAge());
            pstmt.setDouble(2, animal.getWeight());
            pstmt.setString(3, animal.getSex());
            pstmt.setString(4, animal.getNeutered());
            pstmt.setDate(5, animal.getHappenDate());
            pstmt.setString(6, animal.getKindId());
            pstmt.setString(7, animal.getShelterId());
            pstmt.setString(8, animal.getStatus());
            pstmt.setString(9, animal.getImageId());
            pstmt.setString(10, animal.getAnimalName());
            pstmt.setInt(11, animal.getApplicantId());
            pstmt.setString(12, animal.getAnimalId());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("동물 정보 수정 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteAnimal(String animalId) {
        String sql = "DELETE FROM Animals WHERE animal_id = ?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, animalId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("동물 정보 삭제 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateAnimalStatus(String animalId, String newStatus) {
        String sql = "UPDATE Animals SET status = ? WHERE animal_id = ?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, newStatus);
            pstmt.setString(2, animalId);

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("동물 상태 정보 수정 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 트랜잭션 제어를 위해 외부 Connection 객체를 사용하여 동물 상태를 업데이트합니다.
     * @param animalId 상태를 변경할 동물의 ID
     * @param newStatus 새로운 상태 값
     * @param conn 외부에서 관리하는 데이터베이스 Connection 객체
     * @return 업데이트 성공 시 true
     * @throws SQLException SQL 처리 중 예외 발생 시
     */
    public boolean updateAnimalStatus(String animalId, String newStatus, Connection conn) throws SQLException {
        String sql = "UPDATE Animals SET status = ? WHERE animal_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newStatus);
            pstmt.setString(2, animalId);
            return pstmt.executeUpdate() > 0;
        }
    }

    public boolean applyForAnimal(String animalId, int userId) {
        String sql = "UPDATE Animals SET applicant_id = ?, status = 'ON_HOLD' WHERE animal_id = ?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, userId);
            pstmt.setString(2, animalId);

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("동물 신청 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public List<AnimalsDTO> findAllAnimalsByUser(int userId) {
        String sql = "SELECT a.*, s.type_name, s.kind_name " +
                     "FROM Animals a " +
                     "JOIN Species s ON a.kind_id = s.kind_id " +
                     "WHERE a.applicant_id = ? AND a.status = 'ON_HOLD'";
        List<AnimalsDTO> animalList = new ArrayList<>();

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, userId);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    AnimalsDTO animal = mapResultSetToAnimal(rs);
                    animalList.add(animal);
                }
            }
        } catch (SQLException e) {
            System.err.println("사용자별 ON_HOLD 동물 조회 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
        }
        return animalList;
    }

    private AnimalsDTO mapResultSetToAnimal(ResultSet rs) throws SQLException {
        AnimalsDTO animal = new AnimalsDTO();
        animal.setAnimalId(rs.getString("animal_id"));
        animal.setAge(rs.getInt("age"));
        animal.setWeight(rs.getDouble("weight"));
        animal.setSex(rs.getString("sex"));
        animal.setNeutered(rs.getString("neutered"));
        animal.setHappenDate(rs.getDate("happenDate"));
        animal.setKindId(rs.getString("kind_id"));
        animal.setShelterId(rs.getString("shelter_id"));
        animal.setStatus(rs.getString("status"));
        animal.setImageId(rs.getString("image_id"));
        animal.setAnimalName(rs.getString("animal_name"));
        animal.setApplicantId(rs.getInt("applicant_id"));

        SpeciesDTO species = new SpeciesDTO();
        species.setTypeName(rs.getString("type_name"));
        species.setKindName(rs.getString("kind_name"));
        animal.setSpeciesDTO(species);

        return animal;
    }

    public Map<String, Integer> getStatusCountsForYear(int year) {
        Map<String, Integer> statusCounts = new HashMap<>();
        String sql = "SELECT status, COUNT(*) as count FROM Animals WHERE YEAR(happenDate) = ? GROUP BY status";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, year);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                statusCounts.put(rs.getString("status"), rs.getInt("count"));
            }
        } catch (SQLException e) {
            System.err.println("상태별 통계 조회 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
        }
        return statusCounts;
    }

    public Map<Integer, Integer> getYearlyIntakeStats(int year) {
        Map<Integer, Integer> monthlyIntake = new HashMap<>();
        String sql = "SELECT MONTH(happenDate) as month, COUNT(*) as count FROM Animals WHERE YEAR(happenDate) = ? GROUP BY MONTH(happenDate)";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, year);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                monthlyIntake.put(rs.getInt("month"), rs.getInt("count"));
            }
        } catch (SQLException e) {
            System.err.println("연간 입소 통계 조회 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
        }
        return monthlyIntake;
    }


/** 
 * 동물 이름(예: "동물0576")으로 animals 테이블에서 한 건 조회
 * adoption.animal_id가 이름을 저장하는 경우(=ID가 아닌 케이스)를 위해 사용
 */



/** 
 * 동물 이름(예: "동물0576")으로 animals 테이블에서 조회
 */
public AnimalsDTO findAnimalByName(String animalName) {
    String sql = "SELECT * FROM animals WHERE animal_name = ? LIMIT 1";
    try (java.sql.Connection conn = DBConnect.getConnection();
         java.sql.PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, animalName);
        try (java.sql.ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                return mapResultSetToAnimal(rs);
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return null;
}

}