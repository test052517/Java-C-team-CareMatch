package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import DTO.UserDTO;
import DB.DBConnect;

public class UserDAO {

    /**
     * 아이디가 이미 존재하는지 확인합니다.
     * @param loginId 확인할 로그인 ID
     * @return 존재하면 true, 존재하지 않으면 false
     */
    public boolean isLoginIdExists(String loginId) {
        final String sql = "SELECT 1 FROM users WHERE login_id = ? LIMIT 1";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, loginId);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next(); // 결과 행이 있으면 ID가 존재하는 것
            }
        } catch (SQLException e) {
            System.err.println("아이디 중복 확인 중 오류: " + e.getMessage());
            e.printStackTrace();
            return true; // 오류 발생 시 안전을 위해 중복으로 처리
        }
    }

    /**
     * 신규 사용자를 등록합니다. (users, userspecific 테이블에 동시 저장)
     * 트랜잭션을 사용하여 두 작업의 원자성을 보장합니다.
     * @return 회원가입 성공 시 true, 실패 시 false
     */
    public boolean insertUser(String loginId, String password, String name, String phone, String email) {
        final String insertUserSQL = "INSERT INTO users (login_id, password, name, role, status) VALUES (?, ?, ?, 'USER', 'OFFLINE')";
        final String insertSpecificSQL = "INSERT INTO userspecific (phone, name, e_mail, userid) VALUES (?, ?, ?, ?)";

        Connection conn = null;
        try {
            conn = DBConnect.getConnection();
            conn.setAutoCommit(false); // 트랜잭션 시작

            int newUserId = -1;
            // 1. users 테이블에 정보 추가
            try (PreparedStatement ps = conn.prepareStatement(insertUserSQL, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, loginId);
                ps.setString(2, password);
                ps.setString(3, name);
                if (ps.executeUpdate() != 1) {
                    conn.rollback();
                    return false;
                }
                // 방금 생성된 user_id 가져오기
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) newUserId = keys.getInt(1);
                }
            }
            if (newUserId <= 0) {
                conn.rollback();
                return false;
            }

            // 2. userspecific 테이블에 정보 추가
            try (PreparedStatement ps2 = conn.prepareStatement(insertSpecificSQL)) {
                ps2.setString(1, phone);
                ps2.setString(2, name);
                ps2.setString(3, email);
                ps2.setInt(4, newUserId);
                ps2.executeUpdate();
            }

            conn.commit(); // 모든 작업 성공 시 커밋
            return true;

        } catch (SQLException e) {
            System.err.println("회원가입 처리 중 오류: " + e.getMessage());
            e.printStackTrace();
            try { if (conn != null) conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            return false;
        } finally {
            try { if (conn != null) conn.setAutoCommit(true); } catch (SQLException ex) { ex.printStackTrace(); }
            try { if (conn != null) conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
        }
    }

    /**
     * 로그인 ID를 기준으로 사용자의 비밀번호를 변경합니다.
     * @param loginId 비밀번호를 변경할 사용자의 로그인 ID
     * @param newPassword 새로운 비밀번호
     * @return 변경 성공 시 true, 실패 시 false
     */
    public boolean updatePasswordByLoginId(String loginId, String newPassword) {
        final String sql = "UPDATE users SET password = ? WHERE login_id = ?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newPassword);
            pstmt.setString(2, loginId);
            return pstmt.executeUpdate() == 1;
        } catch (SQLException e) {
            System.err.println("비밀번호 변경 중 오류: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * loginId로 사용자를 조회합니다.
     * @param loginId 조회할 사용자의 로그인 ID
     * @return UserDTO 객체, 없을 경우 null
     */
    public UserDTO findUserByLoginId(String loginId) {
        String sql = "SELECT * FROM users WHERE login_id = ?";
        return getUserFromQuery(sql, loginId, true);
    }

    /**
     * userId로 사용자를 조회합니다.
     * @param userId 조회할 사용자의 고유 ID
     * @return UserDTO 객체, 없을 경우 null
     */
    public UserDTO findUserByUserId(int userId) {
        String sql = "SELECT * FROM users WHERE user_id = ?";
        return getUserFromQuery(sql, userId, false);
    }

    // 공통 조회 헬퍼 메서드
    private UserDTO getUserFromQuery(String sql, Object value, boolean isString) {
        UserDTO user = null;
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            if (isString) pstmt.setString(1, (String) value);
            else pstmt.setInt(1, (Integer) value);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    user = new UserDTO();
                    user.setUserId(rs.getInt("user_id"));
                    user.setLoginId(rs.getString("login_id"));
                    user.setPassword(rs.getString("password"));
                    user.setName(rs.getString("name"));
                    user.setRole(rs.getString("role"));
                    user.setStatus(rs.getString("status"));
                    user.setCreatedAt(rs.getTimestamp("created_at"));
                }
            }

        } catch (SQLException e) {
            System.err.println("사용자 조회 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
        }
        return user;
    }

    /**
     * 사용자 정보를 수정합니다. (비밀번호, 이름, 역할, 상태)
     * @param user 수정할 정보가 담긴 UserDTO 객체
     * @return 수정 성공 시 true, 실패 시 false
     */
    public boolean updateUser(UserDTO user) {
        String sql = "UPDATE users SET password = ?, name = ?, role = ?, status = ? WHERE login_id = ?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, user.getPassword());
            pstmt.setString(2, user.getName());
            pstmt.setString(3, user.getRole());
            pstmt.setString(4, user.getStatus());
            pstmt.setString(5, user.getLoginId());

            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("사용자 정보 수정 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 로그인 ID와 비밀번호를 검증합니다.
     * @param loginId 사용자 로그인 ID
     * @param password 사용자 비밀번호
     * @return 인증 성공 시 true, 실패 시 false
     */
    public boolean validateLogin(String loginId, String password) {
        String sql = "SELECT 1 FROM users WHERE login_id = ? AND password = ?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, loginId);
            pstmt.setString(2, password);

            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next(); // 결과 행이 존재하면 인증 성공
            }

        } catch (SQLException e) {
            System.err.println("로그인 인증 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}