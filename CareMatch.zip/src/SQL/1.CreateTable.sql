-- 0. 데이터베이스 및 테이블 초기화 (기존 데이터 삭제)
SET FOREIGN_KEY_CHECKS = 0;
DROP DATABASE IF EXISTS CareMatch;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. 데이터베이스 생성 및 선택
CREATE DATABASE IF NOT EXISTS CareMatch
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;
USE CareMatch;

-- 2. 테이블 생성

-- 사용자 기본 정보
CREATE TABLE users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  login_id VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  name VARCHAR(100) NOT NULL,
  role ENUM('ADMIN','USER') NOT NULL DEFAULT 'USER',
  status ENUM('ONLINE','OFFLINE') DEFAULT 'OFFLINE',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 사용자 상세 정보
CREATE TABLE userspecific (
  phone VARCHAR(20) NOT NULL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  e_mail VARCHAR(100),
  userid INT NOT NULL UNIQUE,
  CONSTRAINT fk_userspecific_user
    FOREIGN KEY (userid) REFERENCES users(user_id)
    ON DELETE CASCADE ON UPDATE CASCADE
);

-- 보호소 정보
CREATE TABLE Shelter (
    shelter_id VARCHAR(50) PRIMARY KEY,
    shelter_name VARCHAR(100),
    telephone VARCHAR(20),
    address VARCHAR(200)
);

-- 품종 정보
CREATE TABLE Species (
    kind_id VARCHAR(50) PRIMARY KEY,
    kind_name VARCHAR(50),
    type_name VARCHAR(50),
    category VARCHAR(50)
);

-- 이미지 정보
CREATE TABLE Image (
    image_id VARCHAR(50) PRIMARY KEY,
    image_url VARCHAR(200),
    image_data LONGBLOB
);

-- 동물 정보
CREATE TABLE Animals (
    animal_id VARCHAR(50) PRIMARY KEY,
    age INT,
    weight FLOAT,
    sex CHAR(1),
    neutered CHAR(1),
    happenDate DATE,
    kind_id VARCHAR(50),
    shelter_id VARCHAR(50),
    status VARCHAR(50),
    image_id VARCHAR(50),
    animal_name VARCHAR(50),
    applicant_id INT NULL DEFAULT NULL
);

-- 문의
CREATE TABLE Inquiry (
    inquiry_id VARCHAR(50) PRIMARY KEY,
    title VARCHAR(100),
    content TEXT,
    created_date DATE,
    status VARCHAR(50),
    user_id INT
);

-- 문의 답변
CREATE TABLE Answer (
    answer_id VARCHAR(50) PRIMARY KEY,
    title VARCHAR(100),
    content TEXT,
    created_date DATETIME,
    inquiry_id VARCHAR(50),
    user_id INT
);

-- 입양 후기
CREATE TABLE Review (
    review_id VARCHAR(50) PRIMARY KEY,
    created_date DATE,
    title VARCHAR(100),
    content TEXT,
    image_id VARCHAR(50),
    `like` INT,
    user_id INT,
    animal_id VARCHAR(50)
);

-- 후기 댓글
CREATE TABLE comment (
    comment_id VARCHAR(50) PRIMARY KEY,
    created_date DATE,
    content TEXT,
    `like` INT,
    review_id VARCHAR(50),
    user_id INT
);

-- 입양 신청
CREATE TABLE Adoption (
    application_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    status VARCHAR(50),
    visit_date DATE,
    submitted_date DATE,
    user_id INT,
    animal_id VARCHAR(50),
    animal_reason TEXT
);

-- 방문 예약 (입양 신청과 연관)
CREATE TABLE Visit (
    visit_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    purpose VARCHAR(100),
    status VARCHAR(50),
    visit_date DATE,
    submitted_date DATE,
    user_id INT,
    animal_id VARCHAR(50),
    application_id INT,
    CONSTRAINT fk_visit_application
        FOREIGN KEY (application_id) REFERENCES Adoption(application_id)
);

-- 관심 동물
CREATE TABLE fav_animal (
    fav_id INT PRIMARY KEY,
    animal_id VARCHAR(50),
    user_id INT
);

-- 채팅방
CREATE TABLE chatting_room (
  room_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  type ENUM('DM','GROUP') NOT NULL,
  title VARCHAR(120),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 채팅방 멤버
CREATE TABLE chatting_room_member (
  room_id BIGINT NOT NULL,
  user_id INT NOT NULL,
  last_read_message_id BIGINT DEFAULT NULL,
  joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (room_id, user_id),
  CONSTRAINT fk_crm_room FOREIGN KEY (room_id) REFERENCES chatting_room(room_id) ON DELETE CASCADE,
  CONSTRAINT fk_crm_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- 채팅 메시지
CREATE TABLE chatting_message (
  message_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  room_id BIGINT NOT NULL,
  sender_id INT NOT NULL,
  content TEXT,
  content_type ENUM('TEXT','IMAGE') NOT NULL DEFAULT 'TEXT',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_cm_room FOREIGN KEY (room_id) REFERENCES chatting_room(room_id) ON DELETE CASCADE,
  CONSTRAINT fk_cm_user FOREIGN KEY (sender_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- 채팅 이미지
CREATE TABLE chat_image (
  image_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  message_id BIGINT NOT NULL,
  file_path VARCHAR(255) NOT NULL,
  original_name VARCHAR(255),
  size_bytes BIGINT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_ci_message FOREIGN KEY (message_id) REFERENCES chatting_message(message_id) ON DELETE CASCADE
);

-- 이메일 인증
CREATE TABLE email_verify (
    fav_id INT PRIMARY KEY,
    animal_id VARCHAR(255),
    user_id VARCHAR(50),
    verified BOOLEAN DEFAULT FALSE,
    created_at DATE
);

-- 메시지 읽음 상태
CREATE TABLE message_read (
  message_id  BIGINT NOT NULL,
  user_id     INT NOT NULL,
  read_at     DATETIME NOT NULL,
  PRIMARY KEY (message_id, user_id),
  KEY idx_read_user (user_id)
);

-- 채팅방별 마지막으로 읽은 메시지
CREATE TABLE chatting_read (
  room_id INT NOT NULL,
  user_id INT NOT NULL,
  last_read_mid BIGINT NOT NULL DEFAULT 0,
  PRIMARY KEY(room_id, user_id)
);

-- 방문 예약 (마이페이지용)
CREATE TABLE visit_reservations (
    reservation_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    animal_name VARCHAR(50) NOT NULL,
    visit_date DATE NOT NULL,
    visit_time VARCHAR(20) NOT NULL,
    contact VARCHAR(20),
    reason TEXT,
    status VARCHAR(20) DEFAULT '예약완료',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_visit_reservations_user
        FOREIGN KEY (user_id) REFERENCES users (user_id)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- 리뷰 좋아요 및 댓글
CREATE TABLE review_like (
    review_id INT NOT NULL,
    user_id VARCHAR(64) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (review_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE review_comment (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    review_id INT NOT NULL,
    user_id VARCHAR(64) NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_review_comment_review (review_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. 샘플 데이터 삽입
-- 샘플 데이터는 users 테이블이 먼저 생성되고 데이터가 삽입된 후에 실행되어야 합니다.
 INSERT INTO users (login_id, password, name, role) VALUES ('aaa', '1234', '관리자', 'ADMIN');
 INSERT INTO users (login_id, password, name) VALUES ('user1', '1234', '사용자1');
 INSERT INTO users (login_id, password, name) VALUES ('user2', '1234', '사용자2');

INSERT INTO userspecific (phone, name, e_mail, userid) VALUES
 ('010-1111-1111', '관리자', 'admin@example.com', (SELECT user_id FROM users WHERE login_id='aaa')),
 ('010-2222-2222', '사용자1', 'user1@example.com', (SELECT user_id FROM users WHERE login_id='user1')),
 ('010-3333-3333', '사용자2', 'user2@example.com', (SELECT user_id FROM users WHERE login_id='user2'));