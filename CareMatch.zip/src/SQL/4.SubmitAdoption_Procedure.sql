-- 기존 프로시저가 있다면 삭제
DROP PROCEDURE IF EXISTS SubmitAdoption;

DELIMITER $$

CREATE PROCEDURE SubmitAdoption (
    IN p_user_id INT,
    IN p_animal_id VARCHAR(50),
    IN p_reason TEXT,
    IN p_intro TEXT
)
BEGIN
    DECLARE v_exists INT DEFAULT 0;
    DECLARE v_status VARCHAR(50);

    -- 사용자 유효성 검사
    SELECT COUNT(*) INTO v_exists FROM users WHERE user_id = p_user_id;
    IF v_exists = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '유효하지 않은 사용자입니다.';
    END IF;

    -- 동물 입양 가능 상태 검사
    SELECT status INTO v_status FROM Animals WHERE animal_id = p_animal_id;
    IF v_status IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '해당 동물이 존재하지 않습니다.';
    END IF;
    IF v_status <> '보호중' AND v_status <> '입양가능' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '해당 동물은 현재 입양 신청 불가 상태입니다.';
    END IF;

    -- Adoption 테이블에 신청 기록 추가
    INSERT INTO Adoption (
        status,
        visit_date,
        submitted_date,
        user_id,
        animal_id,
        animal_reason
    )
    VALUES (
        '대기중',  -- ✅ 'PENDING'에서 'ON_HOLD'로 변경
        NULL,
        NOW(),
        p_user_id,
        p_animal_id,
        CONCAT('Intro: ', p_intro, '\nReason: ', p_reason)
    );

    -- Animals 테이블의 상태를 'ON_HOLD'로 변경
    UPDATE Animals
       SET status = '대기중',
           applicant_id = p_user_id
     WHERE animal_id = p_animal_id;
END$$

DELIMITER ;