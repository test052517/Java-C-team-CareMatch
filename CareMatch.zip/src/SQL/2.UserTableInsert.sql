INSERT INTO users (login_id, password, name, role) VALUES
('aaa',   '1234', '관리자', 'ADMIN'),
('user1', '1234', 'user1',  'USER'),
('user2', '1234', 'user2',  'USER')
ON DUPLICATE KEY UPDATE name=VALUES(name), role=VALUES(role);