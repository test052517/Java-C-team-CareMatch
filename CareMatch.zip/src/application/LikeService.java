package application;

import java.sql.*;

/** 좋아요 서비스: 토글 지원 */
public final class LikeService {
    private LikeService(){}

    public static boolean isLiked(String reviewId, String userId) {
        if (reviewId == null || userId == null) return false;
        final String sql = "SELECT 1 FROM review_like WHERE review_id=? AND user_id=? LIMIT 1";
        try (Connection con = AppDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, reviewId);
            ps.setString(2, userId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static int getLikeCount(String reviewId) {
        if (reviewId == null) return 0;
        final String sql = "SELECT COUNT(*) FROM review_like WHERE review_id=?";
        try (Connection con = AppDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, reviewId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /** 토글: true=좋아요 상태, false=취소 상태 */
    public static boolean toggleLike(String reviewId, String userId) throws SQLException {
        if (reviewId == null || userId == null) return false;
        try (Connection con = AppDB.getConnection()) {
            // 현재 상태 확인
            boolean liked = false;
            try (PreparedStatement ps = con.prepareStatement("SELECT 1 FROM review_like WHERE review_id=? AND user_id=? LIMIT 1")) {
                ps.setString(1, reviewId);
                ps.setString(2, userId);
                try (ResultSet rs = ps.executeQuery()) { liked = rs.next(); }
            }
            if (liked) {
                try (PreparedStatement ps = con.prepareStatement("DELETE FROM review_like WHERE review_id=? AND user_id=?")) {
                    ps.setString(1, reviewId);
                    ps.setString(2, userId);
                    ps.executeUpdate();
                }
                return false; // 취소됨
            } else {
                try (PreparedStatement ps = con.prepareStatement("INSERT INTO review_like(review_id, user_id) VALUES(?, ?)")) {
                    ps.setString(1, reviewId);
                    ps.setString(2, userId);
                    ps.executeUpdate();
                }
                return true; // 좋아요됨
            }
        }
    }
}