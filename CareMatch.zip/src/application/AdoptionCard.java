package application;

import DAO.AdoptionDAO;
import DAO.VisitDAO;
import DAO.VisitReservationDAO;
import DAO.AnimalsDAO;
import DAO.ImageDAO;
import DTO.AdoptionDTO;
import DTO.AnimalsDTO;
import DTO.ImageDTO;
import DTO.VisitReservationDTO;
import DTO.VisitDTO;
import javafx.scene.image.Image;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

public class AdoptionCard extends HBox {

    private Runnable onStatusChanged;

    public AdoptionCard(AdoptionDTO adoption, ManagerAdoptionList listPage) {
        this.getStyleClass().add("animal-card");
        this.setSpacing(20);
        this.setAlignment(Pos.CENTER_LEFT);

        // 이미지
        ImageView imageView = new ImageView("file:resources/img_placeholder.png");
        try {
            AnimalsDAO animalsDAO = new AnimalsDAO();
            AnimalsDTO animal = animalsDAO.findAnimalById(adoption.getAnimalId());
            if (animal != null && animal.getImageId() != null) {
                ImageDAO imageDAO = new ImageDAO();
                ImageDTO img = imageDAO.findImageById(animal.getImageId());
                if (img != null) {
                    if (img.getImageUrl() != null && !img.getImageUrl().trim().isEmpty()) {
                        imageView.setImage(new Image(img.getImageUrl(), true));
                    } else if (img.getImageData() != null && img.getImageData().length > 0) {
                        imageView.setImage(new Image(new java.io.ByteArrayInputStream(img.getImageData())));
                    }
                }
            }
        } catch (Exception ex) {
            System.err.println("이미지 로드 실패: " + ex.getMessage());
        }
        imageView.setFitWidth(80);
        imageView.setFitHeight(80);

        // 정보 박스
        VBox infoBox = new VBox(5);
        infoBox.setAlignment(Pos.CENTER_LEFT);
        infoBox.setMinWidth(250);

        Label animalNameLabel = new Label(adoption.getAnimalName() + "-"+ "ID: " + adoption.getAnimalId());
        animalNameLabel.getStyleClass().add("card-title");

        Label applicantLabel = new Label("신청인 ID: " + adoption.getUserId());
        applicantLabel.getStyleClass().add("card-info");

        Label applyDateLabel = new Label("신청일자: " + adoption.getSubmittedDate());
        applyDateLabel.getStyleClass().add("card-info");

        // 방문일자 조회 (VisitReservationDAO 기준)
        Date visitDate = resolveVisitDateFromReservation(adoption);
        Label visitDateLabel = new Label("방문일자: " +
                (visitDate != null ? visitDate.toString() : "미정"));
        visitDateLabel.getStyleClass().add("card-info");

        infoBox.getChildren().addAll(animalNameLabel, applicantLabel, applyDateLabel, visitDateLabel);

        // 상태 Label
        Label statusLabel = new Label("상태: " + adoption.getStatus());
        statusLabel.getStyleClass().add("card-info");
        statusLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: orange; -fx-font-weight: bold;");
        statusLabel.setPrefWidth(220);
        // ✅ [수정] 라벨 내부의 텍스트를 우측으로 정렬합니다.
        statusLabel.setAlignment(Pos.CENTER_RIGHT);

        // 신청서 확인 버튼
        Button checkApplicationBtn = new Button("입양 신청서 확인");
        checkApplicationBtn.setPrefWidth(220);
        checkApplicationBtn.getStyleClass().add("Orange-Btn2");
        checkApplicationBtn.setOnAction(e -> {
            ManagerAdoptionApplicationForm form = new ManagerAdoptionApplicationForm();
            form.show(adoption, listPage::refreshList);
        });

        // 방문 일정 예약 버튼
        Button scheduleVisitBtn = new Button("방문 일정 확인");
        scheduleVisitBtn.setPrefWidth(220);
        scheduleVisitBtn.getStyleClass().add("Brown-Btn2");
        scheduleVisitBtn.setOnAction(e -> {
            VisitDAO visitDAO = new VisitDAO();
            List<VisitDTO> userVisits = visitDAO.findVisitsByUserId(adoption.getUserId());

            Optional<VisitDTO> matchingVisit = userVisits.stream()
                    .filter(visit -> visit.getApplicationId() == adoption.getApplicationId())
                    .findFirst();

            if (matchingVisit.isPresent()) {
                VisitInfoDisplayForm displayForm = new VisitInfoDisplayForm(matchingVisit.get());
                displayForm.show();
            } else {
                VisitDTO newVisit = new VisitDTO();
                newVisit.setApplicationId(adoption.getApplicationId());
                newVisit.setUserId(adoption.getUserId());
                newVisit.setAnimalId(adoption.getAnimalId());
                newVisit.setVisitDate(java.sql.Date.valueOf(
                        adoption.getVisitDate() != null ? adoption.getVisitDate() : java.time.LocalDate.now()));
                newVisit.setPurpose(adoption.getAnimalReason());
                newVisit.setStatus("예약 대기");

                ManagerVisitScheduleForm scheduleForm =
                        new ManagerVisitScheduleForm(newVisit, listPage::refreshList);
                scheduleForm.show();
            }
        });

        VBox buttonBox = new VBox(8, checkApplicationBtn, scheduleVisitBtn);
        buttonBox.setAlignment(Pos.CENTER_RIGHT);

        VBox rightBox = new VBox(10, statusLabel, buttonBox);
        rightBox.setTranslateX(-6);
        rightBox.setAlignment(Pos.CENTER_RIGHT);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        this.getChildren().addAll(imageView, infoBox, spacer, rightBox);
    }

    private Date resolveVisitDateFromReservation(AdoptionDTO adoption) {
        if (adoption == null) return null;
        try {
            VisitReservationDAO dao = new VisitReservationDAO();
            VisitReservationDTO latest = dao.findLatestByUserAndAnimalLoose(adoption.getUserId(), adoption.getAnimalId());
            if (latest != null && latest.getVisitDate() != null) {
                return latest.getVisitDate();
            }
        } catch (Exception e) {
            System.err.println("방문일자 조회 실패: " + e.getMessage());
        }
        return null;
    }

    public void setOnStatusChanged(Runnable onStatusChanged) {
        this.onStatusChanged = onStatusChanged;
    }
}