package application;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import talkfxclient.bridge.ChatBackend;
import talkfxclient.bridge.JdbcBackend;
import talkfxclient.bridge.LegacySocketBackend;
import talkfxclient.model.User;
import talkfxclient.ui.ChatListWindow;

import java.io.InputStream;
import java.util.Properties;

/** 소켓 우선 → 실패 시 JDBC 백엔드로 폴백하여 채팅 리스트를 여는 런처 */
import application.SessionManager;

public final class ChatLauncher {
    private ChatLauncher() {}

    /** 메뉴 등에서 호출하세요. */
    public static void openChatList() {
        try {
            // 1) 설정 읽기 (classpath의 db.properties)
            String host = "127.0.0.1";
            int port = 9999;
            try (InputStream in = ChatLauncher.class.getClassLoader().getResourceAsStream("db.properties")) {
                if (in != null) {
                    Properties p = new Properties();
                    p.load(in);
                    host = p.getProperty("chat.host", host);
                    try {
                        port = Integer.parseInt(p.getProperty("chat.port", String.valueOf(port)));
                    } catch (NumberFormatException ignore) {}
                } else {
                    System.err.println("[ChatLauncher] db.properties not found on classpath");
                }
            }

            // 2) 백엔드 준비 (소켓 우선)
            ChatBackend backend;
            try {
                System.out.println("[ChatLauncher] try socket backend " + host + ":" + port);
                backend = new LegacySocketBackend(host, port);
            } catch (Throwable t) {
                System.err.println("[ChatLauncher] socket backend failed, fallback JDBC: " + t);
                backend = new JdbcBackend();
            }

                        // 3) 현재 세션을 talkfxclient.model.User로 매핑
            int uid = SessionManager.getInstance().getLoggedInUserId();
            String lid = null, name = null, role = null;
            System.out.println("[ChatLauncher] RESOLVED SESSION uid=" + uid + ", loginId=" + lid + ", role=" + role);
            if (uid <= 0) throw new IllegalStateException("로그인 세션이 비어있습니다. (uid<=0)");
            User me = new User(uid, lid, name, role);

            // 4) 채팅 목록 창 오픈
            new ChatListWindow(backend, me).show();
        } catch (Exception ex) {
            new Alert(Alert.AlertType.ERROR, ex.getMessage(), ButtonType.OK).showAndWait();
        }
    }
}
