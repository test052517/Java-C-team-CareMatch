package application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import DTO.UserDTO;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.VBox;
import javafx.stage.Screen;
import javafx.stage.Stage;

/**
 * 로그인 UI (디자인) + 기존 앱 구조 연동
 * - 로고 아래 텍스트 라벨 제거
 * - 앱 시작 시 로그인 창을 화면 상단 쪽(TopMargin)으로 이동
 * - 회원가입/비번변경 창을 좌/우에 붙이되 위쪽 여백을 보장해서 하단 잘림 방지
 */
public class Main extends Application {

    // 창 위치 기본값
    private static final double TOP_MARGIN = 40; // 화면 위에서 40px
    private static final double SIDE_GAP = 20;   // 로그인과 좌/우 창 사이 간격

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("CareMatch - 로그인");

        VBox root = new VBox(16);
        root.setPadding(new Insets(32, 40, 40, 40));
        root.setAlignment(Pos.TOP_CENTER);
        root.getStyleClass().add("root-pane");

        // ----- 로고 (텍스트 라벨 제거) -----
        Image img = null;
        try {
            InputStream is = getClass().getResourceAsStream("menu_icon/Logo1.png");
            if (is != null) img = new Image(is);
        } catch (Exception ignore) {}
        if (img == null) {
            img = new Image("file:src/application/menu_icon/Logo1.png");
        }
        ImageView logo = new ImageView(img);
        logo.setFitWidth(100);
        logo.setPreserveRatio(true);

        VBox logoBox = new VBox(8, logo);
        logoBox.setAlignment(Pos.CENTER);

        // ----- 폼 -----
        Label idLabel = new Label("ID");
        idLabel.getStyleClass().add("text-label");
        TextField idField = new TextField();
        idField.setPromptText("아이디 입력(6~20자)");
        idField.getStyleClass().add("input-field");

        Label pwLabel = new Label("Password");
        pwLabel.getStyleClass().add("text-label");
        PasswordField pwField = new PasswordField();
        pwField.setPromptText("••••");
        pwField.getStyleClass().add("input-field");
        
        

        Button loginBtn = new Button("로그인");
        loginBtn.setMaxWidth(Double.MAX_VALUE);
        loginBtn.getStyleClass().add("login-button");

        Button signupBtn = new Button("회원가입");
        signupBtn.setMaxWidth(Double.MAX_VALUE);
        signupBtn.getStyleClass().add("secondary-button");

        Hyperlink forgotPw = new Hyperlink("비밀번호를 잊으셨나요?");
        forgotPw.getStyleClass().add("help-link");

        // ----- 이벤트 -----
        loginBtn.setOnAction(event -> {
            String id = idField.getText();
            String pwd = pwField.getText();

            if (id == null || id.isEmpty() || pwd == null || pwd.isEmpty()) {
                showAlert(Alert.AlertType.WARNING, "로그인 실패", "아이디와 비밀번호를 모두 입력해주세요.");
                return;
            }

            LoginResult result = validateLogin(id, pwd);

            if (result != null) {
                // 세션 저장
                UserDTO user = new UserDTO();
                user.setUserId(result.userId);
                user.setLoginId(result.getLoginId());
                SessionManager.getInstance().setLoggedInUser(user);
                // 로그인 사용자 전역 저장 (댓글/좋아요에 사용)
                CurrentUser.set(user.getLoginId());
                
                try {
                    switch (result.role.toLowerCase()) {
                        case "admin":
                            new MainApp().start(primaryStage);
                            break;
                        case "user":
                            new MainListApp().start(primaryStage);
                            break;
                        default:
                            showAlert(Alert.AlertType.ERROR, "오류", "알 수 없는 사용자 역할입니다.");
                            break;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    showAlert(Alert.AlertType.ERROR, "오류", "화면 전환 중 오류가 발생했습니다.");
                }
            } else {
                showAlert(Alert.AlertType.ERROR, "로그인 실패", "아이디 또는 비밀번호가 올바르지 않습니다.");
            }
        });

        signupBtn.setOnAction(event -> {
            SignupStage s = new SignupStage();
            s.show();
            dockLeftOf(s, primaryStage, SIDE_GAP, TOP_MARGIN); // 왼쪽에, 위쪽 여백 보장
        });

        forgotPw.setOnAction(event -> {
            PwChangeStage p = new PwChangeStage();
            p.show();
            dockRightOf(p, primaryStage, SIDE_GAP, TOP_MARGIN); // 오른쪽에, 위쪽 여백 보장
        });

        root.getChildren().addAll(logoBox, idLabel, idField, pwLabel, pwField, loginBtn, signupBtn, forgotPw);

        Scene scene = new Scene(root, 420, 560); // 기본 높이 조금 여유롭게
        //엔터값으로 로그인 이벤트 호출
        scene.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER) {
                loginBtn.fire(); // 버튼 강제 실행
            }
        });
        
        scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();

        // 처음 위치: 화면 중앙에서 위로 올리거나, 고정 TOP_MARGIN 위치
        centerHorizTopMargin(primaryStage, TOP_MARGIN);
    }

    /** 서버 로그인 요청 및 결과 처리 - 기존 로직 사용 */
    private LoginResult validateLogin(String id, String password) {
        try (
            Socket socket = new Socket("localhost", 9999);
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))
        ) {
            String request = String.format("LOGIN:%s:%s", id, password);
            out.println(request);

            String response = in.readLine();
            System.out.println("서버 응답: " + response);

            if (response != null && response.startsWith("LOGIN_SUCCESS:")) {
                // 예: "LOGIN_SUCCESS:123:user"
                String[] parts = response.split(":");
                int userId = Integer.parseInt(parts[1]);
                String role = parts[2];
                return new LoginResult(userId, id, role);
            } else {
                return null;
            }

        } catch (IOException | NumberFormatException e) {
            System.err.println("서버 연결 오류 또는 응답 처리 오류: " + e.getMessage());
            return null;
        }
    }

    private static class LoginResult {
        int userId;
        String loginId;
        String role;
        LoginResult(int userId, String loginId, String role) {
            this.userId = userId;
            this.loginId = loginId;
            this.role = role;
        }
        String getLoginId() { return loginId; }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // ===== 위치 유틸 =====

    /** 로그인 창을 화면 가로 가운데로 두고, Y는 위쪽 여백(TOP_MARGIN)으로 맞춘다. */
    private void centerHorizTopMargin(Stage s, double topMargin) {
        Rectangle2D b = Screen.getPrimary().getVisualBounds();
        double x = b.getMinX() + (b.getWidth() - s.getWidth()) / 2;
        double y = b.getMinY() + topMargin;
        s.setX(Math.max(b.getMinX() + 10, x));
        s.setY(Math.max(b.getMinY() + 10, y));
    }

    /** 기준 창 왼쪽에 child를 붙이고, 위쪽 여백을 보장 */
    private void dockLeftOf(Stage child, Stage base, double gap, double topMargin) {
        Rectangle2D b = Screen.getPrimary().getVisualBounds();
        double x = base.getX() - child.getWidth() - gap;
        double y = Math.max(b.getMinY() + topMargin, base.getY());
        child.setX(Math.max(b.getMinX() + 10, x));
        child.setY(y);
    }

    /** 기준 창 오른쪽에 child를 붙이고, 위쪽 여백을 보장 */
    private void dockRightOf(Stage child, Stage base, double gap, double topMargin) {
        Rectangle2D b = Screen.getPrimary().getVisualBounds();
        double x = base.getX() + base.getWidth() + gap;
        double y = Math.max(b.getMinY() + topMargin, base.getY());
        child.setX(Math.min(b.getMaxX() - child.getWidth() - 10, x));
        child.setY(y);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
