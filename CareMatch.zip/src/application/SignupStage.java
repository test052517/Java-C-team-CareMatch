package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

// ★ DAO 패키지의 클래스명은 UserDAO 여야 합니다.
import DAO.UserDAO;

public class SignupStage extends Stage {

    private boolean idCheckedOK = false;
    private boolean emailVerifiedOK = false;

    public SignupStage() {
        setTitle("CareMatch - 회원가입");

        VBox root = new VBox(16);
        root.getStyleClass().add("root-pane");
        root.setPadding(new Insets(24, 28, 28, 28));

        // 아이디 + 중복확인
        Label idLbl = new Label("아이디");
        idLbl.getStyleClass().add("text-label");

        HBox idRow = new HBox(8);
        idRow.setAlignment(Pos.CENTER_LEFT);
        TextField idField = new TextField();
        idField.setPromptText("아이디 입력(6~20자)");
        idField.getStyleClass().add("input-field");
        Button dupBtn = new Button("중복확인");
        dupBtn.getStyleClass().add("minor-button");
        idRow.getChildren().addAll(idField, dupBtn);
        HBox.setHgrow(idField, Priority.ALWAYS);

        // 비밀번호
        Label pwLbl = new Label("비밀번호");
        pwLbl.getStyleClass().add("text-label");
        PasswordField pwField = new PasswordField();
        pwField.setPromptText("••••••••");
        pwField.getStyleClass().add("input-field");

        Label pwHint = new Label("20자 이내로 비밀번호를 입력해주세요.");
        pwHint.getStyleClass().add("warn-text");

        // 비밀번호 확인
        Label pw2Lbl = new Label("비밀번호 확인");
        pw2Lbl.getStyleClass().add("text-label");
        PasswordField pw2Field = new PasswordField();
        pw2Field.setPromptText("••••••••");
        pw2Field.getStyleClass().add("input-field");

        Label pw2Hint = new Label("비밀번호가 일치하지 않습니다.");
        pw2Hint.getStyleClass().add("warn-text");

        // 이름
        Label nameLbl = new Label("이름");
        nameLbl.getStyleClass().add("text-label");
        TextField nameField = new TextField();
        nameField.setPromptText("이름 입력");
        nameField.getStyleClass().add("input-field");

        // 전화번호
        Label phoneLbl = new Label("전화번호");
        phoneLbl.getStyleClass().add("text-label");
        TextField phoneField = new TextField();
        phoneField.setPromptText("휴대폰 번호 입력('-' 제외 11자리 입력)");
        phoneField.getStyleClass().add("input-field");

        // 이메일 + 인증
        Label emailLbl = new Label("이메일 주소");
        emailLbl.getStyleClass().add("text-label");

        HBox emailRow = new HBox(8);
        emailRow.setAlignment(Pos.CENTER_LEFT);
        TextField emailField = new TextField();
        emailField.setPromptText("이메일 주소");
        emailField.getStyleClass().add("input-field");
        Button sendCodeBtn = new Button("인증번호 받기");
        sendCodeBtn.getStyleClass().add("minor-button");
        emailRow.getChildren().addAll(emailField, sendCodeBtn);
        HBox.setHgrow(emailField, Priority.ALWAYS);

        Label codeLbl = new Label("인증번호 입력");
        codeLbl.getStyleClass().add("text-label");

        HBox codeRow = new HBox(8);
        TextField codeField = new TextField();
        codeField.setPromptText("인증번호 입력");
        codeField.getStyleClass().add("input-field");
        Button verifyBtn = new Button("인증번호 확인");
        verifyBtn.getStyleClass().add("minor-button");
        codeRow.getChildren().addAll(codeField, verifyBtn);
        HBox.setHgrow(codeField, Priority.ALWAYS);

        Button joinBtn = new Button("가입하기");
        joinBtn.getStyleClass().add("primary-button");
        joinBtn.setMaxWidth(Double.MAX_VALUE);

        // 비밀번호 힌트
        pwField.textProperty().addListener((obs, o, n) -> {
            boolean ok = n != null && n.length() <= 20 && n.length() >= 1;
            pwHint.setText(ok ? "가능한 비밀번호입니다." : "20자 이내로 비밀번호를 입력해주세요.");
            pwHint.getStyleClass().removeAll("good-text", "warn-text");
            pwHint.getStyleClass().add(ok ? "good-text" : "warn-text");
        });

        pw2Field.textProperty().addListener((obs, o, n) -> {
            boolean same = n != null && n.equals(pwField.getText());
            pw2Hint.setText(same ? "비밀번호가 일치합니다." : "비밀번호가 일치하지 않습니다.");
            pw2Hint.getStyleClass().removeAll("good-text", "warn-text");
            pw2Hint.getStyleClass().add(same ? "good-text" : "warn-text");
        });

        // 아이디 중복확인
        dupBtn.setOnAction(e -> {
            String id = idField.getText().trim();
            if (id.isEmpty()) {
                alert("아이디를 채워주세요");
                idField.requestFocus();
                idCheckedOK = false;
                return;
            }
            UserDAO dao = new UserDAO();
            boolean exists = dao.isLoginIdExists(id);
            if (exists) {
                idCheckedOK = false;
                alert("사용중인 아이디입니다.");
            } else {
                idCheckedOK = true;
                alertInfo("사용 가능한 아이디입니다.");
            }
        });

        // 인증번호 발송 (requestCode는 void)
        sendCodeBtn.setOnAction(e -> {
            String email = emailField.getText().trim();
            if (email.isEmpty()) {
                alert("이메일을 채워주세요");
                emailField.requestFocus();
                return;
            }
            try {
                EmailVerificationService svc = new EmailVerificationService();
                svc.requestCode(null, email); // 반환값 없음
                alertInfo("인증번호를 발송했습니다. 메일함을 확인하세요.");
            } catch (Exception ex) {
                ex.printStackTrace();
                alert("인증번호 발송 중 오류가 발생했습니다.");
            }
        });

        // 인증번호 확인
        verifyBtn.setOnAction(e -> {
            String email = emailField.getText().trim();
            String code = codeField.getText().trim();
            if (email.isEmpty()) { alert("이메일을 채워주세요"); emailField.requestFocus(); return; }
            if (code.isEmpty()) { alert("인증번호를 채워주세요"); codeField.requestFocus(); return; }
            try {
                EmailVerificationService svc = new EmailVerificationService();
                boolean ok = svc.verifyCode(null, email, code);
                emailVerifiedOK = ok;
                if (ok) alertInfo("이메일 인증이 완료되었습니다.");
                else alert("인증번호가 올바르지 않습니다.");
            } catch (Exception ex) {
                ex.printStackTrace();
                alert("인증 확인 중 오류가 발생했습니다.");
            }
        });

        // 가입
        joinBtn.setOnAction(e -> {
            String id = idField.getText().trim();
            String pw = pwField.getText();
            String pw2 = pw2Field.getText();
            String name = nameField.getText().trim();
            String phone = phoneField.getText().trim();
            String email = emailField.getText().trim();

            if (id.isEmpty()) { alert("아이디를 채워주세요"); idField.requestFocus(); return; }
            if (!idCheckedOK) { alert("아이디 중복확인을 해주세요"); return; }
            if (pw == null || pw.isEmpty() || pw.length() > 20) { alert("비밀번호를 채워주세요 (1~20자)"); pwField.requestFocus(); return; }
            if (!pw.equals(pw2)) { alert("비밀번호가 일치하지 않습니다."); pw2Field.requestFocus(); return; }
            if (name.isEmpty()) { alert("이름을 채워주세요"); nameField.requestFocus(); return; }
            if (phone.isEmpty()) { alert("전화번호를 채워주세요"); phoneField.requestFocus(); return; }
            if (email.isEmpty()) { alert("이메일을 채워주세요"); emailField.requestFocus(); return; }
            if (!emailVerifiedOK) { alert("이메일 인증을 완료해주세요"); return; }

            UserDAO dao = new UserDAO();
            boolean ok = dao.insertUser(id, pw, name, phone, email);
            if (ok) {
                alertInfo("회원가입이 완료되었습니다. 로그인해 주세요.");
                close();
            } else {
                alert("회원가입 처리 중 오류가 발생했습니다.");
            }
        });

        root.getChildren().addAll(
            idLbl, idRow,
            pwLbl, pwField, pwHint,
            pw2Lbl, pw2Field, pw2Hint,
            nameLbl, nameField,
            phoneLbl, phoneField,
            emailLbl, emailRow,
            codeLbl, codeRow,
            joinBtn
        );

        Scene scene = new Scene(root, 520, 800);
        scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
        setScene(scene);
        setResizable(false);
    }

    private void alert(String msg) {
        Alert a = new Alert(AlertType.ERROR);
        a.setTitle("입력 오류");
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }
    private void alertInfo(String msg) {
        Alert a = new Alert(AlertType.INFORMATION);
        a.setTitle("안내");
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }
}
