package application;

import DAO.ReviewDAO;
import DAO.ReviewImageDAO;
import DTO.ReviewDTO;
import DTO.ReviewImageDTO;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Optional;

public class ManagerReviewCard extends HBox {
    
    public ManagerReviewCard(ReviewDTO review, Runnable refreshAction) {
        this.getStyleClass().add("animal-card");
        this.setSpacing(20);
        this.setAlignment(Pos.CENTER_LEFT);

        // --- 이미지 로딩 (DB 연동) ---
        ImageView imageView = new ImageView();
        imageView.setFitWidth(55);
        imageView.setFitHeight(55);
        
        ReviewImageDAO imageDAO = new ReviewImageDAO();
        ReviewImageDTO imageDTO = imageDAO.findByReviewId(review.getReviewId());
        
        if (imageDTO != null && imageDTO.getImageData() != null) {
            Image image = new Image(new ByteArrayInputStream(imageDTO.getImageData()));
            imageView.setImage(image);
        } else {
            imageView.setImage(loadImage("img_placeholder.png"));
        }

        // --- 텍스트 정보 ---
        Label title = new Label(review.getTitle());
        title.getStyleClass().add("card-title");

        Label author = new Label("작성인: " + review.getUserName());
        author.getStyleClass().add("card-info");

        VBox infoBox = new VBox(5, title, author);
        infoBox.setAlignment(Pos.CENTER_LEFT);

        // --- 좋아요 수 ---
        ImageView heartIcon = new ImageView(loadImage("icon/icon-heart.png"));
        heartIcon.setFitWidth(16);
        heartIcon.setFitHeight(16);

        Label likesLabel = new Label(String.valueOf(review.getLikeCount()));
        likesLabel.getStyleClass().add("likes-label");

        HBox likeBox = new HBox(5, heartIcon, likesLabel);
        likeBox.setAlignment(Pos.CENTER_LEFT);

        // --- 버튼 ---
        Button detailBtn = new Button("상세 확인");
        Button deleteBtn = new Button("삭제");

        detailBtn.setOnAction(e -> {
            ManagerReviewForm form = new ManagerReviewForm();
            form.show(review.getReviewId());
        });
        
        deleteBtn.setOnAction(e -> {
            Alert confirmDialog = new Alert(Alert.AlertType.CONFIRMATION);
            confirmDialog.setTitle("삭제 확인");
            confirmDialog.setHeaderText("정말로 이 후기를 삭제하시겠습니까?");
            confirmDialog.setContentText("이 작업은 되돌릴 수 없습니다.");

            Optional<ButtonType> result = confirmDialog.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                ReviewDAO reviewDAO = new ReviewDAO();
                boolean isDeleted = reviewDAO.deleteReview(review.getReviewId());
                if (isDeleted) {
                    refreshAction.run();
                } else {
                    Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                    errorAlert.setTitle("삭제 실패");
                    errorAlert.setHeaderText("리뷰 삭제에 실패했습니다.");
                    errorAlert.showAndWait();
                }
            }
        });
        
        detailBtn.getStyleClass().add("Orange-Btn2");
        deleteBtn.getStyleClass().add("Brown-Btn2");

        HBox buttonBar = new HBox(10, likeBox, detailBtn, deleteBtn);
        buttonBar.setAlignment(Pos.CENTER_RIGHT);

        // --- 레이아웃 구성 ---
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        
        this.getChildren().addAll(imageView, infoBox, spacer, buttonBar);
    }
    
    private Image loadImage(String imagePath) {
        try (InputStream is = getClass().getResourceAsStream("/resources/" + imagePath)) {
            if (is == null) {
                System.err.println("이미지를 찾을 수 없습니다: /resources/" + imagePath);
                return null;
            }
            return new Image(is);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
