package application;

import DAO.ReviewDAO;
import DAO.ReviewImageDAO;
import DTO.ReviewDTO;
import DTO.ReviewImageDTO;
import DTO.UserDTO;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.UUID;

public class ReviewWriteForm {

    private File selectedFile = null;
    private boolean bimg = false;

    public void show(Stage owner, UserDTO currentUser) {
        show(owner, currentUser, null);
    }

    public void show(Stage owner, UserDTO currentUser, Runnable onSuccess) {
        Stage stage = new Stage();
        stage.initOwner(owner);
        stage.setTitle("후기 작성");

        // ===== 상단 헤더 =====
        Label headerTitle = new Label("후기 작성");
        headerTitle.getStyleClass().add("header-title");
        HBox headerBar = new HBox(headerTitle);
        headerBar.getStyleClass().add("header-bar");
        headerBar.setAlignment(Pos.CENTER);

        // ===== 제목 =====
        Label titleLbl = new Label("제목");
        titleLbl.getStyleClass().add("field-label");

        TextField titleField = new TextField();
        titleField.setPromptText("제목을 입력하세요");
        titleField.getStyleClass().add("input-rounded");
        titleField.setStyle("-fx-text-fill: black;"); // ✅ 글씨 검은색

        VBox titleBox = new VBox(6, titleLbl, titleField);

        // ===== 내용 =====
        Label contentLbl = new Label("내용");
        contentLbl.getStyleClass().add("field-label");

        TextArea contentArea = new TextArea();
        contentArea.setPromptText("내용을 입력하세요");
        contentArea.setPrefRowCount(10);
        contentArea.getStyleClass().add("textarea-soft");
        contentArea.setStyle("-fx-text-fill: black;"); // ✅ 글씨 검은색

        VBox contentBox = new VBox(6, contentLbl, contentArea);

        // ===== 첨부 박스 =====
        ImageView attachIcon = new ImageView(new Image("file:src/application/menu_icon/attatch.png"));
        attachIcon.setFitWidth(22);
        attachIcon.setFitHeight(22);

        Label attachText = new Label("사진 첨부");
        attachText.getStyleClass().add("attach-text");

        // 미리보기 이미지
        ImageView previewImage = new ImageView();
        previewImage.setFitWidth(200);
        previewImage.setFitHeight(200);
        previewImage.setPreserveRatio(true);

        // 헤더(아이콘 + 텍스트)는 왼쪽 정렬
        HBox attachHeader = new HBox(10, attachIcon, attachText);
        attachHeader.setAlignment(Pos.CENTER_LEFT);

        // ✅ 미리보기는 가운데 정렬되도록 HBox로 감싼다
        HBox previewCenter = new HBox(previewImage);
        previewCenter.setAlignment(Pos.CENTER);
        previewCenter.setMaxWidth(Double.MAX_VALUE);

        // VBox 구성: (헤더, 가운데정렬 미리보기)
        VBox attachBox = new VBox(10, attachHeader, previewCenter);
        attachBox.getStyleClass().add("attach-box");
        attachBox.setMinHeight(250);
        // ✅ 전체 정렬을 TOP_CENTER로 (가로는 가운데)
        attachBox.setAlignment(Pos.TOP_CENTER);

        // 클릭 이벤트 (파일 선택)
        attachBox.setOnMouseClicked(e -> {
            FileChooser fc = new FileChooser();
            fc.getExtensionFilters().add(new FileChooser.ExtensionFilter(
                "Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif"));
            File f = fc.showOpenDialog(stage);
            if (f != null) {
                selectedFile = f;
                try {
                    previewImage.setImage(new Image(new FileInputStream(f))); // 가운데 표시됨
                    attachText.setText("사진 첨부됨");
                    bimg = true;
                } catch (FileNotFoundException ex) {
                    ex.printStackTrace();
                    bimg = false;
                }
            }
        });

        // ===== 등록 버튼 =====
        Button submitBtn = new Button("등록");
        submitBtn.getStyleClass().add("cta-btn");
        submitBtn.setPrefWidth(130);
        VBox submitBtnBox = new VBox();
        submitBtnBox.getChildren().add(submitBtn);
        submitBtnBox.setAlignment(Pos.BOTTOM_CENTER);
        

        VBox card = new VBox(16, headerBar, titleBox, contentBox, attachBox, submitBtnBox);
        card.getStyleClass().add("card");
        card.setFillWidth(true);

        VBox root = new VBox(card);
        root.getStyleClass().add("page");
        root.setPadding(new Insets(24));
        root.setAlignment(Pos.TOP_CENTER);

        // ===== 저장 로직 =====
        submitBtn.setOnAction(ev -> {
            String title = titleField.getText().trim();
            String content = contentArea.getText().trim();
            if (title.isEmpty()) { titleField.requestFocus(); return; }

            ReviewDTO review = new ReviewDTO();
            review.setReviewId("R-" + System.currentTimeMillis());
            review.setCreatedDate(Date.valueOf(LocalDate.now()));
            review.setTitle(title);
            review.setContent(content);
            review.setUserId(String.valueOf(currentUser != null ? currentUser.getUserId() : 0));
            review.setAnimalId(null);
            review.setImageId(null);
            review.setLikeCount(0);

            boolean ok = new ReviewDAO().addReview(review);
            if (!ok) { new Alert(Alert.AlertType.ERROR, "후기 등록에 실패했습니다.").showAndWait(); return; }

            if (bimg && selectedFile != null) {
                try (FileInputStream fis = new FileInputStream(selectedFile);
                     ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
                    byte[] buf = new byte[8192];
                    int r; while ((r = fis.read(buf)) != -1) baos.write(buf, 0, r);

                    ReviewImageDTO img = new ReviewImageDTO();
                    img.setReviewImageId("rimg_" + UUID.randomUUID());
                    img.setReviewId(review.getReviewId());
                    img.setFileName(selectedFile.getName());
                    img.setMimeType(null);
                    img.setImageData(baos.toByteArray());
                    new ReviewImageDAO().save(img);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }

            new Alert(Alert.AlertType.INFORMATION, "후기가 등록되었습니다.").showAndWait();
            if (onSuccess != null) Platform.runLater(onSuccess);
            stage.close();
        });

        // ===== Scene =====
        Scene scene = new Scene(root, 520, 720); // ✅ 세로 720으로 늘림
        scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
        scene.getStylesheets().add(getClass().getResource("review_write.css").toExternalForm());

        stage.setScene(scene);
        stage.showAndWait();
    }
}
