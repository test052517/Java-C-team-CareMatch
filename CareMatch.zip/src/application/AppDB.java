package application;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * AppDB: DB.java 이름 충돌을 피하기 위해 만든 애플리케이션 전용 JDBC 헬퍼.
 * db.properties 탐색 순서:
 * 1) 클래스패스: /DB/db.properties
 * 2) 클래스패스: /db.properties
 * 3) 파일경로 : DB/db.properties
 * 4) 파일경로 : src/DB/db.properties
 * 5) 마지막 대비: /application/db.properties
 */
public final class AppDB {

    private static String url;
    private static String user;
    private static String password;
    private static String driver;

    static {
        Properties p = new Properties();
        boolean loaded = false;

        // 1) 클래스패스 내 /DB/db.properties
        loaded = loadFromClasspath(p, "/DB/db.properties");

        // 2) 클래스패스 내 /db.properties
        if (!loaded) loaded = loadFromClasspath(p, "/db.properties");

        // 3) 파일 경로 DB/db.properties
        if (!loaded) loaded = loadFromFile(p, new File("DB/db.properties"));

        // 4) 파일 경로 src/DB/db.properties
        if (!loaded) loaded = loadFromFile(p, new File("src/DB/db.properties"));

        // 5) 마지막 대비: 현재 패키지 내 템플릿
        if (!loaded) loaded = loadFromClasspath(p, "db.properties");

        url      = p.getProperty("jdbc.url", "jdbc:mysql://localhost:3306/carematch?useSSL=false&serverTimezone=UTC&characterEncoding=utf8");
        user     = p.getProperty("jdbc.user", "root");
        password = p.getProperty("jdbc.password", "");
        driver   = p.getProperty("jdbc.driver", "com.mysql.cj.jdbc.Driver");

        try {
            Class.forName(driver);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private AppDB() {}

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }

    private static boolean loadFromClasspath(Properties p, String path) {
        try (InputStream in = AppDB.class.getResourceAsStream(path)) {
            if (in != null) {
                p.load(in);
                return true;
            }
        } catch (Exception ignore) {}
        return false;
    }

    private static boolean loadFromFile(Properties p, File f) {
        try (InputStream in = new FileInputStream(f)) {
            p.load(in);
            return true;
        } catch (Exception ignore) {}
        return false;
    }
}