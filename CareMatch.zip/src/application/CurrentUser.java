package application;

/** 
 * 전역 현재 사용자 보관소.
 * - 로그인 성공 직후 set(loginId) 한 번만 호출하세요.
 * - 어디서든 CurrentUser.get()으로 로그인 아이디 사용.
 */
public final class CurrentUser {
    private static volatile String userId = "guest";

    private CurrentUser() {}

    public static void set(String id) {
        userId = (id == null || id.isBlank()) ? "guest" : id;
        System.out.println("[CurrentUser] set -> " + userId);
    }

    public static String get() {
        return userId;
    }

    public static boolean isGuest() {
        return "guest".equalsIgnoreCase(userId);
    }
}