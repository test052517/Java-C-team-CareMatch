package application.ui;

import application.ManagerReviewCard;
import DTO.ReviewDTO;
import javafx.scene.layout.VBox;

import java.util.List;

public class ReviewListView extends VBox {
    private Runnable refreshAction; // 새로고침 동작을 저장할 변수

    // 생성자에서 새로고침 동작(Runnable)을 받도록 수정
    public ReviewListView(List<ReviewDTO> reviews, Runnable refreshAction) {
        super(10);
        this.getStyleClass().add("review-list");
        this.refreshAction = refreshAction; // 전달받은 동작 저장
        updateList(reviews);
    }

    public void updateList(List<ReviewDTO> reviews) {
        this.getChildren().clear();
        for (ReviewDTO review : reviews) {
            // ManagerReviewCard 생성 시 새로고침 동작을 함께 전달
            this.getChildren().add(new ManagerReviewCard(review, refreshAction));
        }
    }
}