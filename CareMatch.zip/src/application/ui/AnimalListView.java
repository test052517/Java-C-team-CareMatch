package application.ui;

import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import DTO.AnimalsDTO;
import application.AnimalCard;
import application.ManagerMainList;

public class AnimalListView extends VBox {
    
    private ManagerMainList mainView;

    public AnimalListView(List<AnimalsDTO> animals, ManagerMainList mainView) {
        super(10);
        this.mainView = mainView;
        this.getStyleClass().add("animal-list");
    }
    
    public void updateList(List<AnimalsDTO> animals, int userId, Map<String, Image> imageCache) {
        this.getChildren().clear();
        for (AnimalsDTO animal : animals) {
            AnimalCard card = new AnimalCard(animal, this.mainView, userId);
            
            Image cachedImage = imageCache.get(animal.getImageId());
            if (cachedImage != null) {
                card.updateImage(cachedImage);
            }
            
            this.getChildren().add(card);
        }
    }

    public List<AnimalCard> getAnimalCards() {
        return this.getChildren().stream()
                   .filter(node -> node instanceof AnimalCard)
                   .map(node -> (AnimalCard) node)
                   .collect(Collectors.toList());
    }
}