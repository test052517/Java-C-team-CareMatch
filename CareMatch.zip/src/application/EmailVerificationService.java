package application;

import java.io.FileInputStream;
import java.io.InputStream;
import java.security.SecureRandom;
import java.sql.*;
import java.time.LocalDate;
import java.util.Properties;

/** 이메일 인증 서비스 (기존 DB 테이블: email_verify 사용)
 *  - 매핑: animal_id = 이메일, user_id = 6자리 코드(평문), verified = 0/1, created_at = DATE(오늘)
 *  - 만료 규칙: created_at = 오늘(자정 기준). 같은 날 가장 최신 레코드 기준 검증.
 *  - 보안성: 코드 평문 저장(요청대로 기존 스키마 사용). 운영 보안 필요시 테이블 컬럼 확장 권장.
 */
public class EmailVerificationService {
    private final Properties db;

    public EmailVerificationService() {
        try {
            db = new Properties();
            InputStream in = getClass().getResourceAsStream("/db.properties");
            if (in != null) db.load(in);
            else db.load(new FileInputStream("db.properties"));
            try { Class.forName("com.mysql.cj.jdbc.Driver"); } catch (Throwable ignore){}
        } catch (Exception e) {
            throw new RuntimeException("DB 설정 로드 실패", e);
        }
    }

    private Connection getConn() throws Exception {
        String url  = first(db.getProperty("jdbc.url"), db.getProperty("url"),
                "jdbc:mysql://localhost:3306/careMatch?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&characterEncoding=UTF-8");
        String user = first(db.getProperty("jdbc.user"), db.getProperty("username"), db.getProperty("user"), "root");
        String pass = first(db.getProperty("jdbc.password"), db.getProperty("password"), db.getProperty("pass"), "");
        return DriverManager.getConnection(url, user, pass);
    }

    /** 인증번호 발송 요청: email_verify에 행 추가 + 메일 발송 */
    public void requestCode(String loginIdOrNull, String email) throws Exception {
        String code = generateCode();
        LocalDate today = LocalDate.now();

        try (Connection c = getConn();
             PreparedStatement ps = c.prepareStatement(
                "INSERT INTO email_verify (animal_id, user_id, verified, created_at) VALUES (?,?,0, ?)")) {
            ps.setString(1, email); // animal_id 컬럼을 이메일로 사용
            ps.setString(2, code);  // user_id 컬럼을 코드로 사용
            ps.setDate(3, java.sql.Date.valueOf(today));
            ps.executeUpdate();
        }

        new EmailSender().sendVerification(email, code);
    }

    /** 인증번호 검증: 같은 날 생성된 최신 레코드 기준 */
    public boolean verifyCode(String loginIdOrNull, String email, String code) throws Exception {
        LocalDate today = LocalDate.now();
        try (Connection c = getConn();
             PreparedStatement ps = c.prepareStatement(
                 "SELECT fav_id, user_id, verified FROM email_verify " +
                 "WHERE animal_id=? AND created_at=? " +
                 "ORDER BY fav_id DESC LIMIT 1")) {
            ps.setString(1, email);
            ps.setDate(2, java.sql.Date.valueOf(today));
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return false;
                int id = rs.getInt("fav_id");
                String storedCode = rs.getString("user_id");
                int ver = rs.getInt("verified");
                if (ver == 1) return false; // 이미 사용됨
                if (!code.equals(storedCode)) return false;

                try (PreparedStatement ps2 = c.prepareStatement(
                        "UPDATE email_verify SET verified=1 WHERE fav_id=?")) {
                    ps2.setInt(1, id);
                    ps2.executeUpdate();
                }
                return true;
            }
        }
    }

    private static String generateCode() {
        return String.format("%06d", new SecureRandom().nextInt(1_000_000));
    }

    private static String first(String... v) {
        for (String s : v) if (s != null && !s.isEmpty()) return s;
        return null;
    }
}
