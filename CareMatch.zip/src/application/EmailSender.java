package application;

import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/** Gmail SMTP 발송 유틸 (javax.mail 1.6.x / Jakarta Mail 호환) */
public class EmailSender {

    private final Properties mailProps;

    public EmailSender() {
        this.mailProps = new Properties();
        try {
            InputStream in = null;
            try {
                in = getClass().getResourceAsStream("/mail.properties");
            } catch (Exception ignore) {}
            if (in == null) {
                in = new FileInputStream("src/mail.properties");
            }
            mailProps.load(in);
            in.close();
        } catch (Exception e) {
            throw new RuntimeException("mail.properties 로드 실패", e);
        }
    }

    private Session buildSession() {
        final String user = mailProps.getProperty("mail.user");
        final String pass = mailProps.getProperty("mail.pass");
        Properties props = new Properties();
        props.put("mail.smtp.host", mailProps.getProperty("mail.smtp.host", "smtp.gmail.com"));
        props.put("mail.smtp.port", mailProps.getProperty("mail.smtp.port", "587"));
        props.put("mail.smtp.auth", mailProps.getProperty("mail.smtp.auth", "true"));
        props.put("mail.smtp.starttls.enable", mailProps.getProperty("mail.smtp.starttls.enable", "true"));
        return Session.getInstance(props, new Authenticator() {
            @Override protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(user, pass);
            }
        });
    }

    private InternetAddress fromAddress() throws Exception {
        String from = mailProps.getProperty("mail.from", mailProps.getProperty("mail.user"));
        String fromName = mailProps.getProperty("mail.from.name", "CareMatch");
        return new InternetAddress(from, fromName, StandardCharsets.UTF_8.name());
    }

    /** 일반 텍스트 메일 */
    public void sendPlainText(String to, String subject, String body) throws Exception {
        Session session = buildSession();
        MimeMessage msg = new MimeMessage(session);
        msg.setFrom(fromAddress());
        msg.setRecipient(Message.RecipientType.TO, new InternetAddress(to));
        msg.setSubject(subject, StandardCharsets.UTF_8.name());
        msg.setText(body, StandardCharsets.UTF_8.name());
        Transport.send(msg);
    }

    /** 기존 코드 호환: 인증번호 전송 (과거 메서드명) */
    public void sendVerification(String to, String code) throws Exception {
        sendAuthCode(to, code);
    }

    /** 인증번호 전송(새 이름) */
    public void sendAuthCode(String to, String code) throws Exception {
        String subject = "[CareMatch] 이메일 인증번호";
        String body = "안녕하세요, CareMatch 입니다.\n\n"
                + "아래 인증번호를 앱에 입력해주세요.\n"
                + "인증번호: " + code + "\n"
                + "유효시간: 5분\n\n"
                + "본 메일은 발신 전용입니다.";
        sendPlainText(to, subject, body);
    }
}