
package application;

import javafx.application.Platform;
import DAO.AdoptionDAO;
import DTO.AdoptionDTO;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox; 
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.stage.Modality;
import javafx.stage.Stage;

import DAO.AnimalsDAO;
import DAO.ImageDAO;
import DTO.AnimalsDTO;
import DTO.ImageDTO;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.file.Paths;
import java.util.List;

public class AdoptionCheckedForm {

    public void show(Stage owner) {
        Stage stage = new Stage();
        stage.initOwner(owner);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("입양신청 확인");

        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_LEFT);

        Label headerLabel = new Label("입양신청 확인");
        headerLabel.getStyleClass().add("headerLabel");

        VBox contentBox = new VBox(12);
        contentBox.setAlignment(Pos.TOP_LEFT);
        contentBox.setPadding(new Insets(12));

        Label sectionLabel = new Label("입양신청 확인");
        sectionLabel.getStyleClass().add("titleLabel");

        int currentUserId = SessionManager.getInstance().getLoggedInUserId();

        AdoptionDAO dao = new AdoptionDAO();
        List<AdoptionDTO> applications = dao.getAdoptionsByUser(currentUserId);

        ComboBox<String> animalSelect = new ComboBox<>();
        for (AdoptionDTO dto : applications) {
            animalSelect.getItems().add(dto.getAnimalId());
        }
        if (!animalSelect.getItems().isEmpty()) {
            animalSelect.setValue(animalSelect.getItems().get(0));
        }

        Label adoptLabel = new Label("입양 대상: ");
        Label dateLabel = new Label("신청일자: ");
        Label statusLabel = new Label("상태: ");
        Label msgArea = new Label("\"관리자의 승인 후 방문 예약이 가능합니다.\"");

        VBox detailText = new VBox(10, adoptLabel, dateLabel, statusLabel, msgArea);

        ImageView animalImageView = new ImageView();
        animalImageView.setFitWidth(140);
        animalImageView.setFitHeight(140);
        animalImageView.setPreserveRatio(true);

        HBox detailRow = new HBox(20, detailText, animalImageView);
        detailRow.setAlignment(Pos.TOP_LEFT);
        HBox.setHgrow(detailText, Priority.ALWAYS);

        Button okBtn = new Button("확인");
        okBtn.setPrefWidth(190);
        okBtn.setOnAction(e -> stage.close());

        Runnable update = () -> {
            String raw = animalSelect.getValue();
            if (raw == null) return;
            String id = raw.trim();

            adoptLabel.setText("입양 대상: " + id);
            AdoptionDTO sel = null;
            for (AdoptionDTO d : applications) {
                if (id.equals(d.getAnimalId())) { sel = d; break; }
            }
            if (sel != null) {
                dateLabel.setText("신청일자: " + (sel.getSubmittedDate() != null ? sel.getSubmittedDate().toString() : "-"));
                statusLabel.setText("상태: " + (sel.getStatus() != null ? sel.getStatus() : "-"));
            } else {
                dateLabel.setText("신청일자: -");
                statusLabel.setText("상태: -");
            }

            try {
                AnimalsDAO animalsDAO = new AnimalsDAO();
                AnimalsDTO animal = animalsDAO.findAnimalById(id);
                if (animal == null) { // adoption.animal_id가 이름인 경우
                    animal = animalsDAO.findAnimalByName(id);
                }
                if (animal == null) {
                    String digits = id.replaceAll("[^0-9]", "");
                    if (!digits.isEmpty()) {
                        animal = animalsDAO.findAnimalById("동물" + digits);
                        if (animal == null) animal = animalsDAO.findAnimalById(digits);
                    }
                }

                Image imageToShow = null;
                ImageDAO imageDAO = new ImageDAO();
                if (animal != null && animal.getImageId() != null) {
                    ImageDTO img = imageDAO.findImageById(animal.getImageId());
                    imageToShow = resolveImage(img);
                }
                if (imageToShow == null) {
                    ImageDTO img2 = imageDAO.findImageById(id);
                    if (img2 == null) {
                        String digits = id.replaceAll("[^0-9]", "");
                        if (!digits.isEmpty()) img2 = imageDAO.findImageById(digits);
                    }
                    imageToShow = resolveImage(img2);
                }
                animalImageView.setImage(imageToShow);
            } catch (Exception ex) {
                System.err.println("동물 이미지 로드 실패: " + ex.getMessage());
            }
        };
        animalSelect.valueProperty().addListener((obs, ov, nv) -> update.run());
        Platform.runLater(update);

        contentBox.getChildren().addAll(sectionLabel, animalSelect, detailRow);

        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);

        VBox buttonContainer = new VBox(okBtn);
        buttonContainer.setAlignment(Pos.CENTER);

        root.getChildren().addAll(headerLabel, contentBox, spacer, buttonContainer);

        Scene scene = new Scene(root, 640, 720);
        scene.getStylesheets().add(AdoptionCheckForm.class.getResource("adoption-check.css").toExternalForm());
        stage.setScene(scene);
        stage.showAndWait();
    }

    /** image_url/ image_data를 안전하게 Image로 변환 */
    private Image resolveImage(ImageDTO img) {
        if (img == null) return null;
        try {
            String url = img.getImageUrl();
            if (url != null && !url.trim().isEmpty()) {
                String u = url.trim();
                if (u.startsWith("http://") || u.startsWith("https://") || u.startsWith("file:")) {
                    return new Image(u, true);
                }
                File f = new File(u);
                if (f.exists()) {
                    return new Image(f.toURI().toString(), true);
                }
                try {
                    String guess = Paths.get(u).toUri().toString();
                    return new Image(guess, true);
                } catch (Exception ignore) {}
                return new Image("file:" + u, true);
            } else if (img.getImageData() != null && img.getImageData().length > 0) {
                return new Image(new ByteArrayInputStream(img.getImageData()));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
