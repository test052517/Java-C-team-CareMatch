package application;

import DAO.AnimalsDAO;
import DAO.ImageDAO;
import DAO.ShelterDAO;
import DAO.SpeciesDAO;
import DTO.AnimalsDTO;
import DTO.ImageDTO;
import DTO.ShelterDTO;
import DTO.SpeciesDTO;
import DB.DBConnect;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.scene.text.Font;
import javafx.stage.Modality;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class ManagerDataRegistrationForm {

    // 데이터 리스트
    private List<SpeciesDTO> allSpecies;
    private List<ShelterDTO> allShelters;

    // UI 컴포넌트
    private ImageView imageView;
    private File selectedImageFile;
    private TextField nameField;
    private TextField ageField;
    private TextField weightField;
    private ComboBox<String> speciesCombo;
    private ComboBox<String> kindCombo;
    private ComboBox<String> statusCombo;
    private ComboBox<String> genderCombo;
    private ComboBox<String> neuteredCombo;
    private DatePicker shelterDatePicker;
    private ComboBox<String> shelterCombo;

    public void show(Stage stage) {
        SpeciesDAO speciesDAO = new SpeciesDAO();
        allSpecies = speciesDAO.findAllSpecies();
        ShelterDAO shelterDAO = new ShelterDAO();
        allShelters = shelterDAO.findAllShelters();

        Font.loadFont(getClass().getResource("/resources/Pretendard-Medium.ttf").toExternalForm(), 12);
        Font.loadFont(getClass().getResource("/resources/Pretendard-Bold.ttf").toExternalForm(), 12);
        Font.loadFont(getClass().getResource("/resources/Pretendard-ExtraBold.ttf").toExternalForm(), 12);

        BorderPane root = new BorderPane();
        root.setPadding(new Insets(20));
        root.getStyleClass().add("root");

        // 상단: 이미지 선택 UI
        imageView = new ImageView();
        imageView.setFitHeight(150);
        imageView.setFitWidth(150);
        imageView.setPreserveRatio(true);
        imageView.setStyle("-fx-border-color: lightgray; -fx-border-width: 1;");

        Button selectImageButton = new Button("이미지 선택");
        selectImageButton.getStyleClass().add("Form-button");

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("이미지 선택");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif")
        );

        selectImageButton.setOnAction(e -> {
            File selectedFile = fileChooser.showOpenDialog(stage);
            if (selectedFile != null) {
                this.selectedImageFile = selectedFile;
                Image image = new Image(selectedFile.toURI().toString());
                imageView.setImage(image);
            }
        });

        VBox imageSelectionBox = new VBox(10, imageView, selectImageButton);
        imageSelectionBox.setAlignment(Pos.CENTER);
        imageSelectionBox.setPadding(new Insets(0, 0, 20, 0));


        HBox formContainer = new HBox(30);
        formContainer.setAlignment(Pos.CENTER);

        VBox leftPane = new VBox(20);
        VBox rightPane = new VBox(20);

        leftPane.setMaxWidth(315);
        rightPane.setMaxWidth(315);

        formContainer.getChildren().addAll(leftPane, rightPane);

        initializeFields();

        VBox group1 = createFormField("이름", nameField);
        VBox group2 = createFormField("나이", ageField);
        VBox group3 = createFormField("무게", weightField);
        VBox groupSpecies = createFormField("종", speciesCombo);
        VBox groupKind = createFormField("품종", kindCombo);
        VBox groupStatus = createFormField("상태 여부", statusCombo);
        VBox group4 = createFormField("성별", genderCombo);
        VBox group5 = createFormField("중성화 여부", neuteredCombo);
        VBox group6 = createFormField("보호소 입소 일자", shelterDatePicker);
        VBox groupShelter = createFormField("보호소", shelterCombo);

        leftPane.getChildren().addAll(group1, group2, groupSpecies, group5, groupStatus);
        rightPane.getChildren().addAll(group6, group3, groupKind, group4, groupShelter);

        speciesCombo.valueProperty().addListener((obs, oldVal, newVal) -> {
            kindCombo.getItems().clear();
            if (newVal != null) {
                List<String> kindNames = allSpecies.stream()
                        .filter(s -> newVal.equals(s.getTypeName()))
                        .map(DTO.SpeciesDTO::getKindName)
                        .collect(Collectors.toList());
                kindCombo.getItems().addAll(kindNames);
                kindCombo.setDisable(false);
                kindCombo.setPromptText("선택");
            } else {
                kindCombo.setDisable(true);
                kindCombo.setPromptText("먼저 '종'을 선택해주세요");
            }
        });

        Button submitButton = new Button("입양 동물 추가");
        submitButton.getStyleClass().add("Form-button");
        submitButton.setOnAction(e -> handleSubmit());

        HBox buttonBox = new HBox(submitButton);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.getStyleClass().add("button-container");

        root.setTop(imageSelectionBox);
        root.setCenter(formContainer);
        root.setBottom(buttonBox);
        BorderPane.setAlignment(buttonBox, Pos.CENTER);

        Scene scene = new Scene(root, 700, 800);
        scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());

        stage.setTitle("입양 동물 등록");
        stage.setScene(scene);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.show();
    }

    private void handleSubmit() {
        // 1. 입력값 유효성 검사
        if (!validateInputs()) {
            return;
        }

        Connection conn = null;
        String imageId = UUID.randomUUID().toString();

        try {
            // 2. DB 커넥션을 얻고 트랜잭션 시작 (AutoCommit 비활성화)
            conn = DBConnect.getConnection();
            conn.setAutoCommit(false);

            // 3. 이미지 파일을 byte 배열(BLOB)로 읽어오기
            byte[] imageData = Files.readAllBytes(selectedImageFile.toPath());
            // ImageDTO 생성 시 imageUrl은 null, imageData에 byte 배열을 전달
            ImageDTO newImage = new ImageDTO(imageId, null, imageData);

            // 4. DAO 객체 생성
            ImageDAO imageDAO = new ImageDAO();
            AnimalsDAO animalsDAO = new AnimalsDAO();

            // 5. 트랜잭션 안에서 DAO 메서드 호출
            // (1) 이미지 추가 (Connection 객체를 넘겨주는 트랜잭션용 메서드 사용)
            if (!imageDAO.addImage(newImage, conn)) {
                throw new SQLException("이미지 저장에 실패했습니다.");
            }

            // (2) 동물 정보 DTO 생성
            AnimalsDTO newAnimal = new AnimalsDTO();
            newAnimal.setAnimalId(UUID.randomUUID().toString());
            newAnimal.setAnimalName(nameField.getText());
            newAnimal.setAge(Integer.parseInt(ageField.getText()));
            newAnimal.setWeight(Double.parseDouble(weightField.getText()));

            String sex;
            switch (genderCombo.getValue()) {
                case "수컷": sex = "M"; break;
                case "암컷": sex = "F"; break;
                default: sex = "Q";
            }
            newAnimal.setSex(sex);

            String neutered;
            switch (neuteredCombo.getValue()) {
                case "예": neutered = "Y"; break;
                case "아니오": neutered = "N"; break;
                default: neutered = "U";
            }
            newAnimal.setNeutered(neutered);
            
            newAnimal.setStatus(statusCombo.getValue());
            newAnimal.setHappenDate(Date.valueOf(shelterDatePicker.getValue()));

            String selectedType = speciesCombo.getValue();
            String selectedKind = kindCombo.getValue();
            String kindId = allSpecies.stream()
                .filter(s -> selectedType.equals(s.getTypeName()) && selectedKind.equals(s.getKindName()))
                .map(DTO.SpeciesDTO::getKindId)
                .findFirst()
                .orElse(null);
            newAnimal.setKindId(kindId);

            String selectedShelterName = shelterCombo.getValue();
            String shelterId = allShelters.stream()
                .filter(s -> selectedShelterName.equals(s.getShelterName()))
                .map(ShelterDTO::getShelterId)
                .findFirst()
                .orElse(null);

            if (kindId == null || shelterId == null) {
                throw new SQLException("품종 또는 보호소 ID를 찾을 수 없습니다.");
            }
            newAnimal.setShelterId(shelterId);
            newAnimal.setImageId(imageId);
            // applicantId는 설정하지 않으므로 DTO의 기본값(0 또는 null)이 사용됨

            // (3) 동물 정보 추가 (Connection 객체를 넘겨주는 트랜잭션용 메서드 사용)
            if (!animalsDAO.addAnimal(newAnimal, conn)) {
                throw new SQLException("동물 정보 저장에 실패했습니다.");
            }

            // 6. 모든 작업이 성공했으면 commit
            conn.commit();
            showAlert(Alert.AlertType.INFORMATION, "등록 성공", "동물 정보가 성공적으로 등록되었습니다.");
            Stage stage = (Stage) imageView.getScene().getWindow();
            stage.close();

        } catch (Exception e) {
            // 7. 중간에 오류가 발생하면 rollback
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            // 오류 로그를 더 자세히 출력
            System.err.println("===== 트랜잭션 오류 발생: 상세 정보 =====");
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "DB 오류", "데이터 저장 중 오류가 발생했습니다: " + e.getMessage());

        } finally {
            // 8. 작업이 끝나면 커넥션 정리
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    private void initializeFields() {
        nameField = new TextField();
        ageField = new TextField();
        weightField = new TextField();
        
        speciesCombo = new ComboBox<>();
        List<String> typeNames = allSpecies.stream()
                .map(DTO.SpeciesDTO::getTypeName)
                .distinct()
                .collect(Collectors.toList());
        speciesCombo.getItems().addAll(typeNames);
        speciesCombo.setPromptText("선택");

        kindCombo = new ComboBox<>();
        kindCombo.setPromptText("먼저 '종'을 선택해주세요");
        kindCombo.setDisable(true);

        statusCombo = new ComboBox<>();
        statusCombo.getItems().addAll("보호중", "입양가능", "치료중");
        statusCombo.setPromptText("선택");

        genderCombo = new ComboBox<>();
        genderCombo.getItems().addAll("수컷", "암컷", "미상");
        genderCombo.setPromptText("선택");

        neuteredCombo = new ComboBox<>();
        neuteredCombo.getItems().addAll("예", "아니오", "알 수 없음");
        neuteredCombo.setPromptText("선택");
        
        shelterDatePicker = new DatePicker();
        
        shelterCombo = new ComboBox<>();
        List<String> shelterNames = allShelters.stream()
                .map(ShelterDTO::getShelterName)
                .collect(Collectors.toList());
        shelterCombo.getItems().addAll(shelterNames);
        shelterCombo.setPromptText("선택");

        setFieldsMaxWidth(nameField, ageField, weightField, speciesCombo, kindCombo,
                statusCombo, genderCombo, neuteredCombo, shelterDatePicker, shelterCombo);
    }
    
    private boolean validateInputs() {

        boolean isAnyFieldEmpty = selectedImageFile == null ||
                nameField.getText().trim().isEmpty() ||
                ageField.getText().trim().isEmpty() ||
                weightField.getText().trim().isEmpty() ||
                speciesCombo.getValue() == null ||
                kindCombo.getValue() == null ||
                statusCombo.getValue() == null ||
                genderCombo.getValue() == null ||
                neuteredCombo.getValue() == null ||
                shelterDatePicker.getValue() == null ||
                shelterCombo.getValue() == null;

        if (isAnyFieldEmpty) {
            showAlert(Alert.AlertType.WARNING, "입력 오류", "모든 항목을 채워주세요");
            return false;
        }

        try {
            Integer.parseInt(ageField.getText());
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.WARNING, "입력 오류", "나이에는 정수만 입력해주세요");
            return false;
        }

        try {
            Double.parseDouble(weightField.getText());
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.WARNING, "입력 오류", "무게에는 숫자만 입력해주세요");
            return false;
        }

        return true;
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(alertType);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }

    private VBox createFormField(String labelText, Control control) {
        Label label = new Label(labelText);
        label.getStyleClass().add("Form-label");
        if (control instanceof ComboBox) {
            control.getStyleClass().add("combo-box2");
        }
        return new VBox(2, label, control);
    }

    private void setFieldsMaxWidth(Control... controls) {
        for (Control control : controls) {
            if (control instanceof Region) {
                ((Region) control).setMaxWidth(Double.MAX_VALUE);
            }
        }
    }
}