package application;

import DTO.UserDTO;

/**
 * 로그인한 사용자 정보를 애플리케이션 전체에서 공유하기 위한 싱글턴(Singleton) 클래스입니다.
 */
public class SessionManager {

    // 1. 단 하나의 인스턴스를 저장하기 위한 정적(static) 변수
    private static SessionManager instance;

    // 2. 로그인한 사용자의 정보를 담을 변수
    private UserDTO loggedInUser;

    // 3. 외부에서 new 키워드로 객체를 생성하지 못하도록 private 생성자
    private SessionManager() { }

    /**
     * SessionManager의 유일한 인스턴스를 반환합니다.
     * @return SessionManager 인스턴스
     */
    public static SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }

    /**
     * 로그인 성공 시 사용자 정보를 세션에 저장하는 메서드입니다.
     * @param user 로그인한 사용자의 UserDTO 객체
     */
    public void setLoggedInUser(UserDTO user) {
        this.loggedInUser = user;
    }

    /**
     * 현재 로그인된 사용자의 정보를 반환합니다.
     * @return 로그인된 UserDTO 객체, 없으면 null
     */
    public UserDTO getLoggedInUser() {
        return this.loggedInUser;
    }

    /**
     * 현재 로그인된 사용자의 ID를 반환합니다.
     * @return 로그인된 사용자의 ID, 없으면 0
     */
    public int getLoggedInUserId() {
        return (loggedInUser != null) ? loggedInUser.getUserId() : 0;
    }

    /**
     * 로그아웃 시 세션에 저장된 사용자 정보를 삭제합니다.
     */
    public void logout() {
        this.loggedInUser = null;
    }
}