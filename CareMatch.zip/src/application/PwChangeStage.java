package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

// ★ DAO 패키지의 클래스명은 UserDAO 여야 합니다.
import DAO.UserDAO;

public class PwChangeStage extends Stage {

    private boolean emailVerifiedOK = false;

    public PwChangeStage() {
        setTitle("CareMatch - 비밀번호 변경");

        VBox root = new VBox(16);
        root.setPadding(new Insets(24, 28, 28, 28));
        root.getStyleClass().add("root-pane");

        // 아이디
        Label idLbl = new Label("아이디");
        idLbl.getStyleClass().add("text-label");
        TextField idField = new TextField();
        idField.setPromptText("아이디 입력(6~20자)");
        idField.getStyleClass().add("input-field");

        // 이메일 + 인증
        Label emailLbl = new Label("이메일 주소");
        emailLbl.getStyleClass().add("text-label");

        HBox emailRow = new HBox(8);
        TextField emailField = new TextField();
        emailField.setPromptText("이메일 주소");
        emailField.getStyleClass().add("input-field");
        Button sendCodeBtn = new Button("인증번호 받기");
        sendCodeBtn.getStyleClass().add("minor-button");
        emailRow.getChildren().addAll(emailField, sendCodeBtn);
        HBox.setHgrow(emailField, Priority.ALWAYS);

        Label codeLbl = new Label("인증번호 입력");
        codeLbl.getStyleClass().add("text-label");

        HBox codeRow = new HBox(8);
        TextField codeField = new TextField();
        codeField.setPromptText("인증번호 입력");
        codeField.getStyleClass().add("input-field");
        Button verifyBtn = new Button("인증번호 확인");
        verifyBtn.getStyleClass().add("minor-button");
        codeRow.getChildren().addAll(codeField, verifyBtn);
        HBox.setHgrow(codeField, Priority.ALWAYS);

        // 새 비밀번호
        Label pwLbl = new Label("새 비밀번호");
        pwLbl.getStyleClass().add("text-label");
        PasswordField pwField = new PasswordField();
        pwField.setPromptText("••••••••");
        pwField.getStyleClass().add("input-field");

        // 새 비밀번호 아래 안내 문구
        Label pwHint = new Label("20자 이내로 비밀번호를 입력해주세요.");
        pwHint.getStyleClass().add("warn-text"); // 기본은 경고(빨강)

        // 비밀번호 확인
        Label pw2Lbl = new Label("비밀번호 확인");
        pw2Lbl.getStyleClass().add("text-label");
        PasswordField pw2Field = new PasswordField();
        pw2Field.setPromptText("••••••••");
        pw2Field.getStyleClass().add("input-field");

        // 비밀번호 확인 아래 안내 문구
        Label pw2Hint = new Label("");
        pw2Hint.getStyleClass().add("warn-text");

        Button changeBtn = new Button("비밀번호 변경");
        changeBtn.getStyleClass().add("primary-button");
        changeBtn.setMaxWidth(Double.MAX_VALUE);

        // ===== 인증번호 발송 (requestCode는 void)
        sendCodeBtn.setOnAction(e -> {
            String email = emailField.getText().trim();
            if (email.isEmpty()) {
                alert("이메일을 채워주세요");
                emailField.requestFocus();
                return;
            }
            try {
                EmailVerificationService svc = new EmailVerificationService();
                svc.requestCode(null, email); // 반환값 없음
                alertInfo("인증번호를 발송했습니다.");
            } catch (Exception ex) {
                ex.printStackTrace();
                alert("인증번호 발송 중 오류가 발생했습니다.");
            }
        });

        // 인증번호 확인
        verifyBtn.setOnAction(e -> {
            String email = emailField.getText().trim();
            String code = codeField.getText().trim();
            if (email.isEmpty()) { alert("이메일을 채워주세요"); emailField.requestFocus(); return; }
            if (code.isEmpty()) { alert("인증번호를 채워주세요"); codeField.requestFocus(); return; }
            try {
                EmailVerificationService svc = new EmailVerificationService();
                boolean ok = svc.verifyCode(null, email, code);
                emailVerifiedOK = ok;
                if (ok) alertInfo("이메일 인증이 완료되었습니다.");
                else alert("인증번호가 올바르지 않습니다.");
            } catch (Exception ex) {
                ex.printStackTrace();
                alert("인증 확인 중 오류가 발생했습니다.");
            }
        });

        // ===== 비번 길이/일치 실시간 검증 =====
        pwField.textProperty().addListener((obs, o, n) -> {
            boolean ok = n != null && n.length() >= 1 && n.length() <= 20;
            pwHint.setText(ok ? "가능한 비밀번호입니다." : "20자 이내로 비밀번호를 입력해주세요.");
            pwHint.getStyleClass().removeAll("good-text", "warn-text");
            pwHint.getStyleClass().add(ok ? "good-text" : "warn-text");

            // 확인 필드까지 입력된 경우, 일치 여부도 즉시 갱신
            String n2 = pw2Field.getText();
            if (n2 != null && !n2.isEmpty()) {
                boolean same = ok && n.equals(n2);
                pw2Hint.setText(same ? "비밀번호가 일치합니다." : "비밀번호가 일치하지 않습니다.");
                pw2Hint.getStyleClass().removeAll("good-text", "warn-text");
                pw2Hint.getStyleClass().add(same ? "good-text" : "warn-text");
            } else {
                pw2Hint.setText("");
                pw2Hint.getStyleClass().removeAll("good-text", "warn-text");
                pw2Hint.getStyleClass().add("warn-text");
            }
        });

        pw2Field.textProperty().addListener((obs, o, n) -> {
            String a = pwField.getText() == null ? "" : pwField.getText();
            boolean aOk = !a.isEmpty() && a.length() <= 20;
            if (n == null || n.isEmpty()) {
                pw2Hint.setText("");
                pw2Hint.getStyleClass().removeAll("good-text", "warn-text");
                pw2Hint.getStyleClass().add("warn-text");
            } else {
                boolean same = aOk && a.equals(n);
                pw2Hint.setText(same ? "비밀번호가 일치합니다." : "비밀번호가 일치하지 않습니다.");
                pw2Hint.getStyleClass().removeAll("good-text", "warn-text");
                pw2Hint.getStyleClass().add(same ? "good-text" : "warn-text");
            }
        });

        // ===== 변경 버튼
        changeBtn.setOnAction(e -> {
            String id = idField.getText().trim();
            String pw = pwField.getText();
            String pw2 = pw2Field.getText();

            if (id.isEmpty()) { alert("아이디를 채워주세요"); idField.requestFocus(); return; }
            if (!emailVerifiedOK) { alert("이메일 인증을 완료해주세요"); return; }
            if (pw == null || pw.isEmpty() || pw.length() > 20) {
                alert("새 비밀번호를 채워주세요 (1~20자)"); pwField.requestFocus(); return;
            }
            if (!pw.equals(pw2)) { alert("비밀번호가 일치하지 않습니다."); pw2Field.requestFocus(); return; }

            UserDAO dao = new UserDAO();
            boolean ok = dao.updatePasswordByLoginId(id, pw);
            if (ok) {
                alertInfo("비밀번호가 변경되었습니다.");
                close();
            } else {
                alert("비밀번호 변경 중 오류가 발생했습니다.");
            }
        });

        // 레이아웃
        root.getChildren().addAll(
            idLbl, idField,
            emailLbl, emailRow,
            codeLbl, codeRow,
            pwLbl, pwField, pwHint,
            pw2Lbl, pw2Field, pw2Hint,
            changeBtn
        );

        Scene scene = new Scene(root, 520, 620);
        scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
        setScene(scene);
        setResizable(false);
    }

    private void alert(String msg) {
        Alert a = new Alert(AlertType.ERROR);
        a.setTitle("입력 오류");
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }
    private void alertInfo(String msg) {
        Alert a = new Alert(AlertType.INFORMATION);
        a.setTitle("안내");
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }
}
