package application;

import DTO.AnimalsDTO;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class AnimalCard extends HBox {
    private AnimalsDTO animal;
    private ImageView imageView;
    private ManagerMainList mainView; // ✨ ManagerMainList의 참조를 저장할 변수

    /**
     * ✨ 생성자 수정
     * ManagerMainList의 참조(mainView)를 추가로 전달받습니다.
     */
    public AnimalCard(AnimalsDTO animal, ManagerMainList mainView, int userId) {
        this.animal = animal;
        this.mainView = mainView; // ✨ 전달받은 참조를 저장
        this.getStyleClass().add("animal-card");
        this.setSpacing(20);

        // 이미지 자리 (초기엔 placeholder)
        imageView = new ImageView("file:resources/img_placeholder.png");
        imageView.setFitWidth(150);
        imageView.setFitHeight(150);
        imageView.setPreserveRatio(true);
        imageView.setStyle("-fx-background-color: #ddd; -fx-border-radius: 8;");

        // 동물 정보 텍스트 영역
        VBox textBox = new VBox(5);
        textBox.setAlignment(Pos.CENTER_LEFT);

        Label nameLabel = new Label(animal.getAnimalName());
        nameLabel.getStyleClass().add("card-title");

        Label typeLabel = new Label("종: " + animal.getKindName());
        Label ageLabel = new Label("나이: " + animal.getAge() + "세");
        Label weightLabel = new Label("무게: " + animal.getWeight() + "kg");
        Label genderLabel = new Label("성별: " + animal.getSex());
        Label neuteredLabel = new Label("중성화: " + ("Y".equalsIgnoreCase(animal.getNeutered()) ? "O" : "X"));
        Label dateLabel = new Label("입소일: " + animal.getHappenDate().toString());

        typeLabel.getStyleClass().add("card-info");
        ageLabel.getStyleClass().add("card-info");
        weightLabel.getStyleClass().add("card-info");
        genderLabel.getStyleClass().add("card-info");
        neuteredLabel.getStyleClass().add("card-info");
        dateLabel.getStyleClass().add("card-info");

        textBox.getChildren().addAll(
            nameLabel, typeLabel, ageLabel, weightLabel,
            genderLabel, neuteredLabel, dateLabel
        );

        // 우측 상태 변경 드롭다운
        ComboBox<String> statusDropdown = new ComboBox<>();
        // ✨ 데이터베이스와 일관된 상태 값으로 변경
        statusDropdown.setItems(FXCollections.observableArrayList("보호중", "입양가능", "입양완료", "안락사"));
        statusDropdown.setValue(animal.getStatus());
        statusDropdown.getStyleClass().add("combo-box");

        // ✨ ComboBox 이벤트 핸들러 수정
        statusDropdown.setOnAction(e -> {
            String selectedStatus = statusDropdown.getValue();
            // 새로운 값이 선택되었고, 기존 값과 다를 경우에만 서버에 요청
            if (selectedStatus != null && !selectedStatus.equals(animal.getStatus())) {
                // ManagerMainList의 메서드를 호출하여 서버에 업데이트를 요청합니다.
                mainView.requestAnimalStatusUpdate(animal.getAnimalId(), selectedStatus);
            }
        });

        VBox statusBox = new VBox(statusDropdown);
        statusBox.setAlignment(Pos.TOP_RIGHT);
        HBox.setHgrow(statusBox, Priority.ALWAYS);

        this.getChildren().addAll(imageView, textBox, statusBox);
    }

    public String getImageId() {
        return animal.getImageId();
    }

    // Image 객체를 직접 받아 이미지를 업데이트하는 메서드
    public void updateImage(Image image) {
        if (image == null) {
            // 이미지가 로드되지 않았을 경우를 대비해 placeholder를 유지
            imageView.setImage(new Image("file:resources/img_placeholder.png"));
            return;
        }

        Platform.runLater(() -> {
            imageView.setImage(image);
        });
    }

    // ✨ AnimalListView에서 AnimalCard 목록을 가져오기 위한 public getter 추가
    public AnimalsDTO getAnimal() {
        return animal;
    }
}