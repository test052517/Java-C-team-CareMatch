package application;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.geometry.Pos;
import DTO.ReviewDTO;
import DTO.SpeciesDTO;
import DTO.UserDTO; // ✅ 추가
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import DAO.ReviewImageDAO;
import DTO.ReviewImageDTO;
import java.io.ByteArrayInputStream;
import javafx.stage.Stage;
import java.text.SimpleDateFormat;
import java.util.stream.Collectors;
import javafx.scene.control.ComboBox;

public class ReviewPageView {

    private ScrollPane scrollPane;
    private GridPane reviewGrid;
    private Stage stage;
    private List<ReviewDTO> reviewList;

    private UserDTO currentUser; // ✅ 추가

    // ✅ 기본 생성자
    public ReviewPageView() {
        this(new Stage(), null, new ComboBox<>(), new ComboBox<>());
    }

    // ✅ UserDTO만 받는 생성자 (요청하신 시그니처)
    public ReviewPageView(UserDTO currentUser) {
        this(new Stage(), currentUser, new ComboBox<>(), new ComboBox<>());
    }

    // 기존 시그니처 유지 (Stage, ComboBox*2)
    public ReviewPageView(Stage stage, ComboBox<String> animalType, ComboBox<String> breedType) {
        this(stage, null, animalType, breedType);
    }

    // ✅ 확장: Stage + UserDTO + ComboBox*2
    public ReviewPageView(Stage stage, UserDTO currentUser, ComboBox<String> animalType, ComboBox<String> breedType) {
        this.stage = stage;
        this.currentUser = currentUser;

        reviewGrid = new GridPane();
        reviewGrid.setHgap(30);
        reviewGrid.setVgap(20);
        reviewGrid.setPadding(new Insets(20));
        reviewGrid.setId("reviewGrid");

        // 서버에서 전체 리뷰 로드
        connectToServerAndLoadReviews();

        scrollPane = new ScrollPane(reviewGrid);
        scrollPane.setClip(null);
        scrollPane.setFitToWidth(true);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scrollPane.setPrefHeight(600);
        scrollPane.setId("scrollPane");
    }

    // 서버 통신
    private void connectToServerAndLoadReviews() {
        new Thread(() -> {
            try (Socket socket = new Socket("localhost", 9999);
                 PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                 BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

                // 필요 시 사용자 기준 필터가 있다면 프로토콜에 맞게 변경하세요.
                // 예: out.println("GET_REVIEWS:" + (currentUser != null ? currentUser.getUserId() : ""));
                out.println("GET_REVIEWS");

                String serverResponse = in.readLine();
                if (serverResponse != null) {
                    processServerResponse(serverResponse);
                } else {
                    Platform.runLater(() -> showErrorMessage("서버 응답 없음 (연결 오류)."));
                }
            } catch (Exception e) {
                System.err.println("서버 연결 또는 리뷰 로딩 중 오류: " + e.getMessage());
                Platform.runLater(() -> showErrorMessage("서버 통신 실패: " + e.getMessage()));
            }
        }).start();
    }

    // 서버 응답 처리
    private void processServerResponse(String response) {
        Platform.runLater(() -> {
            String[] parts = response.split(":", 2);
            String command = parts[0];
            String payload = parts.length > 1 ? parts[1] : "";

            if ("REVIEWS_LIST".equals(command)) {
                this.reviewList = parseReviewList(payload);
                displayReviews(this.reviewList);
            } else {
                showErrorMessage(response);
            }
        });
    }

    private List<ReviewDTO> parseReviewList(String payload) {
        List<ReviewDTO> reviews = new ArrayList<>();
        if (payload.isEmpty()) return reviews;

        String[] reviewStrings = payload.split("\\|");

        for (String reviewStr : reviewStrings) {
            String[] parts = reviewStr.split(",", -1);

            if (parts.length >= 12) {
                ReviewDTO review = new ReviewDTO();
                review.setReviewId(parts[0]);

                try {
                    review.setCreatedDate(Date.valueOf(parts[1]));
                } catch (IllegalArgumentException e) {
                    review.setCreatedDate(null);
                }

                review.setTitle(parts[2]);
                review.setContent(parts[3]);
                review.setImageId(parts[4]);

                try {
                    review.setLikeCount(Integer.parseInt(parts[5]));
                } catch (NumberFormatException e) {
                    review.setLikeCount(0);
                }

                review.setUserId(parts[6]);
                review.setAnimalId(parts[7]);

                review.setUserName(parts[8]);
                review.setAnimalName(parts[9]);

                SpeciesDTO species = new SpeciesDTO();
                species.setTypeName(parts[10]);
                species.setKindName(parts[11]);
                review.setSpeciesDTO(species);

                reviews.add(review);
            } else {
                System.err.println("리뷰 데이터 파싱 오류(필드 부족): " + reviewStr);
            }
        }
        return reviews;
    }

    private void displayReviews(List<ReviewDTO> reviews) {
        reviewGrid.getChildren().clear();
        if (reviews.isEmpty()) {
            showNoDataMessage();
            return;
        }

        int column = 0;
        int row = 0;
        for (ReviewDTO review : reviews) {
            VBox card = createReviewCard(review);
            reviewGrid.add(card, column, row);
            column++;
            if (column >= 4) {
                column = 0;
                row++;
            }
        }
    }

    private VBox createReviewCard(ReviewDTO review) {
        VBox card = new VBox(5);
        card.setPrefSize(240, 280);
        card.setAlignment(Pos.TOP_CENTER);
        card.setPadding(new Insets(10));
        card.getStyleClass().add("reviewCard");

        ImageView imageView = new ImageView();
        imageView.setFitWidth(180);
        imageView.setFitHeight(180);
        imageView.setPreserveRatio(false);
        try {
            ReviewImageDTO rimg = new ReviewImageDAO().findByReviewId(review.getReviewId());
            if (rimg != null && rimg.getImageData() != null && rimg.getImageData().length > 0) {
                imageView.setImage(new Image(new ByteArrayInputStream(rimg.getImageData())));
            } else {
                imageView.setImage(new Image(getClass().getResource("/resources/img_placeholder.png").toExternalForm()));
            }
        } catch (Exception ex) {
            imageView.setImage(new Image(getClass().getResource("/resources/img_placeholder.png").toExternalForm()));
        }

        Label titleLabel = new Label(review.getTitle());
        titleLabel.getStyleClass().add("reviewTitle");
        titleLabel.setWrapText(true);

        String dateStr;
        if (review.getCreatedDate() != null) {
            try {
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd");
                dateStr = dateFormat.format(review.getCreatedDate());
            } catch (Exception e) {
                dateStr = review.getCreatedDate().toString().substring(0, 10).replace("-", ".");
            }
        } else {
            dateStr = "날짜정보없음";
        }

        Label infoLabel = new Label((review.getUserName() != null ? review.getUserName() : "작성자") + " " + dateStr);
        infoLabel.getStyleClass().add("reviewInfo");

        card.getChildren().addAll(imageView, titleLabel, infoLabel);
        card.setAlignment(Pos.CENTER);

        card.setOnMouseClicked(e -> {
            System.out.println("선택된 리뷰 ID: " + review.getReviewId());
            ReviewDetailForm rdf = new ReviewDetailForm(review);
            rdf.showModal(stage);
        });
        return card;
    }

    private void showNoDataMessage() {
        VBox noDataBox = new VBox();
        noDataBox.setAlignment(Pos.CENTER);
        noDataBox.setPadding(new Insets(50));
        Label message = new Label("아직 등록된 후기가 없습니다.");
        noDataBox.getChildren().add(message); // ✅ 실제로 추가
        reviewGrid.getChildren().add(noDataBox);
    }

    private void showErrorMessage(String response) {
        VBox errorBox = new VBox();
        errorBox.setAlignment(Pos.CENTER);
        errorBox.setPadding(new Insets(50));
        Label message = new Label("데이터를 불러오는 중 오류가 발생했습니다.\n" + response);
        errorBox.getChildren().add(message); // ✅ 실제로 추가
        reviewGrid.getChildren().add(errorBox);
    }

    public ScrollPane getContent() {
        return scrollPane;
    }
}
