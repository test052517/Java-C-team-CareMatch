package application;

import DAO.AdoptionManagementDAO; // AdoptionManagementDAO 임포트
import DTO.AdoptionDTO;           // AdoptionDTO 임포트
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ManagerAdoptionApplicationForm {

    // show 메서드의 파라미터를 AdoptionDTO 객체와 Runnable로 변경
    public void show(AdoptionDTO adoption, Runnable refreshAction) {
        Font.loadFont(getClass().getResource("/resources/Pretendard-Medium.ttf").toExternalForm(), 12);
        Font.loadFont(getClass().getResource("/resources/Pretendard-Bold.ttf").toExternalForm(), 12);
        Font.loadFont(getClass().getResource("/resources/Pretendard-ExtraBold.ttf").toExternalForm(), 12);

        Stage stage = new Stage();
        stage.setTitle("입양 신청서 확인");

        VBox root = new VBox(20);
        root.setPadding(new Insets(20));
        root.getStyleClass().add("root");

        // --- DTO 객체에서 정보 추출하여 UI 필드 설정 ---
        // 동물 이름
        Label nameLabel = new Label("동물 이름");
        TextField nameField = new TextField(adoption.getAnimalName());
        nameLabel.getStyleClass().add("Form-label");
        VBox group1 = new VBox(2, nameLabel, nameField);
        nameField.setDisable(true);

        // 신청인 (사용자 이름이 필요하다면 AdoptionDAO의 JOIN 쿼리 수정 필요)
        Label applicantLabel = new Label("입양 신청인 ID");
        TextField applicantField = new TextField(String.valueOf(adoption.getUserId()));
        applicantLabel.getStyleClass().add("Form-label");
        VBox group2 = new VBox(2, applicantLabel, applicantField);
        applicantField.setDisable(true);

        // 신청일
        Label applyDateLabel = new Label("입양 신청일");
        DatePicker applyDatePicker = new DatePicker(adoption.getSubmittedDate());
        applyDateLabel.getStyleClass().add("Form-label");
        VBox group3 = new VBox(2, applyDateLabel, applyDatePicker);
        applyDatePicker.setDisable(true);

        // 사유
        Label reasonLabel = new Label("입양 사유");
        TextArea reasonArea = new TextArea(adoption.getAnimalReason());
        reasonArea.setPrefRowCount(8);
        reasonArea.setMinHeight(220);
        reasonArea.setWrapText(true);
        reasonLabel.getStyleClass().add("Form-label");
        VBox group4 = new VBox(2, reasonLabel, reasonArea);
        reasonArea.setDisable(true);

        // --- 버튼 기능 활성화 (AdoptionManagementDAO 사용) ---
        Button approveButton = new Button("입양 승인");
        Button rejectButton = new Button("입양 거절");
        approveButton.getStyleClass().add("Orange-Btn-Form");
        rejectButton.getStyleClass().add("Brown-Btn-Form");

        AdoptionManagementDAO managementDAO = new AdoptionManagementDAO();

        // '입양 승인' 버튼 클릭 이벤트
        approveButton.setOnAction(e -> {
            boolean success = managementDAO.approveAdoption(adoption.getApplicationId(), adoption.getAnimalId());
            if (success) {
                showAlert("성공", "입양 승인 처리가 완료되었습니다.");
                refreshAction.run(); // 목록 새로고침
                stage.close();       // 현재 창 닫기
            } else {
                showAlert("오류", "데이터베이스 처리 중 오류가 발생했습니다.");
            }
        });

        // '입양 거절' 버튼 클릭 이벤트
        rejectButton.setOnAction(e -> {
            boolean success = managementDAO.rejectAdoption(adoption.getApplicationId(), adoption.getAnimalId());
            if (success) {
                showAlert("성공", "입양 거절 처리가 완료되었습니다.");
                refreshAction.run(); // 목록 새로고침
                stage.close();       // 현재 창 닫기
            } else {
                showAlert("오류", "데이터베이스 처리 중 오류가 발생했습니다.");
            }
        });

        HBox buttonBox = new HBox(120, approveButton, rejectButton);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.getStyleClass().add("button-container");

        applyDatePicker.setMaxWidth(Double.MAX_VALUE);

        root.getChildren().addAll(group1, group2, group3, group4, buttonBox);

        Scene scene = new Scene(root, 450, 650);
        scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());

        stage.setScene(scene);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.show();
    }

    // 사용자에게 피드백을 주기 위한 간단한 알림창 메서드
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}