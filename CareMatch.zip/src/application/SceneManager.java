package application;

import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.util.HashMap;
import java.util.function.Supplier;

public class SceneManager {
    private static Stage primaryStage;
    private static final HashMap<String, Supplier<Pane>> viewSuppliers = new HashMap<>();
    private static Scene scene;

    public static void setStage(Stage stage) {
        primaryStage = stage;
    }

    public static void registerView(String name, Supplier<Pane> supplier) {
        viewSuppliers.put(name, supplier);
    }

    public static void switchTo(String name) {
        if (!viewSuppliers.containsKey(name)) {
            throw new IllegalArgumentException("View not registered: " + name);
        }

        Pane rootPane = viewSuppliers.get(name).get();

        if (scene == null) {
            scene = new Scene(rootPane, 800, 950);
            scene.getStylesheets().add(
                SceneManager.class.getResource("style.css").toExternalForm()
            );
            if (primaryStage != null) primaryStage.setScene(scene);
        } else {
            scene.setRoot(rootPane);
        }
    }

    /** (선택) 현재 Scene만 버림 — 뷰 등록은 유지 */
    public static void resetScene() {
        scene = null;
    }

    /** (선택) 완전 초기화 — Scene과 등록된 뷰를 모두 초기화 */
    public static void resetAll() {
        scene = null;
        viewSuppliers.clear();
    }

    /** 같은 Stage에서 로그인 화면으로 복귀 */
    public static void goLogin() {
        if (primaryStage == null) return;

        // 캐시 리셋(흰 화면/고아 Scene 방지)
        resetAll();

        try {
            new Main().start(primaryStage);  // 로그인 화면 올리기
            primaryStage.setResizable(false);
            primaryStage.centerOnScreen();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /** 지금 Stage를 외부에서 써야 할 때 */
    public static Stage getStage() {
        return primaryStage;
    }
}
