package application;

import DTO.ReviewDTO;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.lang.reflect.Method;

/** 목록 카드 – CSS 스타일에 맡기고, 상세 진입 후 좋아요 수 갱신 */
public class ReviewCard extends VBox {

    private final ReviewDTO reviewDTO;
    private final Stage owner;
    private final String userId;

    public ReviewCard(ReviewDTO review, Stage owner, String currentUserId) {
        super(8);
        this.reviewDTO = review;
        this.owner = owner;
        this.userId = currentUserId != null ? currentUserId : CurrentUser.get();
        initUI();
    }
    public ReviewCard(ReviewDTO review) { this(review, null, CurrentUser.get()); }
    public ReviewCard(Object anyReview) { this(toDto(anyReview), null, CurrentUser.get()); }

    private void initUI() {
        setSpacing(8);
        setPadding(new Insets(12));
        setAlignment(Pos.TOP_CENTER);
        getStyleClass().add("review-card");
        setCursor(Cursor.HAND);

        ImageView thumbnail = new ImageView();
        thumbnail.setFitWidth(220);
        thumbnail.setFitHeight(180);
        thumbnail.setPreserveRatio(true);
        thumbnail.getStyleClass().add("review-thumbnail");

        Label title = new Label(reviewDTO.getTitle());
        title.setWrapText(true);
        title.getStyleClass().add("review-title");

        Label likeCountLabel = new Label();
        likeCountLabel.getStyleClass().add("review-like-count");

        getChildren().addAll(thumbnail, title, likeCountLabel);
        refreshLikeCount(likeCountLabel);

        setOnMouseClicked(e -> {
            new ReviewDetailForm(reviewDTO, userId).showModal(owner);
            refreshLikeCount(likeCountLabel);
        });
    }

    private void refreshLikeCount(Label lbl) {
        int cnt = LikeService.getLikeCount(reviewDTO.getReviewId());
        lbl.setText("♥ " + cnt);
    }

    private static ReviewDTO toDto(Object o) {
        if (o instanceof ReviewDTO) return (ReviewDTO) o;
        try {
            String reviewId = callString(o, "getReviewId");
            if (reviewId == null) reviewId = callString(o, "getId");

            String title = callString(o, "getTitle");
            String userName = callString(o, "getUserName");
            String userId = callString(o, "getUserId");
            String content = callString(o, "getContent");
            java.sql.Date created = callSqlDate(o, "getCreatedDate");

            final String _reviewId = reviewId;
            final String _title = title;
            final String _userName = userName;
            final String _userId = userId;
            final String _content = content;
            final java.sql.Date _created = created;

            return new ReviewDTO() {
                public String getReviewId(){ return _reviewId; }
                public String getTitle(){ return _title != null ? _title : ""; }
                public String getUserName(){ return _userName; }
                public String getUserId(){ return _userId; }
                public String getContent(){ return _content; }
                public java.sql.Date getCreatedDate(){ return _created; }
            };
        } catch (Exception ignore) {
            return new ReviewDTO() {
                public String getReviewId(){ return ""; }
                public String getTitle(){ return ""; }
                public String getUserName(){ return ""; }
                public String getUserId(){ return ""; }
                public String getContent(){ return ""; }
                public java.sql.Date getCreatedDate(){ return null; }
            };
        }
    }
    private static String callString(Object o, String name) {
        try { return String.valueOf(o.getClass().getMethod(name).invoke(o)); }
        catch (Exception e) { return null; }
    }
    private static java.sql.Date callSqlDate(Object o, String name) {
        try {
            Object v = o.getClass().getMethod(name).invoke(o);
            if (v instanceof java.sql.Date) return (java.sql.Date) v;
            if (v instanceof java.util.Date) return new java.sql.Date(((java.util.Date)v).getTime());
            return null;
        } catch (Exception e) { return null; }
    }
}