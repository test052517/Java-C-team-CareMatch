package server.controller;

import java.io.PrintWriter;

public interface Controller {
    void execute(String request, PrintWriter out);
}