package server.controller;

import DAO.AnimalsDAO;
import java.io.PrintWriter;

public class UpdateAnimalStatusController implements Controller {

    private final AnimalsDAO animalsDAO;

    public UpdateAnimalStatusController() {
        this.animalsDAO = new AnimalsDAO();
    }

    @Override
    public void execute(String request, PrintWriter out) {
        String[] parts = request.split(":", 2);
        if (parts.length < 2) {
            out.println("ERROR:Invalid update request format");
            return;
        }

        String[] params = parts[1].split(";", 2);
        if (params.length < 2) {
            out.println("ERROR:Missing parameters for update");
            return;
        }

        String animalId = params[0];
        String newStatus = params[1];

        boolean success = animalsDAO.updateAnimalStatus(animalId, newStatus);

        if (success) {
            System.out.println("동물 상태 변경 완료: ID=" + animalId + ", 상태=" + newStatus);
            out.println("STATUS_UPDATE_SUCCESS:" + animalId + ";" + newStatus);
        } else {
            System.err.println("동물 상태 변경 실패: ID=" + animalId);
            out.println("STATUS_UPDATE_FAILURE:Failed to update status for " + animalId);
        }
    }
}
