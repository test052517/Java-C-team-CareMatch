package server.controller;

import java.io.PrintWriter;
import java.util.List;
import java.sql.Date;

import DAO.ReviewDAO;
import DTO.ReviewDTO;

public class ReviewController implements Controller {

    // 데이터베이스 접근을 위한 ReviewDAO 인스턴스
    private final ReviewDAO reviewDAO;

    public ReviewController() {
        this.reviewDAO = new ReviewDAO();
    }

    @Override
    public void execute(String request, PrintWriter out) {
        String[] parts = request.split(":", 2);
        String command = parts[0];
        String data = parts.length > 1 ? parts[1] : "";

        try {
            switch (command) {
                // 모든 리뷰 목록을 요청할 때
                case "GET_REVIEWS":
                    handleGetAllReviews(out);
                    break;
                // 특정 리뷰 상세 정보를 요청할 때
                case "GET_REVIEW_DETAIL":
                    handleGetReviewDetail(data, out);
                    break;
                // 리뷰 삭제를 요청할 때
                case "DELETE_REVIEW":
                    handleDeleteReview(data, out);
                    break;
                // 새로운 리뷰를 추가할 때 (추가 예시)
                case "ADD_REVIEW":
                    handleAddReview(data, out);
                    break;
                // 정의되지 않은 명령어가 들어왔을 때
                default:
                    out.println("ERROR:Unknown command.");
                    break;
            }
        } catch (Exception e) {
            // 예기치 않은 오류 발생 시 에러 메시지 전송
            System.err.println("ReviewController 오류: " + e.getMessage());
            e.printStackTrace();
            out.println("ERROR:Review data processing failed.");
        }
    }

    private void handleGetAllReviews(PrintWriter out) {
        List<ReviewDTO> reviews = reviewDAO.findAllReviews();
        StringBuilder payload = new StringBuilder();

        for (ReviewDTO review : reviews) {
            if (payload.length() > 0) {
                payload.append("|");
            }

            // 쉼표가 포함된 필드는 제거하거나 치환
            String cleanTitle = review.getTitle() != null ? review.getTitle().replace(",", "") : "";
            String cleanContent = review.getContent() != null ? review.getContent().replace(",", "") : "";
            
            // 최종 페이로드 순서 (이 순서가 중요합니다)
            payload.append(String.join(",", 
                review.getReviewId(),
                review.getCreatedDate() != null ? review.getCreatedDate().toString() : "",
                cleanTitle,
                cleanContent, // ★ content 추가
                review.getImageId(),
                String.valueOf(review.getLikeCount()),
                review.getUserId(),
                review.getAnimalId(),
                review.getUserName() != null ? review.getUserName().replace(",", "") : "",
                review.getAnimalName() != null ? review.getAnimalName().replace(",", "") : "",
                review.getSpeciesDTO().getTypeName() != null ? review.getSpeciesDTO().getTypeName() : "",
                review.getSpeciesDTO().getKindName() != null ? review.getSpeciesDTO().getKindName() : ""
            ));
        }
        out.println("REVIEWS_LIST:" + payload.toString());
    }
    
    private void handleGetReviewDetail(String reviewId, PrintWriter out) {
        if (reviewId == null || reviewId.trim().isEmpty()) {
            out.println("ERROR:Review ID is required.");
            return;
        }

        // ReviewDAO를 통해 특정 ID의 리뷰를 조회
        ReviewDTO review = reviewDAO.findReviewById(reviewId);
        if (review == null) {
            out.println("ERROR:Review not found.");
            return;
        }

        // 모든 필드를 콤마(,)로 구분하여 상세 페이로드 생성
        String payload = String.join(",",
                review.getReviewId(),
                // 날짜를 toString()으로 변환
                review.getCreatedDate() != null ? review.getCreatedDate().toString() : "null",
                review.getTitle(),
                review.getContent(),
                review.getImageId(),
                String.valueOf(review.getLikeCount()),
                review.getUserId(),
                review.getAnimalId()
        );
        out.println("REVIEW_DETAIL:" + payload);
    }
    
    //특정 리뷰를 데이터베이스에서 삭제
     
    private void handleDeleteReview(String reviewId, PrintWriter out) {
        if (reviewId == null || reviewId.trim().isEmpty()) {
            out.println("ERROR:Review ID is required.");
            return;
        }

        boolean success = reviewDAO.deleteReview(reviewId);
        if (success) {
            out.println("SUCCESS:Review deleted successfully.");
        } else {
            out.println("ERROR:Failed to delete review.");
        }
    }

    // 새로운 리뷰를 데이터베이스에 추가
    private void handleAddReview(String data, PrintWriter out) {
        // 데이터 문자열을 콤마(,)로 분리
        String[] parts = data.split(",", -1);
        if (parts.length < 8) {
            out.println("ERROR:Invalid review data format.");
            return;
        }

        try {
            // 파싱된 데이터로 ReviewDTO 객체 생성
            ReviewDTO newReview = new ReviewDTO();
            newReview.setReviewId(parts[0]);
            newReview.setCreatedDate(Date.valueOf(parts[1]));
            newReview.setTitle(parts[2]);
            newReview.setContent(parts[3]);
            newReview.setImageId(parts[4]);
            newReview.setLikeCount(Integer.parseInt(parts[5]));
            newReview.setUserId(parts[6]);
            newReview.setAnimalId(parts[7]);

            // DAO를 통해 DB에 추가
            boolean success = reviewDAO.addReview(newReview);
            if (success) {
                out.println("SUCCESS:Review added successfully.");
            } else {
                out.println("ERROR:Failed to add review.");
            }
        } catch (Exception e) {
            System.err.println("리뷰 추가 중 데이터 파싱 오류: " + e.getMessage());
            out.println("ERROR:Invalid data format.");
        }
    }
}