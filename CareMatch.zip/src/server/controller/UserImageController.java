package server.controller;

import java.io.PrintWriter;
import java.util.Base64;
import DAO.ImageDAO;
import DTO.ImageDTO;

public class UserImageController implements Controller {

    private final ImageDAO imageDAO;

    public UserImageController() {
        this.imageDAO = new ImageDAO();
    }

    @Override
    public void execute(String request, PrintWriter out) {
        String[] parts = request.split(":", 2);
        String imageId = parts.length > 1 ? parts[1] : null;

        if (imageId == null) {
            System.err.println("UserImageController: 이미지 ID가 없습니다.");
            return;
        }
        
        handleGetImage(imageId, out);
    }

    private void handleGetImage(String imageId, PrintWriter out) {
        ImageDTO image = imageDAO.findImageById(imageId);

        if (image != null) {
            if (image.getImageUrl() != null && !image.getImageUrl().isEmpty()) {
                out.println("IMAGE_URL:" + image.getImageId() + "," + image.getImageUrl());
            
            } else if (image.getImageData() != null && image.getImageData().length > 0) {
                String base64ImageData = Base64.getEncoder().encodeToString(image.getImageData());
                out.println("IMAGE_DATA:" + image.getImageId() + "," + base64ImageData);
            
            } else {
                out.println("IMAGE_URL:" + imageId + ",NONE");
            }
        } else {
            out.println("IMAGE_URL:" + imageId + ",NONE");
        }
    }
}