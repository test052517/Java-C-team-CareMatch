package server.controller;

import java.io.PrintWriter;
import DAO.ImageDAO;
import DTO.ImageDTO;

public class ImageController implements Controller {

    private final ImageDAO imageDAO;

    public ImageController() {
        this.imageDAO = new ImageDAO();
    }

    @Override
    public void execute(String request, PrintWriter out) {
        String[] parts = request.split(":", 2);
        String command = parts[0];
        String imageId = parts.length > 1 ? parts[1] : null;

        try {
            if ("GET_IMAGE".equals(command) && imageId != null) {
                handleGetImage(imageId, out);
            }
        } catch (Exception e) {
            System.err.println("ImageController 오류: " + e.getMessage());
            e.printStackTrace();
            out.println("ERROR:Image data processing failed.");
        }
    }

    private void handleGetImage(String imageId, PrintWriter out) {
        ImageDTO image = imageDAO.findImageById(imageId);

        String imageUrl = "NONE";
        if (image != null && image.getImageUrl() != null) {
            imageUrl = image.getImageUrl();
        }

        out.println("IMAGE_URL:" + imageId + "," + imageUrl);
    }
}