package server.controller;

import java.io.PrintWriter;
import java.util.Base64;
import DAO.ImageDAO;
import DTO.ImageDTO;

public class ManagerImageController implements Controller {

    private final ImageDAO imageDAO;

    public ManagerImageController() {
        this.imageDAO = new ImageDAO();
    }

    @Override
    public void execute(String request, PrintWriter out) {
        // 클라이언트가 보낸 ID의 앞뒤 공백을 제거합니다.
        String imageId = request.substring("GET_MANAGER_IMAGE:".length()).trim();

        if (imageId.isEmpty() || imageId.equalsIgnoreCase("null")) {
            out.println("ERROR:Image ID is missing or null.");
            return;
        }

        ImageDTO image = imageDAO.findImageById(imageId);

        if (image == null) {
            out.println("ERROR:Image not found or data is empty.");
            return;
        }

        // 1. image_url 확인 (기존 이미지용)
        String imageUrl = image.getImageUrl();
        if (imageUrl != null && !imageUrl.trim().isEmpty()) {
            out.println("MANAGER_IMAGE_URL:" + image.getImageId() + ";" + imageUrl);

        // 2. image_data 확인 (새로 추가한 이미지용)
        } else if (image.getImageData() != null && image.getImageData().length > 0) {
            String encodedImage = Base64.getEncoder().encodeToString(image.getImageData());
            out.println("MANAGER_IMAGE_DATA:" + image.getImageId() + ";" + encodedImage);
            
        // 3. 둘 다 없는 경우
        } else {
            out.println("ERROR:Image not found or data is empty.");
        }
    }
}