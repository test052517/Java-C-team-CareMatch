package talkfxclient.bridge;

import talkfxclient.model.User;
import java.io.File;

/**
 * Backend abstraction. Implementations:
 *  - JdbcBackend: write directly to DB
 *  - LegacySocketBackend: send to external chat server
 *
 * UI 코드는 이 타입만 의존합니다.
 */
public interface ChatBackend {

    /** 텍스트 전송 */
    default void sendText(int roomId, User from, String text) throws Exception {
        throw new UnsupportedOperationException("sendText not supported by this backend");
    }

    /** 이미지 전송(파일 경로 기반) */
    default void sendImage(int roomId, User from, File file) throws Exception {
        throw new UnsupportedOperationException("sendImage not supported by this backend");
    }
}