package talkfxclient.bridge;

import talkfxclient.model.User;
import talkfxclient.ui.Db;

import java.io.File;
import java.sql.*;

/** DB 직접 접근 백엔드 */
public class JdbcBackend implements ChatBackend {

    @Override
    public void sendText(int roomId, User from, String text) throws Exception {
        System.out.println("[DIRECT-DB] SEND_TEXT -> room=" + roomId + ", me=" + from.getUserId() + ", text=" + text);
        try (Connection con = Db.get();
             PreparedStatement ps = con.prepareStatement(
                     "INSERT INTO chatting_message(room_id, sender_id, content, content_type) VALUES (?,?,?, 'TEXT')")) {
            ps.setInt(1, roomId);
            ps.setInt(2, from.getUserId());
            ps.setString(3, text);
            ps.executeUpdate();
        }
    }

    @Override
    public void sendImage(int roomId, User from, File file) throws Exception {
        System.out.println("[DIRECT-DB] SEND_IMAGE -> room=" + roomId + ", me=" + from.getUserId() + ", file=" + file);
        try (Connection con = Db.get()) {
            con.setAutoCommit(false);
            long mid = -1;
            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO chatting_message(room_id, sender_id, content, content_type) VALUES (?,?,?, 'IMAGE')",
                    Statement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, roomId);
                ps.setInt(2, from.getUserId());
                ps.setString(3, file.getAbsolutePath());
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) mid = rs.getLong(1);
                }
            }
            if (mid > 0) {
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO chat_image(message_id, file_path, original_name, size_bytes) VALUES (?,?,?,?)")) {
                    ps.setLong(1, mid);
                    ps.setString(2, file.getAbsolutePath());
                    ps.setString(3, file.getName());
                    ps.setLong(4, file.length());
                    ps.executeUpdate();
                }
            }
            con.commit();
        }
    }
}