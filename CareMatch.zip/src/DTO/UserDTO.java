package DTO;

import java.sql.Timestamp;

public class UserDTO {

    private int userId;
    private String loginId;
    private String password;
    private String name;
    private String role;
    private String status;
    private Timestamp createdAt;

    public UserDTO() {
    }

    public UserDTO(int userId, String loginId, String password, String name, String role, String status, Timestamp createdAt) {
        this.userId = userId;
        this.loginId = loginId;
        this.password = password;
        this.name = name;
        this.role = role;
        this.status = status;
        this.createdAt = createdAt;
    }

 

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public String getLoginId() { return loginId; }
    public void setLoginId(String loginId) { this.loginId = loginId; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    @Override
    public String toString() {
        return "UserDTO{" +
                "userId=" + userId +
                ", loginId='" + loginId + '\'' +
                ", password='" + "[PROTECTED]" + '\'' +
                ", name='" + name + '\'' +
                ", role='" + role + '\'' +
                ", status='" + status + '\'' +
                ", createdAt=" + createdAt +
                '}';
    }
}