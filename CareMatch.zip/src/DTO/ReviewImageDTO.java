package DTO;

public class ReviewImageDTO {
    private String reviewImageId;
    private String reviewId;
    private String fileName;
    private String mimeType;
    private byte[] imageData;

    public String getReviewImageId() { return reviewImageId; }
    public void setReviewImageId(String reviewImageId) { this.reviewImageId = reviewImageId; }

    public String getReviewId() { return reviewId; }
    public void setReviewId(String reviewId) { this.reviewId = reviewId; }

    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }

    public String getMimeType() { return mimeType; }
    public void setMimeType(String mimeType) { this.mimeType = mimeType; }

    public byte[] getImageData() { return imageData; }
    public void setImageData(byte[] imageData) { this.imageData = imageData; }
}
