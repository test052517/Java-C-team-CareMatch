package DTO;

import java.sql.Date;

public class AnimalsDTO {
    private String animalId;
    private int age;
    private double weight;
    private String sex;
    private String neutered;
    private Date happenDate;
    private String kindId;
    private String shelterId;
    private String status;
    private String imageId;
    private String animalName;

    private int applicantId; // 신청자 ID
    private SpeciesDTO speciesDTO;

    // 기본 생성자
    public AnimalsDTO() {}

    // 전체 필드 생성자
    public AnimalsDTO(String animalId, int age, double weight, String sex, String neutered,
                      Date happenDate, String kindId, String shelterId, String status,
                      String imageId, String animalName, int applicantId, SpeciesDTO speciesDTO) {
        this.animalId = animalId;
        this.age = age;
        this.weight = weight;
        this.sex = sex;
        this.neutered = neutered;
        this.happenDate = happenDate;
        this.kindId = kindId;
        this.shelterId = shelterId;
        this.status = status;
        this.imageId = imageId;
        this.animalName = animalName;
        this.applicantId = applicantId;
        this.speciesDTO = speciesDTO;
    }

    // applicantId getter/setter
    public int getApplicantId() {
        return applicantId;
    }

    public void setApplicantId(int applicantId) {
        this.applicantId = applicantId;
    }

    // SpeciesDTO 관련 getter/setter
    public void setSpeciesDTO(SpeciesDTO speciesDTO) {
        this.speciesDTO = speciesDTO;
    }

    public SpeciesDTO getSpeciesDTO() {
        return speciesDTO;
    }

    public String getType() {
        return speciesDTO != null ? speciesDTO.getTypeName() : null;
    }

    public String getKindName() {
        return speciesDTO != null ? speciesDTO.getKindName() : null;
    }

    // 나머지 필드 getter/setter
    public String getAnimalId() { return animalId; }
    public void setAnimalId(String animalId) { this.animalId = animalId; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public double getWeight() { return weight; }
    public void setWeight(double weight) { this.weight = weight; }

    public String getSex() { return sex; }
    public void setSex(String sex) { this.sex = sex; }

    public String getNeutered() { return neutered; }
    public void setNeutered(String neutered) { this.neutered = neutered; }

    public Date getHappenDate() { return happenDate; }
    public void setHappenDate(Date happenDate) { this.happenDate = happenDate; }

    public String getKindId() { return kindId; }
    public void setKindId(String kindId) { this.kindId = kindId; }

    public String getShelterId() { return shelterId; }
    public void setShelterId(String shelterId) { this.shelterId = shelterId; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getImageId() { return imageId; }
    public void setImageId(String imageId) { this.imageId = imageId; }

    public String getAnimalName() { return animalName; }
    public void setAnimalName(String animalName) { this.animalName = animalName; }

    public boolean isOnHoldForUser(int userId) {
        return this.applicantId == userId && "ON_HOLD".equals(this.status);
    }

    @Override
    public String toString() {
        return "AnimalsDTO{" +
                "animalId='" + animalId + '\'' +
                ", age=" + age +
                ", weight=" + weight +
                ", sex='" + sex + '\'' +
                ", neutered='" + neutered + '\'' +
                ", happenDate=" + happenDate +
                ", kindId='" + kindId + '\'' +
                ", shelterId='" + shelterId + '\'' +
                ", status='" + status + '\'' +
                ", imageId='" + imageId + '\'' +
                ", animalName='" + animalName + '\'' +
                ", applicantId=" + applicantId +
                ", speciesDTO=" + (speciesDTO != null ? speciesDTO.toString() : "null") +
                '}';
    }
}
