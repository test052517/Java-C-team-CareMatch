package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import DB.DBConnect;
import DTO.ReviewLikeDTO;

public class ReviewLikeDAO {

    // 특정 리뷰의 좋아요 개수를 세는 메서드 (ReviewDAO의 쿼리와 동일한 역할)
    public int countLikes(String reviewId) {
        String sql = "SELECT COUNT(*) FROM review_like WHERE review_id = ?";
        int count = 0;
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, reviewId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    count = rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            System.err.println("좋아요 수 계산 중 오류: " + e.getMessage());
            e.printStackTrace();
        }
        return count;
    }
}