package DAO;

import DTO.AdoptionDTO;
import DB.DBConnect;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AdoptionDAO {

    /**
     * 특정 사용자가 신청한 모든 입양 정보를 조회합니다.
     * @param userId 조회할 사용자의 ID
     * @return 해당 사용자의 AdoptionDTO 리스트
     */
    public List<AdoptionDTO> getAdoptionsByUser(int userId) {
        List<AdoptionDTO> list = new ArrayList<>();
        // Animals 테이블과 JOIN하여 동물의 이름까지 함께 조회합니다.
        String sql = "SELECT a.application_id, a.status, a.visit_date, a.submitted_date, " +
                     "a.animal_id, an.animal_name, a.animal_reason " +
                     "FROM Adoption a " +
                     "JOIN Animals an ON a.animal_id = an.animal_id " +
                     "WHERE a.user_id = ?";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                AdoptionDTO dto = new AdoptionDTO(
                        rs.getInt("application_id"),
                        rs.getString("status"),
                        rs.getDate("visit_date") != null ? rs.getDate("visit_date").toLocalDate() : null,
                        rs.getDate("submitted_date") != null ? rs.getDate("submitted_date").toLocalDate() : null,
                        userId, // 매개변수로 받은 userId 사용
                        rs.getString("animal_id"),
                        rs.getString("animal_name"),
                        rs.getString("animal_reason")
                );
                list.add(dto);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    /**
     * 모든 입양 신청 정보를 조회합니다. (관리자용)
     * @return 전체 AdoptionDTO 리스트
     */
    public List<AdoptionDTO> getAllAdoptions() {
        List<AdoptionDTO> list = new ArrayList<>();
        String sql = "SELECT a.application_id, a.status, a.visit_date, a.submitted_date, " +
                     "a.user_id, a.animal_id, an.animal_name, a.animal_reason " +
                     "FROM Adoption a " +
                     "JOIN Animals an ON a.animal_id = an.animal_id";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                AdoptionDTO dto = new AdoptionDTO(
                        rs.getInt("application_id"),
                        rs.getString("status"),
                        rs.getDate("visit_date") != null ? rs.getDate("visit_date").toLocalDate() : null,
                        rs.getDate("submitted_date") != null ? rs.getDate("submitted_date").toLocalDate() : null,
                        rs.getInt("user_id"),
                        rs.getString("animal_id"),
                        rs.getString("animal_name"),
                        rs.getString("animal_reason")
                );
                list.add(dto);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    /**
     * 특정 입양 신청 건의 상태를 업데이트합니다.
     * @param applicationId 상태를 변경할 신청 ID
     * @param newStatus 새로운 상태 값
     * @return 업데이트 성공 시 true, 실패 시 false
     */
    public boolean updateAdoptionStatus(int applicationId, String newStatus) {
        String sql = "UPDATE Adoption SET status = ? WHERE application_id = ?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, newStatus);
            pstmt.setInt(2, applicationId);
            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 트랜잭션 제어를 위해 외부 Connection 객체를 사용하여 입양 신청 상태를 업데이트합니다.
     * @param applicationId 상태를 변경할 신청 ID
     * @param newStatus 새로운 상태 값
     * @param conn 외부에서 관리하는 데이터베이스 Connection 객체
     * @return 업데이트 성공 시 true
     * @throws SQLException SQL 처리 중 예외 발생 시
     */
    public boolean updateAdoptionStatus(int applicationId, String newStatus, Connection conn) throws SQLException {
        String sql = "UPDATE Adoption SET status = ? WHERE application_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newStatus);
            pstmt.setInt(2, applicationId);
            return pstmt.executeUpdate() > 0;
        }
    }
}