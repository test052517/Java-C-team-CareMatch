package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import DTO.ReviewDTO;
import DTO.SpeciesDTO;
import DB.DBConnect; // DBConnect를 사용하도록 통일했습니다.

public class ReviewDAO {

    public boolean addReview(ReviewDTO review) {
        String sql = "INSERT INTO Review (review_id, created_date, title, content, image_id, `like`, user_id, animal_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, review.getReviewId());
            pstmt.setDate(2, review.getCreatedDate());
            pstmt.setString(3, review.getTitle());
            pstmt.setString(4, review.getContent());
            pstmt.setString(5, review.getImageId());
            pstmt.setInt(6, review.getLikeCount());
            pstmt.setString(7, review.getUserId());
            pstmt.setString(8, review.getAnimalId());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("리뷰 추가 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public ReviewDTO findReviewById(String reviewId) {
    	String sql = "SELECT r.*, u.name AS user_name, a.animal_name " +
                "FROM Review r " +
                "LEFT JOIN Users u ON r.user_id = u.user_id " +
                "LEFT JOIN Animals a ON r.animal_id = a.animal_id " +
                "WHERE r.review_id = ?";
        ReviewDTO review = null;
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, reviewId);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    review = new ReviewDTO();
                    review.setReviewId(rs.getString("review_id"));
                    review.setCreatedDate(rs.getDate("created_date"));
                    review.setTitle(rs.getString("title"));
                    review.setContent(rs.getString("content"));
                    review.setImageId(rs.getString("image_id"));
                    review.setLikeCount(rs.getInt("like"));
                    review.setUserId(rs.getString("user_id"));
                    review.setAnimalId(rs.getString("animal_id"));
                    
                    review.setUserName(rs.getString("user_name"));
                    review.setAnimalName(rs.getString("animal_name"));
                }
            }
        } catch (SQLException e) {
            System.err.println("리뷰 조회 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
        }
        return review;
    }

    public List<ReviewDTO> findAllReviews() {
        List<ReviewDTO> reviews = new ArrayList<>();
        String sql = "SELECT r.*, u.name AS user_name, a.animal_name, s.type_name AS species_type, s.kind_name AS species_kind " +
                     "FROM Review r " +
                     "LEFT JOIN users u ON r.user_id = u.user_id " +
                     "LEFT JOIN Animals a ON r.animal_id = a.animal_id " +
                     "LEFT JOIN Species s ON a.kind_id = s.kind_id " + // Animals 테이블의 kind_id를 Species 테이블의 kind_id에 JOIN
                     "ORDER BY r.created_date DESC";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                ReviewDTO review = new ReviewDTO();
                review.setReviewId(rs.getString("review_id"));
                review.setCreatedDate(rs.getDate("created_date"));
                review.setTitle(rs.getString("title"));
                review.setContent(rs.getString("content"));
                review.setImageId(rs.getString("image_id"));
                review.setLikeCount(rs.getInt("like"));
                review.setUserId(rs.getString("user_id"));
                review.setAnimalId(rs.getString("animal_id"));
                
                review.setUserName(rs.getString("user_name"));
                review.setAnimalName(rs.getString("animal_name"));
                
                // Species 테이블에서 직접 가져온 동물의 종류와 품종 정보를 DTO에 설정
                SpeciesDTO species = new SpeciesDTO();
                species.setTypeName(rs.getString("species_type"));
                species.setKindName(rs.getString("species_kind"));
                review.setSpeciesDTO(species);
                
                reviews.add(review);
            }
        } catch (SQLException e) {
            System.err.println("ReviewDAO findAllReviews 오류: " + e.getMessage());
            e.printStackTrace(); 
        }
        return reviews;
    }

    public boolean deleteReview(String reviewId) {
        String sql = "DELETE FROM Review WHERE review_id = ?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, reviewId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("리뷰 삭제 중 오류 발생: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}