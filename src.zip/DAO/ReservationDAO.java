package DAO;

import DTO.ReservationDTO;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReservationDAO {
    private Connection conn;

    public ReservationDAO(Connection conn) { this.conn = conn; }

    public List<ReservationDTO> findReservationsByUserId(int userId) {
        List<ReservationDTO> list = new ArrayList<>();
        String sql = "SELECT * FROM visit_reservations WHERE user_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                list.add(new ReservationDTO(
                        rs.getInt("reservation_id"),
                        rs.getInt("user_id"),
                        rs.getString("animal_name"),
                        rs.getDate("visit_date"),
                        rs.getString("visit_time"),
                        rs.getString("contact"),
                        rs.getString("reason"),
                        rs.getString("status")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean addReservation(ReservationDTO r) {
        String sql = "INSERT INTO visit_reservations(user_id, animal_name, visit_date, visit_time, contact, reason, status) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, r.getUserId());
            pstmt.setString(2, r.getAnimalName());
            pstmt.setDate(3, r.getVisitDate());
            pstmt.setString(4, r.getVisitTime());
            pstmt.setString(5, r.getContact());
            pstmt.setString(6, r.getReason());
            pstmt.setString(7, r.getStatus());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
