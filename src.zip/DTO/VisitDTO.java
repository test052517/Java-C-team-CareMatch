package DTO;

import java.sql.Date;

public class VisitDTO {
    private int visitId;
    private String purpose;
    private String status;
    private Date visitDate;
    private Date submittedDate;
    private int userId;
    private String animalId;
    private int applicationId;

    // 기본 생성자
    public VisitDTO() {}

    /**
     * 모든 필드를 초기화하는 생성자입니다.
     */
    public VisitDTO(int visitId, String purpose, String status, Date visitDate, Date submittedDate, int userId, String animalId, int applicationId) {
        this.visitId = visitId;
        this.purpose = purpose;
        this.status = status;
        this.visitDate = visitDate;
        this.submittedDate = submittedDate;
        this.userId = userId;
        this.animalId = animalId;
        this.applicationId = applicationId;
    }

    // --- Getters and Setters ---
    public int getVisitId() { return visitId; }
    public void setVisitId(int visitId) { this.visitId = visitId; }

    public String getPurpose() { return purpose; }
    public void setPurpose(String purpose) { this.purpose = purpose; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Date getVisitDate() { return visitDate; }
    public void setVisitDate(Date visitDate) { this.visitDate = visitDate; }

    public Date getSubmittedDate() { return submittedDate; }
    public void setSubmittedDate(Date submittedDate) { this.submittedDate = submittedDate; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getAnimalId() { return animalId; }
    public void setAnimalId(String animalId) { this.animalId = animalId; }

    public int getApplicationId() { return applicationId; }
    public void setApplicationId(int applicationId) { this.applicationId = applicationId; }

    @Override
    public String toString() {
        return "VisitDTO{" +
                "visitId=" + visitId +
                ", purpose='" + purpose + '\'' +
                ", status='" + status + '\'' +
                ", visitDate=" + visitDate +
                ", submittedDate=" + submittedDate +
                ", userId=" + userId +
                ", animalId='" + animalId + '\'' +
                ", applicationId=" + applicationId +
                '}';
    }
}