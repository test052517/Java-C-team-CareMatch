package DTO;

import java.time.LocalDate;

public class AdoptionDTO {
    private int applicationId;
    private String status;
    private LocalDate visitDate;
    private LocalDate submittedDate;
    private int userId;
    private String animalId;
    private String animalName;
    private String animalReason;

    public AdoptionDTO() {}

    public AdoptionDTO(int applicationId, String status, LocalDate visitDate, LocalDate submittedDate,
                       int userId, String animalId, String animalName, String animalReason) {
        this.applicationId = applicationId;
        this.status = status;
        this.visitDate = visitDate;
        this.submittedDate = submittedDate;
        this.userId = userId;
        this.animalId = animalId;
        this.animalName = animalName;
        this.animalReason = animalReason;
    }

    public int getApplicationId() { return applicationId; }
    public void setApplicationId(int applicationId) { this.applicationId = applicationId; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public LocalDate getVisitDate() { return visitDate; }
    public void setVisitDate(LocalDate visitDate) { this.visitDate = visitDate; }
    public LocalDate getSubmittedDate() { return submittedDate; }
    public void setSubmittedDate(LocalDate submittedDate) { this.submittedDate = submittedDate; }
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public String getAnimalId() { return animalId; }
    public void setAnimalId(String animalId) { this.animalId = animalId; }
    public String getAnimalName() { return animalName; }
    public void setAnimalName(String animalName) { this.animalName = animalName; }
    public String getAnimalReason() { return animalReason; }
    public void setAnimalReason(String animalReason) { this.animalReason = animalReason; }
}
