package DTO;

import java.sql.Timestamp;

public class ReviewLikeDTO {
    private String reviewId;
    private String userId;
    private Timestamp createdAt;

    public ReviewLikeDTO() {}

    public ReviewLikeDTO(String reviewId, String userId) {
        this.reviewId = reviewId;
        this.userId = userId;
    }

    // Getters and Setters
    public String getReviewId() { return reviewId; }
    public void setReviewId(String reviewId) { this.reviewId = reviewId; }
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
}