package DTO;

import java.sql.Date;

public class ReservationDTO {
    private int reservationId;
    private int userId;
    private String animalName;
    private Date visitDate;
    private String visitTime;
    private String contact;
    private String reason;
    private String status;

    public ReservationDTO(int reservationId, int userId, String animalName, Date visitDate, String visitTime,
                          String contact, String reason, String status) {
        this.reservationId = reservationId;
        this.userId = userId;
        this.animalName = animalName;
        this.visitDate = visitDate;
        this.visitTime = visitTime;
        this.contact = contact;
        this.reason = reason;
        this.status = status;
    }

    // Getter / Setter
    public int getReservationId() { return reservationId; }
    public int getUserId() { return userId; }
    public String getAnimalName() { return animalName; }
    public Date getVisitDate() { return visitDate; }
    public String getVisitTime() { return visitTime; }
    public String getContact() { return contact; }
    public String getReason() { return reason; }
    public String getStatus() { return status; }

    public void setReservationId(int reservationId) { this.reservationId = reservationId; }
    public void setUserId(int userId) { this.userId = userId; }
    public void setAnimalName(String animalName) { this.animalName = animalName; }
    public void setVisitDate(Date visitDate) { this.visitDate = visitDate; }
    public void setVisitTime(String visitTime) { this.visitTime = visitTime; }
    public void setContact(String contact) { this.contact = contact; }
    public void setReason(String reason) { this.reason = reason; }
    public void setStatus(String status) { this.status = status; }
}
