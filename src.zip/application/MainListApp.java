package application;

import DTO.UserDTO;
import DTO.AnimalsDTO;
import DTO.SpeciesDTO;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class MainListApp extends Application {

    public Stage stage;

    private GridPane animalGrid;
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private List<AnimalsDTO> animalList;
    private Map<String, ImageView> imageViewsMap = new HashMap<>();

    private ComboBox<String> animalType;
    private ComboBox<String> breedType;
    
    private HBox topBarAdoption;
    private HBox searchBox;
    
    @Override
    public void start(Stage stage) {
        this.stage = stage;
        HBox root = new HBox();
        root.getStyleClass().add("root");
        Font.loadFont(getClass().getResource("/resources/Pretendard-Medium.ttf").toExternalForm(), 12);
        Font.loadFont(getClass().getResource("/resources/Pretendard-Bold.ttf").toExternalForm(), 12);
        Font.loadFont(getClass().getResource("/resources/Pretendard-ExtraBold.ttf").toExternalForm(), 12);
        
        // --- 좌측 메뉴 ---
        VBox sideMenu = createSideMenu(stage);
        
        // --- 우측 메인 콘텐츠 ---
        VBox mainContent = new VBox(20);
        mainContent.setPadding(new Insets(20, 40, 20, 40));
        mainContent.setPrefWidth(1100);

        // -- 화면 구성 요소 사전 생성 --
        this.topBarAdoption = createTopBar("입양 가능한 동물 리스트", true);
        HBox topBarReview = createTopBar("후기 게시판", false);
        
        this.animalGrid = new GridPane();
        setupGridPane(animalGrid);
        
        connectToServer();
        requestAnimalList();

        ScrollPane adoptionScrollPane = new ScrollPane(animalGrid);
        setupScrollPane(adoptionScrollPane);
        
        // 기본 화면 설정
        mainContent.getChildren().addAll(topBarAdoption, adoptionScrollPane);
        VBox.setVgrow(adoptionScrollPane, Priority.ALWAYS);
        root.getChildren().addAll(sideMenu, mainContent);

        // --- 메뉴 클릭 이벤트 핸들러 설정 ---
        List<Label> menuLabels = sideMenu.getChildren().stream()
                .filter(node -> node instanceof Label)
                .map(node -> (Label) node)
                .collect(Collectors.toList());
        
        HBox h1 = (HBox) sideMenu.lookup("#h1");
        HBox h2 = (HBox) sideMenu.lookup("#h2");
        Label menu6 = (Label) h1.getChildren().get(0);
        Label menu7 = (Label) h2.getChildren().get(0);

        List<Label> allMenuLabels = new ArrayList<>(menuLabels);
        allMenuLabels.add(menu6);
        allMenuLabels.add(menu7);

        allMenuLabels.get(0).getStyleClass().add("menuItem-selected");

        for (Label label : allMenuLabels) {
            setupMenuEvents(label, allMenuLabels, mainContent,
                    topBarAdoption, topBarReview, adoptionScrollPane,
                    h1, h2, menu6, menu7, stage);
        }

        Scene scene = new Scene(root, 1300, 850);
        scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
        stage.setScene(scene);
        stage.setTitle("CareMatch");
        stage.show();
    }

    // --- UI 생성 헬퍼 메서드 ---

    private VBox createSideMenu(Stage stage) {
        VBox sideMenu = new VBox(20);
        sideMenu.setId("sideMenu");
        sideMenu.setPadding(new Insets(30));
        sideMenu.setPrefWidth(250);
        sideMenu.setFillWidth(true);

        ImageView logo = new ImageView(new Image("file:src/application/menu_icon/Logo1.png"));
        logo.setFitWidth(100);
        logo.setFitHeight(105);
        logo.setPreserveRatio(true);
        VBox logoBox = new VBox(5, logo);
        logoBox.setAlignment(Pos.CENTER);

        Label menu1 = createMenuItem("입양 목록", "file:src/application/menu_icon/home.png");
        Label menu2 = createMenuItem("입양 후기", "file:src/application/menu_icon/review.png");
        Label menu3 = createMenuItem("마이 페이지", "file:src/application/menu_icon/smile.png");
        Label menu5 = createMenuItem("채팅 문의하기", "file:src/application/menu_icon/talk.png");
        Label menu6 = createSubMenuItem("입양신청 확인", "file:src/application/menu_icon/down_right.png");
        Label menu7 = createSubMenuItem("방문예약 하기", "file:src/application/menu_icon/down_right.png");
        
        HBox h1 = new HBox(menu6);
        h1.setId("h1");
        HBox h2 = new HBox(menu7);
        h2.setId("h2");
        setupSubMenuLayout(h1, h2);

        Button logoutBtn = new Button("로그아웃");
        logoutBtn.setId("logoutBtn");
        logoutBtn.setOnAction(event -> {
            Main main = new Main();
            try {
                main.start(stage);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);
        
        HBox logoutBox = new HBox(logoutBtn);
        logoutBox.setAlignment(Pos.CENTER);
        
        sideMenu.getChildren().addAll(logoBox, menu1, menu2, menu3, h1, h2, menu5, spacer, logoutBox);
        return sideMenu;
    }
    
    private Label createMenuItem(String text, String iconPath) {
        Label label = new Label(text);
        ImageView icon = new ImageView(new Image(iconPath));
        icon.setFitHeight(17);
        icon.setFitWidth(17);
        label.setGraphic(icon);
        label.setContentDisplay(ContentDisplay.LEFT);
        label.getStyleClass().add("menuItem");
        label.setMaxWidth(Double.MAX_VALUE);
        label.setPrefHeight(30);
        return label;
    }

    private Label createSubMenuItem(String text, String iconPath) {
        Label label = createMenuItem(text, iconPath);
        label.setPrefHeight(20);
        label.setVisible(false);
        label.setManaged(false);
        return label;
    }

    private void setupSubMenuLayout(HBox h1, HBox h2) {
        h1.setAlignment(Pos.CENTER);
        h2.setAlignment(Pos.CENTER);
        h1.setPrefWidth(130);
        h2.setPrefWidth(130);
        h1.setManaged(false);
        h2.setManaged(false);
    }
    
    private HBox createTopBar(String titleText, boolean isAdoptionList) {
        Label title = new Label(titleText);
        title.setId("titleLabel");
        
        searchBox = new HBox(10);
        searchBox.setId("searchBox");
        searchBox.setAlignment(Pos.CENTER_RIGHT);
        
        TextField searchField = new TextField();
        searchField.setPrefWidth(200);
        
        searchField.textProperty().addListener((obs, oldText, newText) -> {
            String searchText = (newText != null) ? newText.toLowerCase() : "";
            applyFilters(searchText);
        });

        if (isAdoptionList) {
             searchField.setPromptText("분양글 검색");
             animalType = createFilterComboBox("전체", "개", "고양이", "기타");
             breedType = createFilterComboBox("품종");
             animalType.valueProperty().addListener((obs, oldVal, newVal) -> applyFilters(searchField.getText()));
             breedType.valueProperty().addListener((obs, oldVal, newVal) -> applyFilters(searchField.getText()));
             searchBox.getChildren().addAll(searchField, animalType, breedType);
        } else {
            searchBox.setVisible(false);
            searchBox.setManaged(false);
            searchField.setManaged(false);
        }

        HBox topBar = new HBox();
        topBar.setAlignment(Pos.BOTTOM_LEFT);
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        topBar.getChildren().addAll(title, spacer, searchBox);
        return topBar;
    }
    
    private ComboBox<String> createFilterComboBox(String... items) {
        ComboBox<String> comboBox = new ComboBox<>();
        comboBox.getItems().addAll(items);
        comboBox.getSelectionModel().selectFirst();
        comboBox.setBackground(Background.fill(Color.web("fff")));
        return comboBox;
    }

    private void setupGridPane(GridPane gridPane) {
        gridPane.setHgap(40);
        gridPane.setVgap(20);
        gridPane.setPadding(new Insets(10));
        gridPane.setId("animalGrid");
		gridPane.setBackground(Background.fill(Color.web("fff")));
	}

	private void setupScrollPane(ScrollPane scrollPane) {
		scrollPane.setFitToWidth(true);
		scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
		scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
		scrollPane.setId("scrollPane");
		scrollPane.setMaxHeight(Double.MAX_VALUE);
	}

	// --- 이벤트 핸들러 ---

	private void setupMenuEvents(Label label, List<Label> allLabels, VBox mainContent, HBox topBarAdoption,
			HBox topBarReview, ScrollPane adoptionScrollPane, HBox h1, HBox h2, Label menu6, Label menu7, Stage stage) {

		label.setOnMouseClicked(event -> {
			for (Label lbl : allLabels) {
				lbl.getStyleClass().remove("menuItem-selected");
			}
			label.getStyleClass().add("menuItem-selected");

			String menuText = label.getText();
			System.out.println("선택된 메뉴: " + menuText);

			if ("입양 목록".equals(menuText)) {
				searchBox.setVisible(true);
				searchBox.setManaged(true);
				mainContent.getChildren().setAll(topBarAdoption, adoptionScrollPane);
				populateBreedComboBox();
				filterAnimalList();
			} else if ("입양 후기".equals(menuText)) {
				searchBox.setVisible(false);
				searchBox.setManaged(false);
				mainContent.getChildren().setAll(topBarReview);

				UserDTO currentUser = SessionManager.getInstance().getLoggedInUser();
				if (currentUser == null) {
					showAlert("로그인 필요", "후기 게시판을 보려면 먼저 로그인해야 합니다.");
				} else {
					ReviewPageView rpv = new ReviewPageView(currentUser);
					ScrollPane reviewScrollPane = rpv.getContent();
					setupScrollPane(reviewScrollPane);
					VBox.setVgrow(reviewScrollPane, Priority.ALWAYS);

					mainContent.getChildren().add(reviewScrollPane);

					Button reviewWriteBtn = new Button("후기 작성");
					reviewWriteBtn.setOnAction(e -> new ReviewWriteForm().show(stage, currentUser));
					HBox btnBox = new HBox(reviewWriteBtn);
					btnBox.setAlignment(Pos.BOTTOM_RIGHT);
					mainContent.getChildren().add(btnBox);
				}
			} else if ("마이 페이지".equals(menuText)) {
				searchBox.setVisible(false);
				searchBox.setManaged(false);
				UserDTO currentUser = SessionManager.getInstance().getLoggedInUser();
				if (currentUser != null) {
					MyPageView myPageView = new MyPageView(currentUser);
					mainContent.getChildren().setAll(myPageView.getContent());
				} else {
					showAlert("로그인 필요", "마이페이지를 보려면 로그인이 필요합니다.");
				}
			} else if ("입양신청 확인".equals(menuText)) {
				searchBox.setVisible(false);
				searchBox.setManaged(false);
				int currentUserId = SessionManager.getInstance().getLoggedInUserId();
				new Thread(() -> Platform.runLater(() -> AdoptionCheckForm.show(currentUserId))).start();
			} else if ("방문예약 하기".equals(menuText)) {
				searchBox.setVisible(false);
				searchBox.setManaged(false);
				new Thread(() -> Platform.runLater(() -> new VisitReservationForm().show())).start();
			} else if ("관리자 문의하기".equals(menuText) || "채팅 문의하기".equals(menuText)) {
				searchBox.setVisible(false);
				searchBox.setManaged(false);
				try {
					ChatLauncher.openChatList();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}

			if ("마이 페이지".equals(menuText) || "입양신청 확인".equals(menuText) || "방문예약 하기".equals(menuText)) {
				setSubMenusVisible(true, menu6, menu7, h1, h2);
			} else {
				setSubMenusVisible(false, menu6, menu7, h1, h2);
			}
		});

		label.setOnMouseEntered(e -> {
			if (!label.getStyleClass().contains("menuItem-selected")) {
				label.getStyleClass().add("menuItem-hover");
			}
		});
		label.setOnMouseExited(e -> {
			label.getStyleClass().remove("menuItem-hover");
		});
	}

    private void setSubMenusVisible(boolean visible, Label menu6, Label menu7, HBox h1, HBox h2) {
        menu6.setVisible(visible);
        menu6.setManaged(visible);
        menu7.setVisible(visible);
        menu7.setManaged(visible);
        h1.setManaged(visible);
        h2.setManaged(visible);
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    // --- 서버 통신 및 데이터 처리 ---
    private void connectToServer() {
		try {
			socket = new Socket("localhost", 9999);
			out = new PrintWriter(socket.getOutputStream(), true);
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

			Thread listenerThread = new Thread(() -> {
				try {
					String serverResponse;
					while ((serverResponse = in.readLine()) != null) {
						processServerResponse(serverResponse);
					}
				} catch (Exception e) {
					System.out.println("서버 연결이 끊어졌습니다.");
				}
			});
			listenerThread.setDaemon(true);
			listenerThread.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void requestAnimalList() {
		if (out != null) {
			out.println("GET_ANIMALS");
		}
	}

	private void processServerResponse(String response) {
	    Platform.runLater(() -> {
	        String[] parts = response.split(":", 2);
	        String command = parts[0];
	        String payload = parts.length > 1 ? parts[1] : "";

	        if ("ANIMALS_LIST".equals(command)) {
	            parseAndStoreAnimals(payload);
	            populateBreedComboBox();
	            filterAnimalList();
	        } else if ("IMAGE_URL".equals(command)) {
	            updateImage(payload);
	        }
	        else if ("IMAGE_DATA".equals(command)) {
	            updateImageData(payload); // Base64 데이터를 처리할 새 메소드 호출
	        }
	    });
	}

	private void parseAndStoreAnimals(String payload) {
	    this.animalList = new ArrayList<>();
	    if (payload.isEmpty()) return;
	    
	    String[] animalsData = payload.split("\\|");
	    for (String animalStr : animalsData) {
	        String[] details = animalStr.split(",");
	        if (details.length >= 7) { 
	            AnimalsDTO animal = new AnimalsDTO();
	            animal.setAnimalId(details[0]);
	            animal.setAnimalName(details[1]);
	            animal.setSex(details[2]);
	            animal.setImageId(details[4]);

	            try {
	                animal.setAge(Integer.parseInt(details[3]));
	            } catch (NumberFormatException e) {
	                System.err.println("경고: 잘못된 나이 형식 '" + details[3] + "'. 기본값 0으로 설정.");
	                animal.setAge(0); 
	            }

	            SpeciesDTO species = new SpeciesDTO();
	            species.setTypeName(details[5]);
	            species.setKindName(details[6]);
	            animal.setSpeciesDTO(species); 
	            animalList.add(animal);
	        }
	    }
	}
    
    private void populateBreedComboBox() {
	    if (animalList == null) return;
	    String selectedType = animalType.getValue();

	    Platform.runLater(() -> {
	        breedType.getItems().clear();
	        breedType.getItems().add("품종");

	        animalList.stream()
	            .filter(animal -> {
	                String typeName = animal.getSpeciesDTO() != null ? animal.getSpeciesDTO().getTypeName() : null;
	                return "전체".equals(selectedType) || (typeName != null && typeName.equals(selectedType));
	            })
	            .map(animal -> animal.getSpeciesDTO().getKindName())
	            .distinct()
	            .filter(name -> name != null)
	            .forEach(breed -> breedType.getItems().add(breed));

	        breedType.getSelectionModel().selectFirst();
	    });
	}

	private void filterAnimalList() {
	    if (animalList == null) return;

	    String selectedType = animalType.getValue();
	    String selectedBreed = breedType.getValue();

	    List<AnimalsDTO> filteredList = animalList.stream()
	        .filter(a -> {
	            String typeName = a.getSpeciesDTO() != null ? a.getSpeciesDTO().getTypeName() : null;
	            String kindName = a.getSpeciesDTO() != null ? a.getSpeciesDTO().getKindName() : null;
	            boolean typeMatch = "전체".equals(selectedType) || (typeName != null && typeName.equals(selectedType));
	            boolean breedMatch = "품종".equals(selectedBreed) || (kindName != null && kindName.equals(selectedBreed));
	            return typeMatch && breedMatch;
	        })
	        .collect(Collectors.toList());

	    updateAnimalGrid(filteredList);
	}
	
	private void updateAnimalGrid(List<AnimalsDTO> animals) {
	    animalGrid.getChildren().clear();
	    imageViewsMap.clear();
	    int col = 0;
	    int row = 0;

	    for (AnimalsDTO animal : animals) {
	        VBox card = createAnimalCard(animal);
	        animalGrid.add(card, col, row);

	        if (animal.getImageId() != null && !"null".equalsIgnoreCase(animal.getImageId())) {
	            out.println("GET_USERIMAGE:" + animal.getImageId());
	        }

	        col++;
	        if (col > 3) {
	            col = 0;
	            row++;
	        }
	    }
	}
	
	private void applyFilters(String searchText) {
	    if (animalList == null) return;

	    String selectedType = (animalType != null && animalType.getValue() != null) 
	        ? animalType.getValue() : "전체";
	    String selectedBreed = (breedType != null && breedType.getValue() != null) 
	        ? breedType.getValue() : "품종";

	    List<AnimalsDTO> filteredList = animalList.stream()
	        .filter(a -> {
	            String animalName = a.getAnimalName();
	            boolean nameMatch = (searchText == null || searchText.isEmpty())
	                || (animalName != null && animalName.toLowerCase().contains(searchText.toLowerCase()));

	            String typeName = (a.getSpeciesDTO() != null) ? a.getSpeciesDTO().getTypeName() : null;
	            String kindName = (a.getSpeciesDTO() != null) ? a.getSpeciesDTO().getKindName() : null;

	            boolean typeMatch = "전체".equals(selectedType) || (typeName != null && typeName.equals(selectedType));
	            boolean breedMatch = "품종".equals(selectedBreed) || (kindName != null && kindName.equals(selectedBreed));

	            return nameMatch && typeMatch && breedMatch;
	        })
	        .collect(Collectors.toList());

	    updateAnimalGrid(filteredList);
	}

	private void updateImage(String payload) {
        String[] parts = payload.split(",", 2);
        if (parts.length < 2) return;

        String imageId = parts[0];
        String imageUrl = parts[1];

        ImageView imageView = imageViewsMap.get(imageId);
        if (imageView != null && !"NONE".equals(imageUrl)) {
            try {
                Image realImage = new Image(imageUrl, true);
                imageView.setImage(realImage);
            } catch (Exception e) {
                System.err.println("이미지 로드 실패: " + imageUrl);
            }
        }
    }
    
	private void updateImageData(String payload) {
	    String[] parts = payload.split(",", 2);
	    if (parts.length < 2) return;

	    String imageId = parts[0];
	    String base64Data = parts[1];

	    ImageView imageView = imageViewsMap.get(imageId);
	    if (imageView != null && base64Data != null && !base64Data.isEmpty()) {
	        try {
	            // Base64 문자열을 byte 배열로 디코딩
	            byte[] decodedBytes = java.util.Base64.getDecoder().decode(base64Data);
	            // byte 배열로부터 Image 객체 생성
	            Image realImage = new Image(new java.io.ByteArrayInputStream(decodedBytes));
	            imageView.setImage(realImage);
	        } catch (Exception e) {
	            System.err.println("Base64 이미지 데이터 변환 실패: " + imageId);
	        }
	    }
	}

	private VBox createAnimalCard(AnimalsDTO animal) {
	    VBox card = new VBox(10);
	    card.setId("animalCard");
	    card.setPadding(new Insets(10));

	    ImageView imageView = new ImageView(new Image("file:resources/img_placeholder.png"));
	    imageView.setFitHeight(180);
	    imageView.setFitWidth(180);
	    imageView.setPreserveRatio(false);

	    Rectangle clip = new Rectangle(180, 180);
	    clip.setArcWidth(30);
	    clip.setArcHeight(30);
	    imageView.setClip(clip);

	    if (animal.getImageId() != null && !"null".equalsIgnoreCase(animal.getImageId())) {
	        imageViewsMap.put(animal.getImageId(), imageView);
	    }

	    Label nameLabel = new Label(animal.getAnimalName());
	    nameLabel.getStyleClass().add("animalName");

	    int ageValue = animal.getAge();
	    int age;
	    if (ageValue > 1000) {
	        int currentYear = LocalDate.now().getYear();
	        age = currentYear - ageValue + 1;
	    } else {
	        age = Math.max(ageValue, 0);
	    }

	    Label infoLabel = new Label(String.format("%s / %d살", animal.getSex(), age));
	    infoLabel.getStyleClass().add("animalInfo");

	    card.getChildren().addAll(imageView, nameLabel, infoLabel);
	    card.setAlignment(Pos.CENTER);

	    card.setOnMouseClicked(event -> {
	        int currentUserId = SessionManager.getInstance().getLoggedInUserId();
	        if (currentUserId == 0) {
	            showAlert("로그인 필요", "동물 상세 정보를 보려면 먼저 로그인해야 합니다.");
	            return;
	        }
	        AnimalDetailView adv = new AnimalDetailView(animal.getAnimalId(), currentUserId);
	        adv.start(stage);
	    });
	    return card;
	}

    public static void main(String[] args) {
        launch(args);
    }
}