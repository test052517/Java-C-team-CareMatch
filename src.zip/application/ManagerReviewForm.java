package application;

import DAO.ReviewDAO;
import DAO.ReviewImageDAO;
// import DAO.ReviewLikeDAO; // 더 이상 필요 없으므로 삭제
import DTO.ReviewDTO;
import DTO.ReviewImageDTO;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.ByteArrayInputStream;

public class ManagerReviewForm {

    private ReviewDAO reviewDAO = new ReviewDAO();
    private ReviewImageDAO reviewImageDAO = new ReviewImageDAO();
    
    public void show(String reviewId) {
        Stage stage = new Stage();
        stage.setTitle("후기 상세 확인");

        VBox root = new VBox(20);
        root.setPadding(new Insets(20));
        root.getStyleClass().add("root");

        ReviewDTO review = reviewDAO.findReviewById(reviewId);
        
        // --- '좋아요 수' 관련 UI 및 로직 전체 삭제 ---
        // ReviewLikeDAO를 통해 좋아요 수를 가져오던 로직을 삭제했습니다.
        
        if (review == null) {
            root.getChildren().add(new Label("리뷰 정보를 불러올 수 없습니다."));
        } else {
            // 사용자
            Label userLabel = new Label("사용자");
            TextField userField = new TextField(review.getUserName());
            userField.setDisable(true);
            userLabel.getStyleClass().add("Form-label");
            VBox group2 = new VBox(2, userLabel, userField);

            // 작성일자
            Label dateLabel = new Label("작성 일자");
            DatePicker datePicker = new DatePicker(review.getCreatedDate().toLocalDate());
            datePicker.setDisable(true);
            dateLabel.getStyleClass().add("Form-label");
            VBox group3 = new VBox(2, dateLabel, datePicker);

            // 제목
            Label titleLabel = new Label("제목");
            TextField titleField = new TextField(review.getTitle());
            titleField.setDisable(true);
            titleLabel.getStyleClass().add("Form-label");
            VBox group4 = new VBox(2, titleLabel, titleField);
            
            // 이미지
            Label imageLabel = new Label("이미지");
            imageLabel.getStyleClass().add("Form-label");
            
            ReviewImageDTO imageDTO = reviewImageDAO.findByReviewId(reviewId);
            ImageView imageView = new ImageView();
            imageView.setFitWidth(100);
            imageView.setFitHeight(100);
            imageView.setPreserveRatio(true);
            
            if (imageDTO != null && imageDTO.getImageData() != null) {
                imageView.setImage(new Image(new ByteArrayInputStream(imageDTO.getImageData())));
            } else {
                imageView.setImage(new Image(getClass().getResourceAsStream("/resources/img_placeholder.png")));
            }
            
            VBox group5 = new VBox(2, imageLabel, imageView);

            // 내용
            Label contentLabel = new Label("내용");
            TextArea contentArea = new TextArea(review.getContent());
            contentArea.setDisable(true);
            contentArea.setWrapText(true);
            contentArea.setMinHeight(100);
            contentLabel.getStyleClass().add("Form-label");
            VBox group6 = new VBox(2, contentLabel, contentArea);

            // 버튼
            Button confirmBtn = new Button("확인");
            confirmBtn.setOnAction(e -> stage.close());
            
            HBox buttonBox = new HBox(10, confirmBtn);
            buttonBox.setAlignment(Pos.CENTER_RIGHT);

            // root의 자식 노드 추가 부분에서 'groupLikes'를 완전히 제거했습니다.
            root.getChildren().addAll(group2, group3, group4, group5, group6, buttonBox);
        }

        Scene scene = new Scene(root, 450, 650); // 컨텐츠가 줄었으므로 높이를 조절했습니다.
        scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());

        stage.setScene(scene);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.show();
    }
}