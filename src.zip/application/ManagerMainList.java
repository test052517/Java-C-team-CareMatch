package application;

import DTO.AnimalsDTO;
import DTO.SpeciesDTO;
import application.ui.AnimalListView;
import application.ui.SidebarView;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.ByteArrayInputStream;

public class ManagerMainList {
    private static final String SERVER_HOST = "localhost";
    private static final int SERVER_PORT = 9999;

    // 네트워킹 객체
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;

    // 정렬 순서 플래그
    private boolean isTypeAsc = true;
    private boolean isAgeAsc = true;
    private boolean isWeightAsc = true;
    private boolean isGenderAsc = true;
    private boolean isNeuteredAsc = true;
    private boolean isDateAsc = true;

    // 데이터 및 UI 컴포넌트
    private List<AnimalsDTO> animals = new ArrayList<>();
    private AnimalListView animalListView;
    private Map<String, AnimalCard> cardMap = new HashMap<>();

    // 한번 불러온 이미지를 저장하는 캐시
    private Map<String, Image> imageCache = new HashMap<>();
    private int userId;

    public Pane getView(int userId) {
        this.userId = userId;

        BorderPane root = new BorderPane();
        root.getStyleClass().add("root");
        Font.loadFont(getClass().getResource("/resources/Pretendard-Medium.ttf").toExternalForm(), 12);
        Font.loadFont(getClass().getResource("/resources/Pretendard-Bold.ttf").toExternalForm(), 12);
        Font.loadFont(getClass().getResource("/resources/Pretendard-ExtraBold.ttf").toExternalForm(), 12);

        root.setLeft(new SidebarView());

        animalListView = new AnimalListView(animals, this);

        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setContent(animalListView);
        scrollPane.setFitToWidth(true);

        HBox header = new HBox();
        header.setPadding(new Insets(10));
        header.setAlignment(Pos.CENTER_LEFT);
        header.setSpacing(10);

        Label title = new Label("입양 동물 목록");
        title.getStyleClass().add("title");

        Button addBtn = new Button("동물 추가");
        addBtn.getStyleClass().add("register-button");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        header.getChildren().addAll(title, spacer, addBtn);

        HBox sortBar = new HBox(20);
        sortBar.setPrefWidth(600);
        sortBar.setAlignment(Pos.CENTER);

        Label sortType = createSortLabel("종");
        Label sortAge = createSortLabel("나이");
        Label sortWeight = createSortLabel("무게");
        Label sortGender = createSortLabel("성별");
        Label sortNeutered = createSortLabel("중성화");
        Label sortDate = createSortLabel("입소일");

        List<Label> allLabels = Arrays.asList(sortType, sortAge, sortWeight,
                sortGender, sortNeutered, sortDate);

        for (Label lbl : allLabels) {
            lbl.setMaxWidth(Double.MAX_VALUE);
            lbl.setAlignment(Pos.CENTER);
            HBox.setHgrow(lbl, Priority.ALWAYS);
            lbl.getStyleClass().add("sort-label");
        }

        sortBar.getChildren().addAll(allLabels);

        HBox sortBarContainer = new HBox(sortBar);
        sortBarContainer.setPadding(new Insets(8));
        sortBarContainer.getStyleClass().add("sort-bar-container");
        sortBarContainer.setPrefWidth(620);

        // 정렬 버튼 이벤트 핸들러
        sortType.setOnMouseClicked(e -> {
            isTypeAsc = !isTypeAsc;
            sortType.setText("종 " + (isTypeAsc ? "↑" : "↓"));
            animals.sort((a, b) -> isTypeAsc ?
                    a.getKindName().compareTo(b.getKindName()) : b.getKindName().compareTo(a.getKindName()));
            animalListView.updateList(animals, this.userId, imageCache);
        });

        sortAge.setOnMouseClicked(e -> {
            isAgeAsc = !isAgeAsc;
            sortAge.setText("나이 " + (isAgeAsc ? "↑" : "↓"));
            animals.sort((a, b) -> isAgeAsc ?
                    Integer.compare(a.getAge(), b.getAge()) : Integer.compare(b.getAge(), a.getAge()));
            animalListView.updateList(animals, this.userId, imageCache);
        });

        sortWeight.setOnMouseClicked(e -> {
            isWeightAsc = !isWeightAsc;
            sortWeight.setText("무게 " + (isWeightAsc ? "↑" : "↓"));
            animals.sort((a, b) -> isWeightAsc ?
                    Double.compare(a.getWeight(), b.getWeight()) : Double.compare(b.getWeight(), a.getWeight()));
            animalListView.updateList(animals, this.userId, imageCache);
        });

        sortGender.setOnMouseClicked(e -> {
            isGenderAsc = !isGenderAsc;
            sortGender.setText("성별 " + (isGenderAsc ? "♂" : "♀"));
            animals.sort((a, b) -> isGenderAsc ?
                    a.getSex().compareTo(b.getSex()) : b.getSex().compareTo(a.getSex()));
            animalListView.updateList(animals, this.userId, imageCache);
        });

        sortNeutered.setOnMouseClicked(e -> {
            isNeuteredAsc = !isNeuteredAsc;
            sortNeutered.setText("중성화 " + (isNeuteredAsc ? "O" : "X"));
            animals.sort((a, b) -> isNeuteredAsc ?
                    a.getNeutered().compareTo(b.getNeutered()) : b.getNeutered().compareTo(a.getNeutered()));
            animalListView.updateList(animals, this.userId, imageCache);
        });

        sortDate.setOnMouseClicked(e -> {
            isDateAsc = !isDateAsc;
            sortDate.setText("입소일 " + (isDateAsc ? "↑" : "↓"));
            animals.sort((a, b) -> isDateAsc ?
                    a.getHappenDate().compareTo(b.getHappenDate()) : b.getHappenDate().compareTo(a.getHappenDate()));
            animalListView.updateList(animals, this.userId, imageCache);
        });

        addBtn.setOnAction(e -> {
            Stage formStage = new Stage();
            formStage.initModality(Modality.APPLICATION_MODAL);
            ManagerDataRegistrationForm form = new ManagerDataRegistrationForm();
            form.show(formStage);
        });

        VBox centerPane = new VBox(10);
        centerPane.setPadding(new Insets(20));
        centerPane.getChildren().addAll(header, sortBarContainer, scrollPane);

        root.setCenter(centerPane);

        connectAndLoadData();

        return root;
    }

    private void connectAndLoadData() {
        new Thread(() -> {
            try {
                socket = new Socket(SERVER_HOST, SERVER_PORT);
                out = new PrintWriter(socket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                Thread listenerThread = new Thread(this::listenToServer);
                listenerThread.setDaemon(true);
                listenerThread.start();

                out.println("GET_MANAGER_ANIMALS");

            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void listenToServer() {
        try {
            String serverResponse;
            while ((serverResponse = in.readLine()) != null) {
                processServerResponse(serverResponse);
            }
        } catch (IOException e) {
            System.err.println("서버 연결이 끊어졌습니다.");
        }
    }

    private void processServerResponse(String response) {
        String[] parts = response.split(":", 2);
        String command = parts[0];
        String payload = parts.length > 1 ? parts[1] : "";

        Platform.runLater(() -> {
            if ("MANAGER_ANIMAL_LIST".equals(command)) {
                handleAnimalList(payload);
            } else if ("MANAGER_IMAGE_URL".equals(command)) {
                handleImageUrl(payload);
            } else if ("MANAGER_IMAGE_DATA".equals(command)) {
                handleImageData(payload);
            } else if ("STATUS_UPDATE_SUCCESS".equals(command)) {
                handleStatusUpdateSuccess(payload);
            } else if ("STATUS_UPDATE_FAILURE".equals(command)) {
                showErrorAlert("상태 변경 실패", "데이터베이스에 상태를 업데이트하는 데 실패했습니다.");
            } else if (response.startsWith("ERROR")) {
                System.err.println("서버 오류: " + payload);
            }
        });
    }

    private void handleAnimalList(String payload) {
        List<AnimalsDTO> newAnimals = parseAnimalData(payload);
        animals.clear();
        animals.addAll(newAnimals);
        animalListView.updateList(animals, this.userId, imageCache);

        cardMap.clear();
        for (AnimalCard card : animalListView.getAnimalCards()) {
            String imageId = card.getImageId();
            if (imageId != null && !"null".equalsIgnoreCase(imageId) && imageCache.get(imageId) == null) {
                cardMap.put(imageId, card);
                out.println("GET_MANAGER_IMAGE:" + imageId);
            }
        }
    }

    private void handleImageUrl(String payload) {
        String[] dataParts = payload.split(";", 2);
        if (dataParts.length == 2) {
            String imageId = dataParts[0];
            String imageUrl = dataParts[1];
            AnimalCard card = cardMap.get(imageId);
            if (card != null) {
                try {
                    Image image = new Image(imageUrl, true);
                    imageCache.put(imageId, image);
                    card.updateImage(image);
                } catch (Exception e) {
                    System.err.println("이미지 URL 로드 실패: " + imageUrl);
                }
            }
        }
    }

    private void handleImageData(String payload) {
        String[] dataParts = payload.split(";", 2);
        if (dataParts.length == 2) {
            String imageId = dataParts[0];
            String base64Data = dataParts[1];
            AnimalCard card = cardMap.get(imageId);

            if (card != null) {
                try {
                    byte[] decodedBytes = Base64.getDecoder().decode(base64Data);
                    ByteArrayInputStream bis = new ByteArrayInputStream(decodedBytes);
                    Image image = new Image(bis);

                    imageCache.put(imageId, image);
                    card.updateImage(image);

                } catch (Exception e) {
                    System.err.println("Base64 이미지 디코딩 또는 UI 업데이트 실패: " + e.getMessage());
                }
            }
        }
    }

    private List<AnimalsDTO> parseAnimalData(String data) {
        List<AnimalsDTO> newAnimals = new ArrayList<>();
        if (data.isEmpty()) return newAnimals;

        String[] records = data.split("##RECORD_END##");
        for (String record : records) {
            if (record.trim().isEmpty()) continue;

            String[] fields = record.split(";", -1);

            if (fields.length >= 13) {
                try {
                    AnimalsDTO dto = new AnimalsDTO();
                    SpeciesDTO species = new SpeciesDTO();

                    dto.setAnimalId(fields[0]);
                    dto.setAnimalName(fields[1]);
                    species.setKindName(fields[2]);
                    dto.setSpeciesDTO(species);

                    // ✨ 수정된 나이 계산 로직 (1000 이상일 때만 적용)
                    int ageValue = Integer.parseInt(fields[3]);
                    int finalAge;

                    if (ageValue > 1000) {
                        // 값이 1000보다 크면 출생년도로 간주하고 나이 계산
                        String birthYearStr = String.valueOf(ageValue);
                        int birthYear;

                        // '202560' 같은 데이터는 앞 4자리만 사용하도록 처리
                        if (birthYearStr.length() > 4) {
                            birthYear = Integer.parseInt(birthYearStr.substring(0, 4));
                        } else {
                            birthYear = ageValue;
                        }
                        
                        // 현재 연도를 기준으로 나이 계산 (현재 2025년)
                        int currentYear = 2025;
                        finalAge = currentYear - birthYear;
                        if (finalAge < 0) finalAge = 0; // 데이터 오류로 나이가 음수일 경우 0으로 처리

                    } else {
                        // 값이 1000 이하면 그대로 나이로 사용
                        finalAge = ageValue;
                    }

                    dto.setAge(finalAge); // 😊 최종 계산된 나이를 저장합니다.
                    
                    dto.setWeight(Double.parseDouble(fields[4]));
                    dto.setSex(fields[5]);
                    dto.setNeutered(fields[6]);
                    dto.setHappenDate(Date.valueOf(fields[7]));
                    dto.setStatus(fields[8]);
                    dto.setImageId(fields[9]);

                    newAnimals.add(dto);
                } catch (Exception e) {
                    System.err.println("데이터 파싱 오류: " + record);
                    e.printStackTrace();
                }
            }
        }
        return newAnimals;
    }

    private Label createSortLabel(String text) {
        Label label = new Label(text);
        label.getStyleClass().add("sort-label");
        label.setStyle("-fx-cursor: hand;");
        return label;
    }
    
    public void requestAnimalStatusUpdate(String animalId, String newStatus) {
        if (out != null) {
            System.out.println("서버에 상태 변경 요청: " + animalId + " -> " + newStatus);
            out.println("UPDATE_ANIMAL_STATUS:" + animalId + ";" + newStatus);
        } else {
            System.err.println("서버에 연결되지 않아 상태를 변경할 수 없습니다.");
        }
    }

    private void handleStatusUpdateSuccess(String payload) {
        String[] parts = payload.split(";", 2);
        String animalId = parts[0];
        String newStatus = parts[1];

        animals.stream()
               .filter(a -> a.getAnimalId().equals(animalId))
               .findFirst()
               .ifPresent(animal -> animal.setStatus(newStatus));
        
        animalListView.updateList(animals, this.userId, imageCache);

        showInfoAlert("변경 완료", "동물(" + animalId + ")의 상태가 '" + newStatus + "' (으)로 성공적으로 변경되었습니다.");
    }

    private void showInfoAlert(String title, String content) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
    
    private void showErrorAlert(String title, String content) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}