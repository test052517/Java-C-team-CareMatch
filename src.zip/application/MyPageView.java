package application;

import DAO.UserDAO;
import DAO.UserSpecificDAO;
import DAO.VisitReservationDAO;
import DTO.UserDTO;
import DTO.UserSpecificDTO;
import DTO.VisitReservationDTO;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

public class MyPageView {

    private final UserDTO currentUser;
    private UserSpecificDTO currentUserSpecific;
    private VBox reservationList;
    private final VisitReservationDAO reservationDAO;

    public MyPageView(UserDTO currentUser) {
        this.currentUser = currentUser;
        this.reservationDAO = new VisitReservationDAO();
    }

    public VBox getContent() {
        UserSpecificDAO userSpecificDao = new UserSpecificDAO();
        this.currentUserSpecific = userSpecificDao.findUserByUserId(currentUser.getUserId());

        if (currentUser == null || currentUserSpecific == null) {
            Label errorLabel = new Label("사용자 정보를 불러올 수 없습니다. 다시 로그인해주세요.");
            errorLabel.setStyle("-fx-text-fill: red; -fx-font-size: 16;");
            VBox errorBox = new VBox(errorLabel);
            errorBox.setAlignment(Pos.CENTER);
            errorBox.setPadding(new Insets(40, 60, 40, 60));
            return errorBox;
        }

        VBox content = new VBox(30);
        content.setPadding(new Insets(40, 60, 40, 60));
        content.getStyleClass().add("mypage-container");

        // Title
        Label title = new Label("마이 페이지");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 36));
        title.getStyleClass().add("page-title");

        Separator separator = new Separator();

        VBox form = new VBox(35);

        // ID
        VBox idBox = new VBox(10);
        idBox.getChildren().add(createField("ID", currentUser.getLoginId(), false, null));

        // PW
        VBox pwBox = new VBox(10);
        // 라벨 텍스트/버튼 텍스트 지정: "비밀번호 변경"
        pwBox.getChildren().add(createField("PW", "********", true, "비밀번호 변경"));

        // Phone
        VBox phoneBox = new VBox(10);
        // 라벨 텍스트/버튼 텍스트 지정: "번호 변경"
        phoneBox.getChildren().add(createField("Phone", currentUserSpecific.getPhone(), false, "번호 변경"));

        // Email
        VBox emailBox = new VBox(10);
        // 라벨 텍스트/버튼 텍스트 지정: "이메일 변경"
        emailBox.getChildren().add(createField("E-mail", currentUserSpecific.getEmail(), false, "이메일 변경"));

        form.getChildren().addAll(idBox, pwBox, phoneBox, emailBox);

        // ------------------- 예약 관리 영역 -------------------
        Label resTitle = new Label("나의 예약 목록");
        resTitle.setFont(Font.font("Arial", FontWeight.BOLD, 24));

        reservationList = new VBox(5);
        refreshReservationList();

        VBox reservationBox = new VBox(10, resTitle, reservationList);
        reservationBox.setPadding(new Insets(20, 0, 0, 0));

        content.getChildren().addAll(title, separator, form, reservationBox);

        return content;
    }

    private void refreshReservationList() {
        reservationList.getChildren().clear();
        List<VisitReservationDTO> reservations = java.util.Collections.emptyList();
        try {
            reservations = reservationDAO.findReservationsByUserId(currentUser.getUserId());
        } catch (java.sql.SQLException e) {
            e.printStackTrace();
        }
        for (VisitReservationDTO r : reservations) {
            Label label = new Label(r.getAnimalName() + " - " + r.getVisitDate() + " " + r.getVisitTime() + " - 상태: " + r.getStatus());
            reservationList.getChildren().add(label);
        }
    }

    private void showAddReservationDialog() {
        Dialog<VisitReservationDTO> dialog = new Dialog<>();
        dialog.setTitle("예약 추가");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        TextField animalField = new TextField();
        DatePicker datePicker = new DatePicker(LocalDate.now());
        TextField timeField = new TextField();
        TextField contactField = new TextField(currentUserSpecific.getPhone());
        TextArea reasonArea = new TextArea();

        grid.add(new Label("동물 이름:"), 0, 0);
        grid.add(animalField, 1, 0);
        grid.add(new Label("날짜:"), 0, 1);
        grid.add(datePicker, 1, 1);
        grid.add(new Label("시간:"), 0, 2);
        grid.add(timeField, 1, 2);
        grid.add(new Label("연락처:"), 0, 3);
        grid.add(contactField, 1, 3);
        grid.add(new Label("사유:"), 0, 4);
        grid.add(reasonArea, 1, 4);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(btn -> {
            if (btn == ButtonType.OK && datePicker.getValue() != null) {
                VisitReservationDTO res = new VisitReservationDTO();
                res.setUserId(currentUser.getUserId());
                res.setAnimalName(animalField.getText());
                res.setVisitDate(Date.valueOf(datePicker.getValue()));
                res.setVisitTime(timeField.getText());
                res.setContact(contactField.getText());
                res.setReason(reasonArea.getText());
                res.setStatus("예약완료");
                return res;
            }
            return null;
        });

        dialog.showAndWait().ifPresent(res -> {
            boolean __added = false;
            try {
                __added = reservationDAO.addReservation(res);
            } catch (java.sql.SQLException e) {
                e.printStackTrace();
            }
            if (__added) {
                refreshReservationList();
            }
        });
    }

    /**
     * @brief 필드를 생성하고 이벤트 핸들러를 설정하는 메소드
     * @details 비밀번호 필드 안내문구 추가 & 변경 버튼 스타일/동작
     */
    private HBox createField(String labelText, String value, boolean isPassword, String buttonLabel) {
        Label label = new Label(labelText);
        label.setPrefWidth(100);
        label.setFont(Font.font("Arial", 16));

        TextField field;
        if (isPassword) {
            field = new PasswordField();
            field.setPromptText("새 비밀번호를 입력하세요");
        } else {
            field = new TextField(value);
        }
        field.setPrefWidth(400);
        field.setPrefHeight(40);

        if (buttonLabel != null) {
            Button changeBtn = new Button(buttonLabel);
            changeBtn.setPrefWidth(150);
            // ★ 버튼 폰트/스타일: 맑은 고딕 13px
            changeBtn.getStyleClass().add("changeBtn");
            
            changeBtn.setOnAction(e -> {
                boolean success = false;

                if (labelText.equals("PW")) {
                    UserDAO dao = new UserDAO();
                    String newPassword = field.getText();
                    if (newPassword == null || newPassword.trim().isEmpty()) {
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setHeaderText(null);
                        alert.setContentText("새로운 비밀번호를 입력해주세요.");
                        alert.showAndWait();
                        return;
                    }
                    success = dao.updatePasswordByLoginId(currentUser.getLoginId(), newPassword);

                } else if (labelText.equals("Phone")) {
                    UserSpecificDAO dao = new UserSpecificDAO();
                    success = dao.updatePhone(currentUserSpecific.getUserId(), field.getText());

                } else if (labelText.equals("E-mail")) {
                    UserSpecificDAO dao = new UserSpecificDAO();
                    success = dao.updateEmail(currentUserSpecific.getUserId(), field.getText());
                }

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setHeaderText(null);
                if (success) {
                    alert.setContentText(labelText + " 변경 완료!");
                    if (labelText.equals("PW")) {
                        field.clear();
                    } else if (labelText.equals("Phone")) {
                        currentUserSpecific.setPhone(field.getText());
                    } else if (labelText.equals("E-mail")) {
                        currentUserSpecific.setEmail(field.getText());
                    }
                } else {
                    alert.setContentText(labelText + " 변경 실패! 다시 시도하세요.");
                }
                alert.showAndWait();
            });

            HBox box = new HBox(10, label, field, changeBtn);
            box.setAlignment(Pos.CENTER_LEFT);
            return box;
        } else {
            field.setEditable(false);
            HBox box = new HBox(10, label, field);
            box.setAlignment(Pos.CENTER_LEFT);
            return box;
        }
    }
}
