package application;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.time.LocalDate;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class AnimalDetailView extends Application {
		
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;

    // 클래스 변수에 userId 추가
    private String animalId;
    private int userId; 
    private String imageId;

    private ImageView mainImageView;
    private Label nameLabel;
    private Label infoLabel;
    private Label statusValueLabel;
    private Label shelterValueLabel;
    private Label addressValueLabel;
    private Label contactValueLabel;
	
    // 생성자에서 animalId와 userId를 모두 받도록 수정
	public AnimalDetailView(String animalId, int userId) {
        this.animalId = animalId;
        this.userId = userId;
    }

    @Override
    public void start(Stage primaryStage) {
        // 🔹 메인 레이아웃
        VBox root = new VBox(20);
        root.setPadding(new Insets(20));
        root.getStyleClass().add("root-pane");
        
        // 뒤로가기 버튼
        ImageView back = new ImageView(new Image("file:src/application/menu_icon/Back.png"));
        back.setFitWidth(35);
        back.setFitHeight(35);
        back.setPickOnBounds(true);
        StackPane backContainer = new StackPane(back);
        backContainer.getStyleClass().add("back-container");
        
        back.setOnMouseClicked(event->{
        	closeConnection();
        	MainListApp mla = new MainListApp();
        	mla.start(primaryStage);
        });
        
        HBox backBox = new HBox(20);
        backBox.setAlignment(Pos.TOP_LEFT);
        backBox.getChildren().addAll(backContainer);

        // 🔹 이미지 영역
        HBox imageBox = new HBox(20);
        imageBox.setAlignment(Pos.CENTER);

        mainImageView = new ImageView(new Image("file:resources/img_placeholder.png"));
        mainImageView.setFitHeight(400);
        mainImageView.setFitWidth(400);
        mainImageView.setPreserveRatio(true);
        mainImageView.getStyleClass().add("image-placeholder");
        
        imageBox.getChildren().add(mainImageView);

        // 🔹 이름/품종/정보
        nameLabel = new Label("로딩 중...");
        nameLabel.getStyleClass().add("name-label");
        
        infoLabel = new Label("...");
        infoLabel.getStyleClass().add("animal-info");

        VBox nameInfoBox = new VBox(5, nameLabel, infoLabel);
        nameInfoBox.setAlignment(Pos.CENTER);

        // 🔹 보호소 정보 박스
        VBox infoBox = new VBox(5);
        infoBox.getStyleClass().add("info-box");
        
        statusValueLabel = new Label();
        shelterValueLabel = new Label();
        addressValueLabel = new Label();
        contactValueLabel = new Label();

        infoBox.getChildren().addAll(
                createInfoRow("상태", statusValueLabel),
                createInfoRow("보호소", shelterValueLabel),
                createInfoRow("보호주소", addressValueLabel),
                createInfoRow("보호소 연락처", contactValueLabel)
        );

        // 🔹 입양 신청 버튼
        Button adoptButton = new Button("입양 신청");
        adoptButton.getStyleClass().add("adopt-button");
        
        // 버튼 액션에서 this.animalId와 this.userId를 사용하도록 수정
        adoptButton.setOnAction(e -> {
            // 클래스 변수에 저장된 animalId와 userId를 사용합니다.
            new AdoptionForm().showModal(primaryStage, this.animalId, this.userId);
        });

        VBox.setMargin(adoptButton, new Insets(10, 0, 0, 0));
        VBox.setMargin(nameInfoBox, new Insets(10, 10, 0, 0));

        root.getChildren().addAll(backBox,imageBox, nameInfoBox, infoBox, adoptButton);
        root.setAlignment(Pos.TOP_CENTER);

        Scene scene = new Scene(root, 1200, 800);
        scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.setTitle("입양 상세 화면");
        primaryStage.show();
        
        connectToServer();
        requestAnimalDetails();
    }
    
    private void connectToServer() {
        try {
            socket = new Socket("localhost", 9999);
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            Thread listenerThread = new Thread(() -> {
                try {
                    String serverResponse;
                    while ((serverResponse = in.readLine()) != null) {
                        processServerResponse(serverResponse);
                    }
                } catch (Exception e) {
                    System.out.println("서버 연결이 끊어졌습니다.");
                }
            });
            listenerThread.setDaemon(true);
            listenerThread.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void requestAnimalDetails() {
        if (out != null && animalId != null) {
            out.println("GET_ANIMAL_DETAIL:" + this.animalId);
        }
    }
    
    private void processServerResponse(String response) {
        Platform.runLater(() -> {
            String[] parts = response.split(":", 2);
            String command = parts[0];
            String payload = parts.length > 1 ? parts[1] : "";

            if ("ANIMAL_DETAIL".equals(command)) {
                updateUIWithAnimalData(payload);
            } else if ("IMAGE_URL".equals(command)) {
                updateImage(payload);
            } else if (response.startsWith("ERROR")) {
                System.err.println("서버 오류: " + payload);
            }
        });
    }
    
    private void updateUIWithAnimalData(String payload) {
        String[] details = payload.split(",");
        if (details.length >= 11) {
            String name = details[0];
            String kind = details[1];
            String sex = "F".equalsIgnoreCase(details[2]) ? "여아" : "남아"; 
            int birthYear = Integer.parseInt(details[3]);
            double weight = Double.parseDouble(details[4]);
            String neutered = "Y".equalsIgnoreCase(details[5]) ? "중성화 O" : "중성화 X";
            String status = details[6];
            String shelterName = details[7];
            String shelterAddress = details[8];
            String shelterTel = details[9];
            this.imageId = details[10];
            
            int currentYear = LocalDate.now().getYear();
            int age = currentYear - birthYear;

            nameLabel.setText(String.format("%s (%s)", name, kind));
            infoLabel.setText(String.format("%s | %d살 | %.1fkg | %s", sex, age, weight, neutered));
            
            statusValueLabel.setText(status);
            shelterValueLabel.setText(shelterName);
            addressValueLabel.setText(shelterAddress);
            contactValueLabel.setText(shelterTel);

            if (imageId != null && !"null".equalsIgnoreCase(imageId)) {
                out.println("GET_IMAGE:" + imageId);
            }
        }
    }
    
    private void updateImage(String payload) {
        String[] parts = payload.split(",", 2);
        if (parts.length < 2) return;
        
        String receivedImageId = parts[0];
        String imageUrl = parts[1];

        if (this.imageId != null && this.imageId.equals(receivedImageId) && !"NONE".equals(imageUrl)) {
            try {
                mainImageView.setImage(new Image(imageUrl, true));
            } catch (Exception e) {
                System.err.println("이미지 로드 실패: " + imageUrl);
            }
        }
    }

    private Region createImagePlaceholder() {
        Region region = new Region();
        region.setPrefSize(400, 400);
        region.setStyle("-fx-background-color: #EFEFEF; -fx-background-radius: 8;");
        return region;
    }

    private HBox createInfoRow(String label, Label valueLabel) {
        Label keyLabel = new Label(label);
        keyLabel.setFont(Font.font(13));
        keyLabel.setTextFill(Color.GRAY);
        keyLabel.setPrefWidth(120);

        valueLabel.setFont(Font.font(13));
        valueLabel.setWrapText(true);
        valueLabel.setMaxWidth(400);

        HBox row = new HBox(10, keyLabel, valueLabel);
        return row;
    }
    
    private void closeConnection() {
        try {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args); // 직접 실행 시 필요
    }
}