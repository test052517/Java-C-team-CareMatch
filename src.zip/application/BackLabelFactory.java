package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Hyperlink;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public final class BackLabelFactory {
    private BackLabelFactory() {}
    public static Node create(Stage stage, Runnable onBack) {
        Hyperlink back = new Hyperlink("← 뒤로가기");
        back.setFocusTraversable(false);
        back.setUnderline(false);
        back.setStyle("-fx-text-fill:#5A3222; -fx-font-size: 14px;");
        back.setOnAction(e -> {
            try { if (onBack != null) onBack.run(); }
            finally { if (stage != null) stage.close(); }
        });
        HBox bar = new HBox(back);
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setPadding(new Insets(0,0,10,0));
        return bar;
    }
}