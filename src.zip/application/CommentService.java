package application;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public final class CommentService {
    private CommentService(){}

    public static List<Comment> list(String reviewId) {
        List<Comment> out = new ArrayList<>();
        final String sql = "SELECT review_id, user_id, content, created_at FROM review_comment WHERE review_id=? ORDER BY created_at ASC";
        try (Connection con = AppDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, reviewId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    out.add(new Comment(
                            rs.getString(1), rs.getString(2), rs.getString(3), rs.getTimestamp(4)
                    ));
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return out;
    }

    public static void add(String reviewId, String userId, String content) throws SQLException {
        final String sql = "INSERT INTO review_comment(review_id, user_id, content) VALUES(?, ?, ?)";
        try (Connection con = AppDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, reviewId);
            ps.setString(2, userId);
            ps.setString(3, content);
            ps.executeUpdate();
        }
    }
}