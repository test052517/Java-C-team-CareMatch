package application;

import DAO.AdoptionDAO;
import DAO.AnimalsDAO;
import DAO.ImageDAO;
import DTO.AdoptionDTO;
import DTO.AnimalsDTO;
import DTO.ImageDTO;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.file.Paths;
import java.util.List;

public class AdoptionCheckForm {

    public static void show(int currentUserId) {
        Stage stage = new Stage();
        stage.initOwner(null); // 특정 주인 창이 없으면 null로 설정 가능
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("입양신청 확인");

        VBox root = new VBox(15);
        root.setPadding(new Insets(20));
        root.getStyleClass().add("root");

        Label headerLabel = new Label("입양신청 확인");
        headerLabel.getStyleClass().add("header-label");

        // --- 1. DAO를 통해 현재 사용자의 입양 신청 목록을 가져옵니다.
        AdoptionDAO dao = new AdoptionDAO();
        List<AdoptionDTO> adoptionList = dao.getAdoptionsByUser(currentUserId);

        // --- 2. UI 요소 생성 ---
        Label titleLabel = new Label("📄 입양신청 확인");
        titleLabel.getStyleClass().add("section-title");

        ComboBox<String> animalSelect = new ComboBox<>();
        if (adoptionList != null && !adoptionList.isEmpty()) {
            animalSelect.getItems().addAll(adoptionList.stream().map(AdoptionDTO::getAnimalName).toList());
            animalSelect.setValue(animalSelect.getItems().getFirst());
        }
        animalSelect.setPromptText("🐾 신청한 동물 선택");
        animalSelect.setPrefWidth(250);

        Label adoptLabel = new Label("🐶 입양 대상: ");
        adoptLabel.getStyleClass().add("info-label");
        Label dateLabel = new Label("📅 신청일자: ");
        dateLabel.getStyleClass().add("info-label");
        Label statusLabel = new Label("📌 상태: ");
        statusLabel.getStyleClass().add("info-label");
        Label msgArea = new Label("\"관리자의 승인 후 방문 예약이 가능합니다.\"");

        // --- 3. 이미지를 표시할 ImageView 생성 ---
        ImageView animalImageView = new ImageView();
        animalImageView.setFitWidth(150);
        animalImageView.setFitHeight(150);
        animalImageView.setPreserveRatio(true);
        animalImageView.setStyle("-fx-border-color: lightgray; -fx-border-width: 1;");

        // --- 4. 텍스트 정보와 이미지를 수평으로 배치할 HBox 생성 ---
        VBox detailText = new VBox(10, adoptLabel, dateLabel, statusLabel, msgArea);
        HBox detailRow = new HBox(20, detailText, animalImageView);
        detailRow.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(detailText, Priority.ALWAYS);

        Button checkBtn = new Button("확인");
        checkBtn.setPrefWidth(190);
        checkBtn.setOnAction(event -> stage.close());
        VBox checkBox = new VBox(checkBtn);
        checkBox.setAlignment(Pos.BOTTOM_CENTER);

        // --- 5. ComboBox 선택 변경 시 화면을 업데이트하는 핸들러 ---
        animalSelect.setOnAction(event -> {
            int selectedIndex = animalSelect.getSelectionModel().getSelectedIndex();
            if (selectedIndex >= 0) {
                AdoptionDTO selectedAdoption = adoptionList.get(selectedIndex);

                // 텍스트 정보 업데이트
                adoptLabel.setText("🐶 입양 대상: " + selectedAdoption.getAnimalName());
                dateLabel.setText("📅 신청일자: " + selectedAdoption.getSubmittedDate());
                statusLabel.setText("📌 상태: " + selectedAdoption.getStatus());

                if ("승인".equalsIgnoreCase(selectedAdoption.getStatus())) {
                    msgArea.setText("승인되었습니다. 방문 예약을 진행해주세요.");
                } else {
                    msgArea.setText("\"관리자의 승인 후 방문 예약이 가능합니다.\"");
                }

                // 이미지 정보 업데이트
                try {
                    // A. animal_id를 이용해 Animals 테이블 조회
                    AnimalsDAO animalsDAO = new AnimalsDAO();
                    AnimalsDTO animal = animalsDAO.findAnimalById(selectedAdoption.getAnimalId());

                    if (animal != null && animal.getImageId() != null) {
                        // B. image_id를 이용해 Image 테이블 조회
                        ImageDAO imageDAO = new ImageDAO();
                        ImageDTO imageDTO = imageDAO.findImageById(animal.getImageId());

                        // C. 이미지 객체로 변환하여 ImageView에 설정
                        Image imageToShow = resolveImage(imageDTO);
                        animalImageView.setImage(imageToShow);
                    } else {
                        animalImageView.setImage(null); // 정보가 없으면 이미지 제거
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    animalImageView.setImage(null); // 오류 시 이미지 제거
                }
            }
        });

        // --- 초기 화면 설정 ---
        // ComboBox의 첫 항목을 기준으로 초기 정보를 표시하기 위해 이벤트를 강제로 발생시킴
        if (!animalSelect.getItems().isEmpty()) {
            animalSelect.fireEvent(new javafx.event.ActionEvent());
        }

        // --- 레이아웃 구성 ---
        VBox contentBox = new VBox(20);
        contentBox.getStyleClass().add("content-box");
        contentBox.getChildren().addAll(animalSelect, detailRow);
        
        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);

        root.getChildren().addAll(headerLabel, titleLabel, contentBox, spacer, checkBox);

        Scene scene = new Scene(root, 600, 800);
        try {
            scene.getStylesheets().add(AdoptionCheckForm.class.getResource("adoption-check.css").toExternalForm());
        } catch (Exception e) {
            System.out.println("CSS 파일을 로드할 수 없습니다: adoption-check.css");
        }

        stage.setScene(scene);
        stage.showAndWait();
    }

    /**
     * ImageDTO 객체를 JavaFX Image 객체로 변환하는 헬퍼 메서드
     */
    private static Image resolveImage(ImageDTO img) {
        if (img == null) return null;
        try {
            // URL 기반 이미지 로드
            String url = img.getImageUrl();
            if (url != null && !url.trim().isEmpty()) {
                if (url.trim().startsWith("http")) {
                    return new Image(url.trim(), true);
                }
                File f = new File(url.trim());
                if (f.exists()) {
                    return new Image(f.toURI().toString(), true);
                }
            }
            // BLOB 데이터 기반 이미지 로드
            if (img.getImageData() != null && img.getImageData().length > 0) {
                return new Image(new ByteArrayInputStream(img.getImageData()));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}