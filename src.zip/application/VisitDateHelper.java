
package application;

import DAO.VisitReservationDAO;
import DTO.VisitReservationDTO;
import javafx.scene.control.Label;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

/**
 * 디자인 변경 없이 라벨 텍스트만 교체하기 위한 헬퍼.
 * - "방문일자: 미정" 라벨에 최신 예약 visit_date가 있으면 그 날짜를 세팅.
 * - 카드/목록 UI 레이아웃은 그대로 유지.
 */
public final class VisitDateHelper {

    private VisitDateHelper() {}

    public static void fillLatestVisitDate(Label visitDateLabel, int userId, String animalKey) {
        if (visitDateLabel == null) return;
        String text = visitDateLabel.getText(); // 기존 텍스트 유지 (대개 "방문일자: 미정")
        try {
            VisitReservationDAO dao = new VisitReservationDAO();
            VisitReservationDTO latest = dao.findLatestByUserAndAnimalLoose(userId, animalKey);
            if (latest != null) {
                LocalDate ld = null;
                try {
                    Object v = latest.getClass().getMethod("getVisitDate").invoke(latest);
                    if (v instanceof java.sql.Date) {
                        ld = ((java.sql.Date) v).toLocalDate();
                    } else if (v instanceof Date) {
                        ld = new java.sql.Date(((Date) v).getTime()).toLocalDate();
                    } else if (v instanceof LocalDate) {
                        ld = (LocalDate) v;
                    }
                } catch (Throwable ignore) {}
                if (ld != null) {
                    text = "방문일자: " + ld.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            // 반사 호출 예외 무시
        }
        visitDateLabel.setText(text);
    }
}
