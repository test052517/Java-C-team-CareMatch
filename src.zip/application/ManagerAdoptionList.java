package application;

import DTO.AdoptionDTO;
import DAO.AdoptionDAO;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import application.ui.SidebarView;

public class ManagerAdoptionList {

    private boolean isApplyDateAsc = true;
    private boolean isVisitDateAsc = true;
    private int statusFilterIndex = 0; // 0: 전체 보기

    // "입양 거절" 상태 추가
    private static final List<String> statusOrder = Arrays.asList(
            "승인 미완료", "입양 승인", "방문 예약", "입양 완료", "입양 거절"
    );

    private List<AdoptionDTO> applications;
    private VBox applicationListView = new VBox(10);

    public Pane getView() {
        BorderPane root = new BorderPane();
        root.getStyleClass().add("root");

        Font.loadFont(getClass().getResource("/resources/Pretendard-Medium.ttf").toExternalForm(), 12);
        Font.loadFont(getClass().getResource("/resources/Pretendard-Bold.ttf").toExternalForm(), 12);
        Font.loadFont(getClass().getResource("/resources/Pretendard-ExtraBold.ttf").toExternalForm(), 12);

        root.setLeft(new SidebarView());

        applicationListView.getStyleClass().add("application-list");

        ScrollPane scrollPane = new ScrollPane(applicationListView);
        scrollPane.setFitToWidth(true);
        scrollPane.getStyleClass().add("scroll-pane");

        // --- 상단 헤더 ---
        HBox header = new HBox(10);
        header.setPadding(new Insets(10));
        header.setAlignment(Pos.CENTER_LEFT);
        Label title = new Label("입양 신청 관리");
        title.getStyleClass().add("title");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        header.getChildren().addAll(title, spacer);

        // --- 정렬 바 ---
        HBox sortBarContainer = new HBox(20);
        sortBarContainer.setAlignment(Pos.CENTER);
        sortBarContainer.setPadding(new Insets(10));
        sortBarContainer.setMinHeight(50);
        sortBarContainer.getStyleClass().add("sort-bar-container");

        Label sortApplyDate = createSortLabel("신청 일자");
        Label sortVisitDate = createSortLabel("방문 일자");
        Label sortStatus = createSortLabel("진행 상태");

        List<Label> allLabels = Arrays.asList(sortApplyDate, sortVisitDate, sortStatus);
        allLabels.forEach(lbl -> {
            lbl.setMaxWidth(Double.MAX_VALUE);
            HBox.setHgrow(lbl, Priority.ALWAYS);
            lbl.setAlignment(Pos.CENTER);
        });
        sortBarContainer.getChildren().addAll(allLabels);

        // --- 정렬 및 필터링 이벤트 핸들러 ---
        sortApplyDate.setOnMouseClicked(e -> {
            isApplyDateAsc = !isApplyDateAsc;
            sortApplyDate.setText("신청 일자 " + (isApplyDateAsc ? "↑" : "↓"));
            applications.sort(Comparator.comparing(AdoptionDTO::getSubmittedDate));
            if (!isApplyDateAsc) java.util.Collections.reverse(applications);
            updateApplicationList();
        });

        sortVisitDate.setOnMouseClicked(e -> {
            isVisitDateAsc = !isVisitDateAsc;
            sortVisitDate.setText("방문 일자 " + (isVisitDateAsc ? "↑" : "↓"));
            applications.sort(Comparator.comparing(AdoptionDTO::getVisitDate, Comparator.nullsLast(LocalDate::compareTo)));
            if (!isVisitDateAsc) java.util.Collections.reverse(applications);
            updateApplicationList();
        });

        sortStatus.setOnMouseClicked(e -> {
            statusFilterIndex = (statusFilterIndex + 1) % (statusOrder.size() + 1);
            String label = (statusFilterIndex == 0) ? "전체 보기" : statusOrder.get(statusFilterIndex - 1);
            sortStatus.setText("진행 상태: " + label);
            updateApplicationList();
        });

        // --- 초기 데이터 로드 및 화면 구성 ---
        refreshList(); // DB에서 데이터를 불러와 화면을 최초로 그림

        VBox centerPane = new VBox(10, header, sortBarContainer, scrollPane);
        centerPane.setPadding(new Insets(20));

        root.setCenter(centerPane);
        return root;
    }

    private Label createSortLabel(String text) {
        Label label = new Label(text);
        label.getStyleClass().add("sort-label");
        label.setStyle("-fx-cursor: hand;");
        return label;
    }

    // 화면의 카드 목록을 업데이트하는 메서드
    private void updateApplicationList() {
        applicationListView.getChildren().clear();
        String currentFilter = (statusFilterIndex <= 0) ? null : statusOrder.get(statusFilterIndex - 1);

        for (AdoptionDTO app : applications) {
            if (currentFilter == null || app.getStatus().equals(currentFilter)) {
                // AdoptionCard 생성 시 ManagerAdoptionList의 인스턴스(this)를 전달
                AdoptionCard card = new AdoptionCard(app, this);

                // 카드 내부에서 상태 변경 시 목록을 새로고침하도록 콜백 설정
                card.setOnStatusChanged(this::refreshList);

                applicationListView.getChildren().add(card);
            }
        }
    }

    /**
     * DB에서 입양 신청 목록을 다시 불러와 화면을 새로고침합니다.
     */
    public void refreshList() {
        AdoptionDAO dao = new AdoptionDAO();
        this.applications = dao.getAllAdoptions();
        updateApplicationList();
    }
}
