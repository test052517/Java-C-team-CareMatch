package application;

import DAO.ReviewDAO;
import DAO.ReviewLikeDAO; // ReviewLikeDAO를 import 합니다.
import DTO.ReviewDTO;
import application.ui.ReviewListView;
import application.ui.SidebarView;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ManagerReviewList {

    private List<ReviewDTO> reviews; // 데이터 타입을 ReviewDTO로 변경
    private ReviewDAO reviewDAO = new ReviewDAO();
    private ReviewListView reviewListView;

    private boolean isLikesAsc = false;
    private boolean isDateAsc = true;
    private boolean isBestFirst = false;

    public Pane getView() {
        BorderPane root = new BorderPane();
        root.getStyleClass().add("root");
        // 폰트 로딩
        Font.loadFont(getClass().getResource("/resources/Pretendard-Medium.ttf").toExternalForm(), 12);
        Font.loadFont(getClass().getResource("/resources/Pretendard-Bold.ttf").toExternalForm(), 12);
        Font.loadFont(getClass().getResource("/resources/Pretendard-ExtraBold.ttf").toExternalForm(), 12);
		
        root.setLeft(new SidebarView());
        
        // DB에서 후기 목록 불러오기 (내부 로직 변경)
        loadReviewsFromDatabase();
        
        // ReviewListView 초기화 시 DB 데이터와 새로고침 메서드 전달
        reviewListView = new ReviewListView(reviews, this::refreshReviewList);

        ScrollPane scrollPane = new ScrollPane(reviewListView);
        scrollPane.setFitToWidth(true);
        
        // --- 상단 헤더 및 정렬 바 ---
        HBox header = new HBox();
        header.setPadding(new Insets(10));
        header.setAlignment(Pos.CENTER_LEFT);
        header.setSpacing(10);
        
        Label title = new Label("후기 게시판 관리");
        title.getStyleClass().add("title");
        
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        header.getChildren().addAll(title, spacer);
	    
        HBox sortBar = new HBox(20);
        sortBar.setPrefWidth(600);
        sortBar.setAlignment(Pos.CENTER);
	    
        Label sortDate = createSortLabel("작성 일자");
        Label sortLikes = createSortLabel("좋아요 수");
        Label sortBest = createSortLabel("우수 후기"); // '좋아요' 많은 순으로 정렬
	    
        sortBar.getChildren().addAll(sortDate, sortLikes, sortBest);
        
        HBox sortBarContainer = new HBox(sortBar);
        sortBarContainer.setPadding(new Insets(8));
        sortBarContainer.getStyleClass().add("sort-bar-container");
        sortBarContainer.setPrefWidth(620);

        // --- 정렬 이벤트 핸들러 ---
        sortDate.setOnMouseClicked(e -> {
            isDateAsc = !isDateAsc;
            sortDate.setText("작성 일자 " + (isDateAsc ? "↑" : "↓"));
            reviews.sort(Comparator.comparing(ReviewDTO::getCreatedDate));
            if (!isDateAsc) {
                reviews.sort(Comparator.comparing(ReviewDTO::getCreatedDate).reversed());
            }
            reviewListView.updateList(reviews);
        });

        sortLikes.setOnMouseClicked(e -> {
            isLikesAsc = !isLikesAsc;
            sortLikes.setText("좋아요 수 " + (isLikesAsc ? "↑" : "↓"));
            reviews.sort(Comparator.comparingInt(ReviewDTO::getLikeCount));
            if (!isLikesAsc) {
                reviews.sort(Comparator.comparingInt(ReviewDTO::getLikeCount).reversed());
            }
            reviewListView.updateList(reviews);
        });

        sortBest.setOnMouseClicked(e -> {
            isBestFirst = !isBestFirst;
            sortBest.setText("우수 후기 " + (isBestFirst ? "↓" : "↑"));
            // '우수 후기'를 '좋아요'가 많은 순으로 정렬
            if (isBestFirst) {
                reviews.sort(Comparator.comparingInt(ReviewDTO::getLikeCount).reversed());
            } else {
                reviews.sort(Comparator.comparingInt(ReviewDTO::getLikeCount));
            }
            reviewListView.updateList(reviews);
        });
        
        VBox centerPane = new VBox(10);
        centerPane.setPadding(new Insets(20));
        centerPane.getChildren().addAll(header, sortBarContainer, scrollPane);

        root.setCenter(centerPane);

        return root;
    }
    
    /**
     * DB에서 데이터를 가져오는 메서드 (좋아요 수 갱신 로직 추가)
     */
    private void loadReviewsFromDatabase() {
        // 1. ReviewDAO를 통해 기본적인 리뷰 목록을 가져옵니다. (ReviewDAO는 수정하지 않음)
        this.reviews = reviewDAO.findAllReviews();

        // 2. 새로 만든 ReviewLikeDAO를 이용해 각 리뷰의 실제 좋아요 수를 갱신합니다.
        ReviewLikeDAO reviewLikeDAO = new ReviewLikeDAO();
        for (ReviewDTO review : this.reviews) {
            // 2-1. 각 리뷰의 ID로 실제 좋아요 수를 DB에서 조회
            int realLikeCount = reviewLikeDAO.countLikes(review.getReviewId());
            // 2-2. DTO 객체의 likeCount 값을 실제 값으로 덮어씁니다.
            review.setLikeCount(realLikeCount);
        }
    }

    /**
     * 목록을 새로고침하는 메서드
     */
    private void refreshReviewList() {
        loadReviewsFromDatabase(); // 좋아요 수를 새로고침하는 로직이 포함된 메서드 호출
        reviewListView.updateList(reviews);
    }
    
    private Label createSortLabel(String text) {
        Label label = new Label(text);
        label.getStyleClass().add("sort-label");
        label.setStyle("-fx-cursor: hand;");
        return label;
    }
}