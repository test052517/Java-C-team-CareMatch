package application;

import DTO.ReviewDTO;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import DAO.ReviewImageDAO;
import DTO.ReviewImageDTO;
import java.io.ByteArrayInputStream;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.text.SimpleDateFormat;

/**
 * 후기 상세보기 (정사각형 이미지 프레임)
 * - 헤더 아래 좌측 뒤로가기
 * - 제목 위 이미지 프레임을 "정사각형"으로 고정
 * - 내용과 버튼 사이 간격은 BUTTON_TOP_GAP으로 제어
 */
public class ReviewDetailForm {

    /** 정사각형 이미지 한 변(px) — 숫자만 바꾸면 크기 조절됩니다. */
    private static final double IMAGE_SIZE = 260;
    /** 내용 아래 버튼 위 여백(px) */
    private static final double BUTTON_TOP_GAP = 28;

    private final ReviewDTO review;
    private final String currentUserId;

    public static void open(ReviewDTO review, Stage owner, String userId) {
        new ReviewDetailForm(review, userId).showModal(owner);
    }

    public ReviewDetailForm(ReviewDTO review, String currentUserId) {
        this.review = review;
        this.currentUserId = (currentUserId != null && !currentUserId.isEmpty()) ? currentUserId : CurrentUser.get();
    }
    public ReviewDetailForm(ReviewDTO review) { this(review, CurrentUser.get()); }

    public void showModal() { showModal(null); }

    public void showModal(Stage owner) {
        Stage modal = new Stage();
        modal.initModality(Modality.APPLICATION_MODAL);
        if (owner != null) modal.initOwner(owner);
        modal.setTitle("후기 상세보기 - " + currentUserId);
        modal.setResizable(false);

        VBox root = new VBox();
        root.setSpacing(12);
        root.setPadding(new Insets(14));
        root.getStyleClass().add("review-detail-root");

        // 1) 헤더
        Label header = new Label("후기 상세보기");
        header.getStyleClass().add("detail-header");
        HBox headerBox = new HBox(header);
        headerBox.setAlignment(Pos.CENTER_LEFT);
        headerBox.getStyleClass().add("detail-header-box");
        root.getChildren().add(headerBox);

        // 2) 뒤로가기 (헤더 바로 아래)
        Node back = BackLabelFactory.create(modal, null);
        HBox backWrap = new HBox(back);
        backWrap.setAlignment(Pos.CENTER_LEFT);
        VBox.setMargin(backWrap, new Insets(6, 0, 0, 0));
        root.getChildren().add(backWrap);

        // 3) 본문 상단 정보
        VBox center = new VBox(10);
        center.setAlignment(Pos.TOP_CENTER);

        // 정사각형 이미지 프레임
        StackPane imageFrame = new StackPane();
        imageFrame.getStyleClass().add("image-frame");
        ImageView imageView = new ImageView();
        imageView.setPreserveRatio(true);
        imageView.setFitWidth(IMAGE_SIZE);
        imageView.setFitHeight(IMAGE_SIZE);
        Label placeholder = new Label("임시사진");
        placeholder.getStyleClass().add("image-placeholder");
        try {
            ReviewImageDTO rimg = new ReviewImageDAO().findByReviewId(review.getReviewId());
            if (rimg != null && rimg.getImageData() != null && rimg.getImageData().length > 0) {
                imageView.setImage(new Image(new ByteArrayInputStream(rimg.getImageData())));
                placeholder.setVisible(false);
            }
        } catch (Exception ex) { /* ignore */ }
        imageFrame.getChildren().addAll(imageView, placeholder);

        Label postTitle = new Label("제목: " + safe(review.getTitle()));
        postTitle.getStyleClass().add("post-title");

        Label writerLabel = new Label("작성자: " + (review.getUserName()!=null?review.getUserName():safe(review.getUserId())));
        writerLabel.getStyleClass().add("post-writer");

        String dateStr = review.getCreatedDate()!=null? new SimpleDateFormat("yyyy.MM.dd").format(review.getCreatedDate()):"";
        Label dateLabel = new Label("날짜: " + dateStr);
        dateLabel.getStyleClass().add("post-date");

        Label likeCountLabel = new Label();
        likeCountLabel.getStyleClass().add("like-count");
        final String reviewId = review.getReviewId();
        refreshLikeCount(likeCountLabel, reviewId);

        center.getChildren().addAll(imageFrame, postTitle, writerLabel, dateLabel, likeCountLabel);

        // 4) 내용
        VBox contentBox = new VBox(8);
        Label contentTitle = new Label("내용");
        String content = safe(review.getContent());
        TextArea contentArea = new TextArea(content.isEmpty() ? "내용이 없습니다." : content);
        contentArea.setEditable(false);
        contentArea.setWrapText(true);
        contentArea.getStyleClass().add("detail-content");
        contentArea.setPrefRowCount(10);
        contentBox.getChildren().addAll(contentTitle, contentArea);

        // 5) 버튼
        Button likeBtn = new Button("좋아요");
        likeBtn.getStyleClass().addAll("btn", "btn-like");
        boolean likedInit = LikeService.isLiked(reviewId, currentUserId);
        setHeartGraphic(likeBtn, likedInit);

        Button replyBtn = new Button("댓글창");
        replyBtn.getStyleClass().addAll("btn", "btn-reply");

        HBox buttons = new HBox(24, likeBtn, replyBtn);
        buttons.setAlignment(Pos.CENTER);
        VBox.setMargin(buttons, new Insets(BUTTON_TOP_GAP, 0, 0, 0));

        likeBtn.setOnAction(e -> {
            try {
                boolean likedNow = LikeService.toggleLike(reviewId, currentUserId);
                setHeartGraphic(likeBtn, likedNow);
                refreshLikeCount(likeCountLabel, reviewId);
            } catch (Exception ex) {
                new Alert(Alert.AlertType.ERROR, "좋아요 처리 중 오류가 발생했습니다.\n" + ex.getMessage()).showAndWait();
            }
        });
        replyBtn.setOnAction(e -> new CommentsDialog(reviewId, currentUserId, modal).showAndWait());

        root.getChildren().addAll(center, contentBox, buttons);

        Scene scene = new Scene(root, 640, 800);
        try { scene.getStylesheets().add(getClass().getResource("review-detail.css").toExternalForm()); } catch (Exception ignore) {}
        try { scene.getStylesheets().add(getClass().getResource("comments.css").toExternalForm()); } catch (Exception ignore) {}
        scene.setOnKeyPressed(ev -> { if (ev.getCode()==KeyCode.ESCAPE) modal.close(); });
        modal.setScene(scene);
        modal.show();
    }

    private void refreshLikeCount(Label label, String reviewId) {
        int count = LikeService.getLikeCount(reviewId);
        label.setText("♥ " + count + "명이 좋아합니다");
    }

    private void setHeartGraphic(Button btn, boolean liked) {
        String iconPath = liked ? "menu_icon/redheart.png" : "menu_icon/whiteheart.png";
        try {
            Image img = new Image(getClass().getResourceAsStream(iconPath));
            ImageView iv = new ImageView(img);
            iv.setFitWidth(18);
            iv.setFitHeight(18);
            btn.setGraphic(iv);
            btn.setContentDisplay(javafx.scene.control.ContentDisplay.LEFT);
        } catch (Exception ignore) { btn.setGraphic(null); }
    }

    private static String safe(String s) { return s == null ? "" : s; }
}
