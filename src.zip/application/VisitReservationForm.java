package application;

import DB.DBConnect;
import DAO.UserSpecificDAO;
import DTO.UserSpecificDTO;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class VisitReservationForm extends Stage {

    // ✨ 1. AnimalInfo 클래스에 '입양 상태'를 저장할 adoptionStatus 필드 추가
    private static class AnimalInfo {
        private final String name;
        private final String adoptionStatus; // 입양 신청의 상태 ('승인', '진행중' 등)

        public AnimalInfo(String name, String adoptionStatus) {
            this.name = name;
            this.adoptionStatus = adoptionStatus;
        }

        public String getName() { return name; }
        public String getAdoptionStatus() { return adoptionStatus; }

        @Override
        public String toString() { return name; }
    }

    private final Label statusLabel = new Label("현재 상태: -");

    public VisitReservationForm() {
        int currentUserId = SessionManager.getInstance().getLoggedInUserId();

        setTitle("방문 예약");
        setWidth(600);
        setHeight(800);

        // ... (이전과 동일한 UI 구성 요소 초기화 코드는 생략하지 않고 모두 포함) ...
        VBox root = new VBox(20);
        root.setPadding(new Insets(30));

        Label header = new Label("방문 예약");
        header.getStyleClass().add("title-label");

        VBox formBox = new VBox(15);
        UserSpecificDAO userDao = new UserSpecificDAO();
        UserSpecificDTO user = userDao.findUserByUserId(currentUserId);
        Label nameLabel = new Label("이름:");
        TextField nameField = new TextField(user != null ? user.getName() : "");
        nameField.setDisable(true);
        Label contactLabel = new Label("연락처:");
        TextField contactField = new TextField(user != null ? user.getPhone() : "");
        Label emailLabel = new Label("이메일:");
        TextField emailField = new TextField(user != null ? user.getEmail() : "");
        Label reasonLabel = new Label("방문 사유:");
        TextArea reasonArea = new TextArea();
        reasonArea.setPrefRowCount(3);
        Label dateLabel = new Label("📅 날짜 선택");
        DatePicker datePicker = new DatePicker(LocalDate.now());
        Label timeLabel = new Label("🕒 시간 선택");
        ComboBox<String> timeBox = new ComboBox<>();
        timeBox.getItems().addAll("오전9시","오전10시","오전11시","오후12시","오후1시","오후2시","오후3시","오후4시","오후5시");
        timeBox.setValue("오전9시");
        HBox timeHBox = new HBox(20);
        VBox timeVBox = new VBox(8, dateLabel, datePicker);
        VBox timeVBox2 = new VBox(8, timeLabel, timeBox);
        timeHBox.getChildren().addAll(timeVBox, timeVBox2);
        Label animalLabel = new Label("입양 동물을 선택해 주세요");
        ComboBox<AnimalInfo> animalCombo = new ComboBox<>();
        animalCombo.setPrefWidth(400);
        statusLabel.setStyle("-fx-font-weight: bold;");
        // ... (UI 구성 요소 초기화 끝) ...


        // ✨ 2. 동물의 이름과 '입양 신청 상태'를 함께 조회하는 메서드 호출
        List<AnimalInfo> userAnimals = fetchUserAnimalsWithAdoptionStatus(currentUserId);
        animalCombo.getItems().setAll(userAnimals);

        animalCombo.setConverter(new StringConverter<AnimalInfo>() {
            @Override public String toString(AnimalInfo obj) { return obj == null ? "" : obj.getName(); }
            @Override public AnimalInfo fromString(String string) { return null; }
        });

        Button submitBtn = new Button("예약 완료");
        submitBtn.getStyleClass().add("submit-button");
        submitBtn.setDisable(true);

        animalCombo.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal == null) {
                updateStatusUI("-", Color.BLACK, true, submitBtn);
                return;
            }

            Task<String> fetchStatusTask = new Task<>() {
                @Override
                protected String call() throws Exception {
                    return fetchLatestVisitStatusForAnimal(currentUserId, newVal.getName());
                }
            };

            fetchStatusTask.setOnSucceeded(e -> {
                String visitStatus = fetchStatusTask.getValue().trim(); // 방문 예약 상태
                String adoptionStatus = newVal.getAdoptionStatus().trim(); // 입양 신청 상태

                // ✨ 3. 새로운 버튼 활성화 로직 적용
                boolean canReserve = "승인".equals(visitStatus) ||
                                     ("예약가능".equals(visitStatus) && "승인".equals(adoptionStatus));

                if (canReserve) {
                    // 방문 기록이 없는 '승인' 상태일 경우, 레이블은 '예약가능'으로 표시
                    String displayStatus = "승인".equals(visitStatus) ? visitStatus : "예약가능";
                    updateStatusUI(displayStatus, Color.BLUE, false, submitBtn);
                } else {
                    updateStatusUI(visitStatus, Color.ORANGE, true, submitBtn);
                }
            });

            fetchStatusTask.setOnFailed(e -> {
                updateStatusUI("상태 조회 실패", Color.RED, true, submitBtn);
                fetchStatusTask.getException().printStackTrace();
            });

            new Thread(fetchStatusTask).start();
        });

        // ... (submitBtn.setOnAction, 폼 조립, Scene 설정 등 나머지 코드는 이전과 동일)
        submitBtn.setOnAction(e -> {
            AnimalInfo selectedAnimal = animalCombo.getSelectionModel().getSelectedItem();
            if (selectedAnimal == null) { showAlert("동물을 선택해주세요."); return; }
            String currentStatusText = statusLabel.getText();
            if (!currentStatusText.contains("승인") && !currentStatusText.contains("예약가능")) {
                 showAlert("예약 가능한 상태가 아닙니다."); return;
            }
            LocalDate visitDate = datePicker.getValue();
            if (visitDate == null) { showAlert("날짜를 선택해주세요."); return; }
            String visitTime = timeBox.getValue();
            String contact = contactField.getText();
            String reason = reasonArea.getText();
            boolean success = insertVisitReservation(
                    currentUserId, selectedAnimal.getName(), visitDate, visitTime, contact, reason, "예약완료");
            if (success) {
                showAlert("예약이 완료되었습니다.");
                this.close();
            } else {
                showAlert("예약 중 오류가 발생했습니다.");
            }
        });

        HBox submitBox = new HBox(submitBtn);
        submitBox.setAlignment(Pos.CENTER);
        formBox.getChildren().addAll(nameLabel, nameField, contactLabel, contactField, emailLabel, emailField,
                reasonLabel, reasonArea, timeHBox, animalLabel, animalCombo, statusLabel, submitBox);
        root.getChildren().addAll(header, formBox);
        Scene scene = new Scene(root);
        try {
            var url = getClass().getResource("AdoptionForm.css");
            if (url != null) scene.getStylesheets().add(url.toExternalForm());
        } catch (Exception ex) {
            System.err.println("[WARN] CSS 적용 중 오류: " + ex.getMessage());
        }
        setScene(scene);
    }

    private void updateStatusUI(String status, Color color, boolean disableButton, Button submitBtn) {
        statusLabel.setText("현재 상태: " + status);
        statusLabel.setTextFill(color);
        submitBtn.setDisable(disableButton);
    }

    // ✨ 4. 메서드 이름 변경 및 로직 확인 (기존 fetchLatestStatusForAnimal 과 동일)
    private String fetchLatestVisitStatusForAnimal(int userId, String animalName) {
        String sql = "SELECT status FROM visit_reservations " +
                     "WHERE user_id = ? AND animal_name = ? " +
                     "ORDER BY created_at DESC LIMIT 1";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            pstmt.setString(2, animalName);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getString("status");
            } else {
                return "예약가능";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "오류";
        }
    }

    // ✨ 5. '입양 신청 상태'를 함께 조회하도록 SQL 수정
    private List<AnimalInfo> fetchUserAnimalsWithAdoptionStatus(int userId) {
        // Adoption 테이블에 입양 진행 상태를 나타내는 'status' 컬럼이 있다고 가정합니다.
        String sql = "SELECT a.animal_name, ad.status FROM Animals a " +
                     "JOIN Adoption ad ON a.animal_id = ad.animal_id " +
                     "WHERE ad.user_id = ? ORDER BY a.animal_name";

        List<AnimalInfo> animals = new ArrayList<>();
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                String name = rs.getString("animal_name");
                String adoptionStatus = rs.getString("status");
                animals.add(new AnimalInfo(name, adoptionStatus));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return animals;
    }

    private boolean insertVisitReservation(int userId, String animalName, LocalDate date, String time, String contact, String reason, String status) {
        String sql = "INSERT INTO visit_reservations (user_id, animal_name, visit_date, visit_time, contact, reason, status) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            pstmt.setString(2, animalName);
            pstmt.setDate(3, java.sql.Date.valueOf(date));
            pstmt.setString(4, time);
            pstmt.setString(5, contact);
            pstmt.setString(6, reason);
            pstmt.setString(7, status);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("알림");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}