package application;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.OverrunStyle;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.text.SimpleDateFormat;

/**
 * 댓글 다이얼로그(채팅형)
 * - 베이지 테마 적용 (comments.css)
 * - 입력칸 높이 업 + 파란 포커스 제거 (comment-input)
 * - 말풍선 여백/간격/최대폭 CSS 클래스 부여
 * - 전송 버튼 라벨 '전송'
 */
public class CommentsDialog extends Stage {

    private final String reviewId;
    private final String userIdHint; // 전달받은 사용자 힌트(없으면 CurrentUser 사용)

    private final ObservableList<Comment> comments = FXCollections.observableArrayList();
    private final ListView<Comment> listView = new ListView<>(comments);
    private final TextField input = new TextField();

    public CommentsDialog(String reviewId, String userId, Stage owner) {
        this.reviewId = reviewId;
        this.userIdHint = userId;

        String me = (userId != null && !userId.isEmpty()) ? userId : CurrentUser.get();
        setTitle("댓글 - " + me);
        initModality(Modality.APPLICATION_MODAL);
        if (owner != null) initOwner(owner);
        setResizable(false);

        BorderPane root = new BorderPane();
        root.getStyleClass().add("chat-root");

        // Header
        Label headerLabel = new Label("댓글창");
        headerLabel.getStyleClass().add("chat-header-title");
        HBox header = new HBox(headerLabel);
        header.getStyleClass().add("chat-header");
        root.setTop(header);

        // List
        listView.setFocusTraversable(false);
        listView.setCellFactory(lv -> new ChatCell(lv, me));
        root.setCenter(listView);

        // Input bar
        HBox bar = new HBox(10);
        bar.getStyleClass().add("chat-input-bar");

        input.setPromptText("메시지를 입력하세요...");
        input.getStyleClass().add("comment-input"); // CSS로 높이/포커스 제거
        input.setPrefHeight(44);
        input.setMinHeight(44);
        input.setOnAction(e -> send());

        Button sendBtn = new Button("등록");
        sendBtn.getStyleClass().add("chat-send");
        sendBtn.setOnAction(e -> send());

        HBox.setHgrow(input, Priority.ALWAYS);
        bar.getChildren().addAll(input, sendBtn);
        root.setBottom(bar);

        Scene scene = new Scene(root, 620, 560);
        try { scene.getStylesheets().add(getClass().getResource("comments.css").toExternalForm()); } catch (Exception ignore) {}
        // ESC 닫기
        scene.setOnKeyPressed(ev -> { if (ev.getCode()== KeyCode.ESCAPE) close(); });
        setScene(scene);

        refresh();
        listView.scrollTo(comments.size() - 1);
    }

    private void refresh() {
        comments.setAll(CommentService.list(reviewId));
        listView.scrollTo(comments.size() - 1);
    }

    private void send() {
        String text = input.getText();
        if (text == null || text.trim().isEmpty()) return;
        try {
            String me = (userIdHint != null && !userIdHint.isEmpty()) ? userIdHint : CurrentUser.get();
            CommentService.add(reviewId, me, text.trim()); // 항상 실제 로그인 ID 기록
            input.clear();
            refresh();
        } catch (Exception ex) {
            new Alert(Alert.AlertType.ERROR, "전송 실패\n" + ex.getMessage()).showAndWait();
        }
    }

    /** 셀(말풍선) */
    private static class ChatCell extends ListCell<Comment> {
        private final String me;
        private final ListView<Comment> parent;
        ChatCell(ListView<Comment> parent, String me) { this.parent = parent; this.me = me; }

        @Override protected void updateItem(Comment c, boolean empty) {
            super.updateItem(c, empty);
            if (empty || c == null) { setGraphic(null); return; }

            boolean mine = c.getUserId()!=null && c.getUserId().equals(me);

            // 메타(아이디/날짜)
            Label meta = new Label(
                c.getUserId() + "  [" +
                new SimpleDateFormat("yyyy.MM.dd HH:mm").format(c.getCreatedAt()) + "]"
            );
            meta.getStyleClass().addAll("meta", "bubble-meta");
            meta.setWrapText(true);
            meta.setTextOverrun(OverrunStyle.CLIP);

            // 본문
            Text bodyText = new Text(c.getContent());
            TextFlow body = new TextFlow(bodyText);
            body.getStyleClass().addAll("body", "bubble-body");

            // 가로 최대폭: 리스트 폭의 80% 정도
            body.maxWidthProperty().bind(parent.widthProperty().subtract(180));
            bodyText.wrappingWidthProperty().bind(body.maxWidthProperty());

            VBox bubble = new VBox(6, meta, body); // 메타와 본문 사이 간격
            bubble.getStyleClass().addAll("bubble", mine ? "mine" : "theirs");
            bubble.maxWidthProperty().bind(parent.widthProperty().multiply(0.80));

            HBox line = new HBox(bubble);
            line.getStyleClass().add("message-row");
            line.setAlignment(mine ? Pos.CENTER_RIGHT : Pos.CENTER_LEFT);
            line.setPadding(new Insets(6, 12, 6, 12));

            setGraphic(line);
        }
    }
}
