package application;

import javafx.application.Application;
import javafx.stage.Stage;

public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        SceneManager.setStage(primaryStage);
        
        int tempUserId = 0; 

        // 페이지 등록
        SceneManager.registerView("mainList", () -> new ManagerMainList().getView(tempUserId));
        SceneManager.registerView("adoptionList", () -> new ManagerAdoptionList().getView());
        SceneManager.registerView("reviewList", () -> new ManagerReviewList().getView());
        SceneManager.registerView("statsList", () -> new ManagerStatsPage().getView());
        SceneManager.registerView("chatList", () -> new ManagerChatPage().getView());
        
        // 초기 화면
        SceneManager.switchTo("mainList");

        primaryStage.setTitle("CareMatch 관리자 페이지");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}