package application;

import DAO.AnimalsDAO;
import application.ui.SidebarView;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.chart.*;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Popup;
import javafx.stage.Window;
import javafx.util.StringConverter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Map;

public class ManagerStatsPage {

    private AnimalsDAO animalsDAO;

    public Pane getView() {
        this.animalsDAO = new AnimalsDAO();

        BorderPane root = new BorderPane();
        root.getStyleClass().add("root");
        Font.loadFont(getClass().getResource("/resources/Pretendard-Medium.ttf").toExternalForm(), 12);
        Font.loadFont(getClass().getResource("/resources/Pretendard-Bold.ttf").toExternalForm(), 12);
        Font.loadFont(getClass().getResource("/resources/Pretendard-ExtraBold.ttf").toExternalForm(), 12);

        root.setLeft(new SidebarView());

        HBox header = new HBox();
        header.setPadding(new Insets(10));
        header.setAlignment(Pos.CENTER_LEFT);
        
        Label title = new Label("통계 페이지");
        title.getStyleClass().add("title");
        header.getChildren().add(title);

        VBox statsContainer = new VBox(15);
        statsContainer.setPadding(new Insets(10));
        
        statsContainer.getChildren().addAll(
                createChartBox("상태별 동물 통계", true),
                createChartBox("연간 입소 통계", false)
        );

        VBox center = new VBox(5);
        center.setPadding(new Insets(20));
        center.getChildren().addAll(header, statsContainer);

        root.setCenter(center);
        return root;
    }

    private VBox createChartBox(String titleText, boolean isStatusChart) {
        VBox chartBox = new VBox();
        chartBox.getStyleClass().add("chart-Box");
        chartBox.setSpacing(5);
        chartBox.setPadding(new Insets(0));
        chartBox.setMaxWidth(Double.MAX_VALUE);
        VBox.setVgrow(chartBox, Priority.ALWAYS);

        HBox titleBar = new HBox();
        titleBar.setAlignment(Pos.CENTER_LEFT);
        titleBar.setPadding(new Insets(8, 12, 8, 12));
        titleBar.getStyleClass().add("title-Bar");

        final Label title = new Label();
        title.getStyleClass().add("sub-section-title");

        ImageView calendarIcon = new ImageView(new Image(getClass().getResourceAsStream("/resources/icon/icon-date.png")));
        calendarIcon.setFitWidth(20);
        calendarIcon.setFitHeight(20);

        Button calendarButton = new Button(null, calendarIcon);
        calendarButton.setStyle("-fx-background-color: transparent; -fx-padding: 0;");
        
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        LineChart<String, Number> lineChart = new LineChart<>(new CategoryAxis(), new NumberAxis());
        lineChart.setAnimated(false);
        lineChart.setLegendVisible(true);
        lineChart.setPrefHeight(200);

        DatePicker datePicker = new DatePicker(LocalDate.now());
        datePicker.setConverter(new StringConverter<>() {
            private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
            public String toString(LocalDate date) { return date != null ? formatter.format(date) : ""; }
            public LocalDate fromString(String str) { return str != null && !str.isEmpty() ? LocalDate.parse(str + "-01") : null; }
        });

        Popup popup = new Popup();
        popup.getContent().add(datePicker);
        popup.setAutoHide(true);

        calendarButton.setOnAction(e -> {
            Window window = calendarButton.getScene().getWindow();
            double x = window.getX() + calendarButton.localToScene(0, 0).getX() + calendarButton.getScene().getX();
            double y = window.getY() + calendarButton.localToScene(0, 0).getY() + calendarButton.getScene().getY() + calendarButton.getHeight();
            popup.show(window, x, y);
        });

        datePicker.setOnAction(e -> {
            LocalDate selectedDate = datePicker.getValue();
            popup.hide();
            updateChartData(lineChart, selectedDate, isStatusChart);
            title.setText(titleText + " (" + selectedDate.format(DateTimeFormatter.ofPattern("yyyy")) + "년)");
        });

        LocalDate now = LocalDate.now();
        updateChartData(lineChart, now, isStatusChart);
        title.setText(titleText + " (" + now.format(DateTimeFormatter.ofPattern("yyyy")) + "년)");

        titleBar.getChildren().addAll(title, spacer, calendarButton);
        chartBox.getChildren().addAll(titleBar, lineChart);
        return chartBox;
    }

    private void updateChartData(LineChart<String, Number> chart, LocalDate selectedDate, boolean isStatusChart) {
        chart.getData().clear();
        int year = selectedDate.getYear();
        
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        chart.getYAxis().setLabel("마리 수");

        if (isStatusChart) {
            // 1. 상태별 통계 (첫 번째 그래프)
            series.setName("상태별 마리 수");
            
            Map<String, Integer> statusData = animalsDAO.getStatusCountsForYear(year);
            String[] statuses = {"보호중", "대기중", "치료중", "종료"};
            for (String status : statuses) {
                int count = statusData.getOrDefault(status, 0);
                series.getData().add(new XYChart.Data<>(status, count));
            }

        } else {
            // 2. 월별 입소 통계 (두 번째 그래프)
            series.setName("동물 추가");

            Map<Integer, Integer> monthlyData = animalsDAO.getYearlyIntakeStats(year);
            String[] months = {"1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"};
            for (int i = 0; i < months.length; i++) {
                int count = monthlyData.getOrDefault(i + 1, 0);
                series.getData().add(new XYChart.Data<>(months[i], count));
            }
        }
        chart.getData().add(series);
    }
}