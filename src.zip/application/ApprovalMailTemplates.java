package application;

import java.sql.Date;
import java.time.format.DateTimeFormatter;

/** 승인/거절 메일 템플릿 유틸 */
public final class ApprovalMailTemplates {

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private ApprovalMailTemplates() {}

    public static String subjectApproved() {
        return "[CareMatch] 방문 신청 승인 안내";
    }

    public static String subjectRejected() {
        return "[CareMatch] 방문 신청 거절 안내";
    }

    public static String bodyApproved(String name, Date visitDate) {
        String dateStr = visitDate != null ? visitDate.toLocalDate().format(DATE_FMT) : "(일자 미정)";
        return (name != null && !name.isEmpty() ? name + "님," : "안녕하세요,") + "\n\n"
            + "CareMatch 방문 신청이 승인되었습니다.\n"
            + "방문 예정일: " + dateStr + "\n\n"
            + "방문 신청일에 뵙겠습니다. 감사합니다!\n"
            + "- CareMatch 드림";
    }

    public static String bodyRejected(String name, Date visitDate) {
        String dateStr = visitDate != null ? visitDate.toLocalDate().format(DATE_FMT) : "(일자 미정)";
        return (name != null && !name.isEmpty() ? name + "님," : "안녕하세요,") + "\n\n"
            + "죄송합니다. 요청하신 CareMatch 방문 신청이 거절되었습니다.\n"
            + "요청하신 일자: " + dateStr + "\n\n"
            + "다른 날짜로 다시 예약해 주시거나 문의해 주세요.\n"
            + "- CareMatch 드림";
    }
}