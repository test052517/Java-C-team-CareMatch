package application;

import DAO.VisitReservationDAO;
import DTO.VisitReservationDTO;
import DTO.VisitDTO;
import DAO.UserSpecificDAO;
import DTO.UserSpecificDTO;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.sql.Date;

/** 방문 일정 확인: 예약 테이블(visit_reservations)의 날짜로 표시 + DatePicker 비활성화 */
public class ManagerVisitScheduleForm extends Stage {

    private final VisitDTO visit;

    public ManagerVisitScheduleForm(VisitDTO visit, Runnable afterCloseCallback) {
        this.visit = visit;
        setTitle("방문 일정 확인");
        initModality(Modality.APPLICATION_MODAL);

        VBox root = new VBox(16);
        root.setPadding(new Insets(22));

        Label header = new Label("방문 일정 확인");
        header.getStyleClass().add("menu-Title");

        // 동물 ID
        Label animalLabel = new Label("동물 ID");
        TextField animalField = new TextField(visit != null ? String.valueOf(visit.getAnimalId()) : "");
        animalField.setEditable(false);
        VBox animalBox = new VBox(6, animalLabel, animalField);

        // 신청인 ID
        Label userLabel = new Label("신청인 ID");
        TextField userField = new TextField(visit != null ? String.valueOf(visit.getUserId()) : "");
        userField.setEditable(false);
        VBox userBox = new VBox(6, userLabel, userField);

        // 방문 신청 날짜 = 예약 테이블의 값
        Label dateLabel = new Label("방문 신청 날짜");
        DatePicker datePicker = new DatePicker();
        Date resolved = resolveDateFromReservation(visit);
        if (resolved != null) datePicker.setValue(resolved.toLocalDate());
        datePicker.setDisable(true); // 사용자 선택 못 하도록 비활성화
        VBox dateBox = new VBox(6, dateLabel, datePicker);

        // 방문 목적
        Label purposeLabel = new Label("방문 목적");
        TextArea purposeArea = new TextArea(visit != null ? visit.getPurpose() : "");
        purposeArea.setEditable(false);
        purposeArea.setPrefRowCount(4);
        VBox purposeBox = new VBox(6, purposeLabel, purposeArea);

        Button approveButton = new Button("승인");
        Button rejectButton  = new Button("거절");

        approveButton.setOnAction(ev -> {
            boolean ok = handleDecision(true, resolved);
            if (ok) {
                new Alert(Alert.AlertType.INFORMATION, "방문이 승인되었습니다.", ButtonType.OK).showAndWait();
                close();
                if (afterCloseCallback != null) afterCloseCallback.run();
            }
        });
        rejectButton.setOnAction(ev -> {
            boolean ok = handleDecision(false, resolved);
            if (ok) {
                new Alert(Alert.AlertType.INFORMATION, "방문이 거절되었습니다.", ButtonType.OK).showAndWait();
                close();
                if (afterCloseCallback != null) afterCloseCallback.run();
            }
        });

        HBox buttonBox = new HBox(10, approveButton, rejectButton);
        buttonBox.setAlignment(Pos.CENTER);

        root.getChildren().addAll(header, animalBox, userBox, dateBox, purposeBox, buttonBox);

        Scene scene = new Scene(root, 500, 520);
        try { scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm()); } catch (Exception ignore) {}
        setScene(scene);
    }

    /** visit_reservations에서 user_id + 동물 마지막4자리로 최신 예약을 찾아 날짜 반환 */
    private static Date resolveDateFromReservation(VisitDTO visit) {
        if (visit == null) return null;
        VisitReservationDAO dao = new VisitReservationDAO();
        try {
            int userId = visit.getUserId();
            String animalIdAny = visit.getAnimalId();
            VisitReservationDTO latest = dao.findLatestByUserAndAnimalLoose(userId, animalIdAny);
            if (latest != null && latest.getVisitDate() != null) return latest.getVisitDate();
        } catch (Exception ignore) {}
        return visit.getVisitDate(); // 폴백
    }

    /** 승인/거절 시 상태 업데이트 + 메일 발송(템플릿 사용) */
    private boolean handleDecision(boolean approve, Date dateToMail) {
        int userId = visit != null ? visit.getUserId() : -1;
        if (userId <= 0) {
            new Alert(Alert.AlertType.ERROR, "신청인 ID가 올바르지 않습니다.").showAndWait();
            return false;
        }
        // 상태 업데이트
        VisitReservationDAO vrdao = new VisitReservationDAO();
        VisitReservationDTO latest = null;
        try {
            latest = vrdao.findLatestByUserAndAnimalLoose(userId, visit.getAnimalId());
        } catch (java.sql.SQLException e) {
            e.printStackTrace();
        }
        if (latest != null) {
        	boolean updated = false;
        	try {
        	    updated = vrdao.updateStatus(latest.getReservationId(), approve ? "승인" : "거절");
        	} catch (java.sql.SQLException e) {
        	    e.printStackTrace();
        	}
            if (!updated) {
                new Alert(Alert.AlertType.ERROR, "예약 상태 업데이트 실패").showAndWait();
                return false;
            }
        }

        // 메일 발송
        try {
            UserSpecificDAO udao = new UserSpecificDAO();
            UserSpecificDTO user = udao.findUserByUserId(userId);
            if (user == null || user.getEmail() == null || user.getEmail().isEmpty()) {
                new Alert(Alert.AlertType.WARNING, "사용자 이메일을 찾을 수 없어 메일을 보내지 못했습니다.").showAndWait();
                return true;
            }
            EmailSender mail = new EmailSender();
            String subject = approve ? ApprovalMailTemplates.subjectApproved() : ApprovalMailTemplates.subjectRejected();
            String body = approve ? ApprovalMailTemplates.bodyApproved(user.getName(), dateToMail)
                                  : ApprovalMailTemplates.bodyRejected(user.getName(), dateToMail);
            mail.sendPlainText(user.getEmail(), subject, body);
            return true;
        } catch (Exception e) {
            new Alert(Alert.AlertType.ERROR, "메일 발송 실패: " + e.getMessage()).showAndWait();
            return false;
        }
    }
}