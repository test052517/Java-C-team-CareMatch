package application;

import java.sql.Timestamp;

public class Comment {
    private String reviewId;
    private String userId;
    private String content;
    private Timestamp createdAt;

    public Comment(String reviewId, String userId, String content, Timestamp createdAt) {
        this.reviewId = reviewId;
        this.userId = userId;
        this.content = content;
        this.createdAt = createdAt;
    }
    public String getReviewId() { return reviewId; }
    public String getUserId() { return userId; }
    public String getContent() { return content; }
    public Timestamp getCreatedAt() { return createdAt; }
}