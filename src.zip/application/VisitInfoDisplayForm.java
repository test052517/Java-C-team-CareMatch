package application;

import DTO.VisitDTO;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class VisitInfoDisplayForm extends Stage {

    public VisitInfoDisplayForm(VisitDTO visit) {
        setTitle("Registered Visit Information");
        initModality(Modality.APPLICATION_MODAL);

        VBox root = new VBox(15);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-font-size: 14px;");

        Label header = new Label("A visit has been scheduled.");
        header.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        // Convert java.sql.Date to String for display
        String visitDateStr = (visit.getVisitDate() != null) ? visit.getVisitDate().toString() : "Not set";
        String submittedDateStr = (visit.getSubmittedDate() != null) ? visit.getSubmittedDate().toString() : "Not set";

        Label purposeLabel = new Label("Purpose of Visit: " + visit.getPurpose());
        Label statusLabel = new Label("Reservation Status: " + visit.getStatus());
        Label visitDateLabel = new Label("Scheduled Visit Date: " + visitDateStr);
        Label submittedDateLabel = new Label("Reservation Request Date: " + submittedDateStr);

        root.getChildren().addAll(header, purposeLabel, statusLabel, visitDateLabel, submittedDateLabel);

        Scene scene = new Scene(root, 400, 250);
        setScene(scene);
    }
}