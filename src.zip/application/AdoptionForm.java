package application;

import DB.DBConnect;
import DAO.UserDAO;
import DAO.UserSpecificDAO;
import DTO.UserDTO;
import DTO.UserSpecificDTO;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class AdoptionForm {

    /**
     * 입양 신청 모달 창을 띄웁니다.
     * @param owner    부모 창 Stage
     * @param animalId 신청할 동물의 ID
     * @param userId   현재 로그인한 사용자의 ID
     */
    public void showModal(Stage owner, String animalId, int userId) {

        // DB에서 현재 사용자 정보 조회
        UserDAO userDao = new UserDAO();
        UserSpecificDAO userSpecificDao = new UserSpecificDAO();
        UserDTO user = userDao.findUserByUserId(userId);
        UserSpecificDTO userSpecific = userSpecificDao.findUserByUserId(userId);

        // 사용자 정보 로드 실패 시, 오류 메시지를 보여주고 창을 열지 않음
        if (user == null || userSpecific == null) {
            showAlert(Alert.AlertType.ERROR, "오류", "신청자 정보를 불러올 수 없습니다. 다시 시도해주세요.");
            return;
        }

        // 새 Stage (모달)
        Stage dialog = new Stage();
        dialog.initOwner(owner);
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("입양 신청");
        dialog.setResizable(false); // 창 크기 변경 방지

        // 상단 제목
        Label titleLabel = new Label("입양 신청");
        titleLabel.getStyleClass().add("title-label");

        // 입양할 동물 (외부에서 받아온 ID로 표시)
        Label animalLabel = new Label("입양할 동물: " + animalId);
        animalLabel.getStyleClass().add("animal-label");

        // 신청자 정보
        Label applicantLabel = new Label("📋 신청자 정보");
        applicantLabel.getStyleClass().add("section-label");

        // DB에서 가져온 정보로 TextField 채우기
        TextField nameField = new TextField(user.getName());
        nameField.setEditable(false);
        nameField.setFocusTraversable(false); // 포커스 이동 제외

        TextField phoneField = new TextField(userSpecific.getPhone());
        phoneField.setEditable(false);
        phoneField.setFocusTraversable(false);

        TextField emailField = new TextField(userSpecific.getEmail());
        emailField.setEditable(false);
        emailField.setFocusTraversable(false);
        
        // 주소는 사용자가 직접 입력하도록 함
        TextField addressField = new TextField();
        addressField.setPromptText("상세 주소를 입력해주세요.");
        addressField.setEditable(true); // 수정 가능하도록 변경
        addressField.setFocusTraversable(true);


        Label reasonLabel = new Label("입양 사유");
        Label introLabel = new Label("자기소개 (반려동물 경험 등)");

        TextArea reasonArea = new TextArea();
        reasonArea.setPromptText("이 동물을 입양하려는 특별한 이유가 있나요?");
        reasonArea.setPrefRowCount(3);
        reasonArea.setWrapText(true); // 자동 줄바꿈

        TextArea introArea = new TextArea();
        introArea.setPromptText("가족 구성원, 현재 또는 과거의 반려동물 경험, 주거 환경 등 자신을 소개해주세요.");
        introArea.setPrefRowCount(3);
        introArea.setWrapText(true); // 자동 줄바꿈

        // 동의 체크박스 + 안내 문구
        CheckBox agreeCheck = new CheckBox("위 내용을 읽고 동의합니다.");
        agreeCheck.getStyleClass().add("agree-check");

        Label agreeNote = new Label("\"입양은 한 생명의 남은 삶을 함께하는 소중한 약속입니다.\"");
        agreeNote.getStyleClass().add("agree-note");

        // 버튼
        Button submitBtn = new Button("신청 완료");
        submitBtn.getStyleClass().add("submit-button");
        submitBtn.setDefaultButton(true);

        submitBtn.setOnAction(e -> {
            if (reasonArea.getText().trim().isEmpty() || introArea.getText().trim().isEmpty()) {
                showAlert(Alert.AlertType.WARNING, "입력 오류", "자기소개와 입양 사유를 모두 작성해주세요.");
                return;
            }
            if (!agreeCheck.isSelected()) {
                showAlert(Alert.AlertType.WARNING, "동의 필요", "안내 문구를 읽고 동의 항목에 체크해주세요.");
                return;
            }

            String sql = "{CALL SubmitAdoption(?, ?, ?, ?)}";

            try (Connection conn = DBConnect.getConnection();
                 CallableStatement cstmt = conn.prepareCall(sql)) {

                cstmt.setInt(1, userId);
                cstmt.setString(2, animalId);
                cstmt.setString(3, reasonArea.getText());
                cstmt.setString(4, introArea.getText());

                cstmt.execute();

                showAlert(Alert.AlertType.INFORMATION, "신청 완료", "입양 신청이 성공적으로 접수되었습니다.\n관리자 확인 후 연락드리겠습니다.");
                dialog.close();

            } catch (SQLException ex) {
                // 첫 번째 파일의 더 상세한 오류 처리 로직 적용
                if (ex.getMessage().contains("입양 신청 불가 상태입니다")) {
                    showAlert(Alert.AlertType.WARNING, "신청 불가", "이 동물은 이미 다른 입양 절차가 진행 중이거나 입양이 완료되었습니다. 목록을 새로고침 해주세요.");
                
                } else if (ex.getMessage().contains("해당 동물이 존재하지 않습니다")) {
                    showAlert(Alert.AlertType.WARNING, "신청 불가", "선택한 동물의 정보가 변경되었거나 삭제되었습니다. 목록을 새로고침 후 다시 시도해주세요.");
                
                } else {
                    showAlert(Alert.AlertType.ERROR, "데이터베이스 오류", "데이터 처리 중 알 수 없는 오류가 발생했습니다.");
                }
                ex.printStackTrace();
            } catch (Exception ex) {
                showAlert(Alert.AlertType.ERROR, "시스템 오류", "알 수 없는 오류가 발생했습니다. 관리자에게 문의해주세요.");
                ex.printStackTrace();
            }
        });

        // 폼 레이아웃
        GridPane formGrid = new GridPane();
        formGrid.setHgap(10);
        formGrid.setVgap(12); // 간격 조정
        ColumnConstraints col1 = new ColumnConstraints();
        ColumnConstraints col2 = new ColumnConstraints();
        col1.setPercentWidth(20);
        col2.setPercentWidth(80);
        formGrid.getColumnConstraints().addAll(col1, col2);
        formGrid.add(new Label("이름:"), 0, 0); formGrid.add(nameField, 1, 0);
        formGrid.add(new Label("연락처:"), 0, 1); formGrid.add(phoneField, 1, 1);
        formGrid.add(new Label("이메일:"), 0, 2); formGrid.add(emailField, 1, 2);
        formGrid.add(new Label("주소:"), 0, 3); formGrid.add(addressField, 1, 3);

        // 전체 레이아웃
        VBox root = new VBox(15,
                titleLabel,
                animalLabel,
                new Separator(),
                applicantLabel,
                formGrid,
                new Separator(),
                reasonLabel,
                reasonArea,
                introLabel,
                introArea,
                new Separator(),
                agreeNote,
                agreeCheck,
                submitBtn
        );
        root.setPadding(new Insets(30));
        root.setAlignment(Pos.CENTER);
        root.setPrefWidth(550);

        Scene scene = new Scene(root);
        scene.getStylesheets().add(getClass().getResource("AdoptionForm.css").toExternalForm());

        dialog.setScene(scene);
        dialog.sizeToScene();
        introArea.requestFocus();
        dialog.showAndWait();
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}