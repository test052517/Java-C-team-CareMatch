package server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

//컨트롤러 추가
import server.controller.Controller;
import server.controller.LoginController;
import server.controller.AnimalController;
import server.controller.ImageController;
import server.controller.ManagerImageController;
import server.controller.ManagerAnimalController;
import server.controller.UpdateAnimalStatusController;
import server.controller.ReviewController;
import server.controller.UserImageController;

public class ClientHandler implements Runnable {

    private Socket clientSocket;
    private Map<String, Controller> controllerMap;

    public ClientHandler(Socket socket) {
        this.clientSocket = socket;
        this.controllerMap = new HashMap<>();
        
        AnimalController animalController = new AnimalController();
        
        // 컨트롤러 등록
        controllerMap.put("LOGIN", new LoginController());
        
        controllerMap.put("GET_ANIMALS", new AnimalController());
        controllerMap.put("GET_IMAGE", new ImageController());
        controllerMap.put("GET_ANIMAL_DETAIL", animalController);
        controllerMap.put("GET_USERIMAGE", new UserImageController());
        
        controllerMap.put("GET_MANAGER_IMAGE", new ManagerImageController());
        controllerMap.put("GET_MANAGER_ANIMALS", new ManagerAnimalController());
        controllerMap.put("UPDATE_ANIMAL_STATUS", new UpdateAnimalStatusController());
        controllerMap.put("GET_REVIEWS", new ReviewController());
        
    }

    @Override
    public void run() {
        try (
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
        ) {
            String request;
            while ((request = in.readLine()) != null) {
                System.out.println("클라이언트로부터 받은 요청: " + request);
                
                String[] parts = request.split(":", 2);
                String command = parts[0];
                
                Controller controller = controllerMap.get(command);

                if (controller != null) {
                    controller.execute(request, out);
                } else {
                    out.println("ERROR:Unknown command");
                }
            }
        } catch (IOException e) {
            System.out.println("클라이언트 연결 끊김: " + clientSocket.getInetAddress());
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}