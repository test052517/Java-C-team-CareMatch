package server;

import java.io.*;
import java.net.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.Properties;

/** Tiny chat server: each request is one line, a new TCP connection per request.
 *  Protocol:
 *   TEXT|roomId|senderId|content
 *   IMAGE|roomId|senderId|absPath
 *   READ|roomId|userId|lastMessageId
 *  Database credentials are read from /db.properties (same as client).
 */
public class ChatServer {

    private final int port;
    private final String url, user, password;

    public ChatServer(int port, String url, String user, String password) {
        this.port = port; this.url = url; this.user = user; this.password = password;
    }

    public void start() throws Exception {
        System.out.println("[SERVER] Starting on port " + port);
        try (ServerSocket ss = new ServerSocket(port)) {
            while (true) {
                Socket s = ss.accept();
                new Thread(() -> handle(s)).start();
            }
        }
    }

    private void handle(Socket s) {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"))) {
            String line = in.readLine();
            if (line == null) return;
            process(line);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try { s.close(); } catch (Exception ignore) {}
        }
    }

    private void process(String line) throws Exception {
        String[] parts = split(line);
        if (parts.length < 2) return;

        String cmd = parts[0];
        if ("TEXT".equals(cmd)) {
            int roomId = Integer.parseInt(parts[1]);
            int senderId = Integer.parseInt(parts[2]);
            String content = parts[3];
            try (Connection con = DriverManager.getConnection(url, user, password);
                 PreparedStatement ps = con.prepareStatement(
                         "INSERT INTO chatting_message(room_id, sender_id, content, content_type) VALUES(?,?,?, 'TEXT')")) {
                ps.setInt(1, roomId);
                ps.setInt(2, senderId);
                ps.setString(3, content);
                ps.executeUpdate();
            }
            System.out.println("[SERVER] TEXT room=" + roomId + " sender=" + senderId + " len=" + content.length());
        } else if ("IMAGE".equals(cmd)) {
            int roomId = Integer.parseInt(parts[1]);
            int senderId = Integer.parseInt(parts[2]);
            String path = parts[3];
            long mid;
            try (Connection con = DriverManager.getConnection(url, user, password)) {
                con.setAutoCommit(false);
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO chatting_message(room_id, sender_id, content, content_type) VALUES(?,?,?, 'IMAGE')",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setInt(1, roomId);
                    ps.setInt(2, senderId);
                    ps.setString(3, path);
                    ps.executeUpdate();
                    try (ResultSet rs = ps.getGeneratedKeys()) { rs.next(); mid = rs.getLong(1); }
                }
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO chat_image(message_id, file_path, original_name, size_bytes) VALUES(?,?,?,?)")) {
                    File f = new File(path);
                    ps.setLong(1, mid);
                    ps.setString(2, path);
                    ps.setString(3, f.getName());
                    ps.setLong(4, f.exists()? f.length() : 0L);
                    ps.executeUpdate();
                }
                con.commit();
            }
            System.out.println("[SERVER] IMAGE room=" + roomId + " sender=" + senderId + " path=" + path);
        } else if ("READ".equals(cmd)) {
            int roomId = Integer.parseInt(parts[1]);
            int userId = Integer.parseInt(parts[2]);
            long lastMid = Long.parseLong(parts[3]);
            try (Connection con = DriverManager.getConnection(url, user, password);
                 PreparedStatement ps = con.prepareStatement(
                         "INSERT IGNORE INTO message_read(message_id, user_id, read_at) " +
                         "SELECT m.message_id, ?, NOW() FROM chatting_message m " +
                         "WHERE m.room_id=? AND m.message_id<=? AND m.sender_id<>?")) {
                ps.setInt(1, userId);
                ps.setInt(2, roomId);
                ps.setLong(3, lastMid);
                ps.setInt(4, userId);
                ps.executeUpdate();
            }
            System.out.println("[SERVER] READ-UP-TO room=" + roomId + " user=" + userId + " lastMid=" + lastMid);
        }
    }

    private static String[] split(String line) {
        // Simple splitter with escaping support for \| and \\
        StringBuilder cur = new StringBuilder();
        java.util.List<String> out = new java.util.ArrayList<>();
        boolean esc = false;
        for (int i=0;i<line.length();i++) {
            char c = line.charAt(i);
            if (esc) { cur.append(c); esc = false; continue; }
            if (c == '\\') { esc = true; continue; }
            if (c == '|') { out.add(cur.toString()); cur.setLength(0); continue; }
            cur.append(c);
        }
        out.add(cur.toString());
        return out.toArray(new String[0]);
    }

    public static void main(String[] args) throws Exception {
        Properties p = new Properties();
        try (InputStream in = ChatServer.class.getResourceAsStream("/db.properties")) {
            if (in == null) throw new RuntimeException("db.properties not found on classpath");
            p.load(in);
        }
        int port = Integer.parseInt(p.getProperty("chat.port", "9999"));
        String url = p.getProperty("url");
        String user = p.getProperty("user");
        String pass = p.getProperty("password");
        new ChatServer(port, url, user, pass).start();
    }
}
