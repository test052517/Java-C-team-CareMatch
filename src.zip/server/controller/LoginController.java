package server.controller;

import java.io.PrintWriter;
import DAO.UserDAO;
import DTO.UserDTO;

public class LoginController implements Controller {

    @Override
    public void execute(String request, PrintWriter out) {
        String[] parts = request.split(":");

        if (parts.length < 3) {
            out.println("ERROR:Invalid login request format.");
            System.err.println("잘못된 로그인 요청 형식: " + request);
            return;
        }

        String id = parts[1];
        String password = parts[2];

        UserDAO userDAO = new UserDAO();

        if (userDAO.validateLogin(id, password)) {
            UserDTO user = userDAO.findUserByLoginId(id);
            
            if (user != null) {
                // ✅ 사용자 ID와 역할(Role) 모두 서버 응답에 포함
                out.println("LOGIN_SUCCESS:" + user.getUserId() + ":" + user.getRole());
            } else {
                out.println("LOGIN_FAIL");
            }
        } else {
            out.println("LOGIN_FAIL");
        }
    }
}
