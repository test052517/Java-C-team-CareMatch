package server.controller;

import java.io.PrintWriter;
import java.util.List;
import DAO.AnimalsDAO;
import DAO.ShelterDAO;
import DTO.AnimalsDTO;
import DTO.ShelterDTO;

public class ManagerAnimalController implements Controller {

    private final AnimalsDAO animalsDAO;
    private final ShelterDAO shelterDAO;

    public ManagerAnimalController() {
        this.animalsDAO = new AnimalsDAO();
        this.shelterDAO = new ShelterDAO();
    }

    @Override
    public void execute(String request, PrintWriter out) {
        // 단 한 번의 DB 접근으로 동물 정보와 품종 정보를 모두 가져옵니다.
        List<AnimalsDTO> animals = animalsDAO.findAllAnimals();
        
        if (animals != null) {
            StringBuilder responseBuilder = new StringBuilder();
            for (AnimalsDTO animal : animals) {
                // 보호소 정보는 별도로 조회해야 합니다.
                ShelterDTO shelter = shelterDAO.findShelterById(animal.getShelterId());

                // DTO에 내장된 getKindName()을 활용합니다.
                String kindName = animal.getKindName() != null ? animal.getKindName() : "정보 없음";
                String shelterName = (shelter != null) ? shelter.getShelterName() : "정보 없음";
                String address = (shelter != null) ? shelter.getAddress() : "정보 없음";
                String telephone = (shelter != null) ? shelter.getTelephone() : "정보 없음";
                String imageId = animal.getImageId() != null ? animal.getImageId() : "null";

                // 클라이언트로 보낼 문자열을 조립합니다.
                // ✨ 맨 앞에 animal.getAnimalId()를 추가하여 클라이언트가 동물을 식별할 수 있도록 합니다.
                String record = String.join(";",
                    animal.getAnimalId(),       // ✨ 수정된 부분
                    animal.getAnimalName(),
                    kindName,
                    String.valueOf(animal.getAge()),
                    String.valueOf(animal.getWeight()),
                    animal.getSex(),
                    animal.getNeutered(),
                    animal.getHappenDate().toString(),
                    animal.getStatus(),
                    imageId,
                    shelterName,
                    address,
                    telephone
                );
                
                responseBuilder.append(record).append("##RECORD_END##");
            }
            out.println("MANAGER_ANIMAL_LIST:" + responseBuilder.toString());
        } else {
            out.println("ERROR:Failed to retrieve animal list for manager");
        }
    }
}