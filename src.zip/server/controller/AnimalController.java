package server.controller;

import java.io.PrintWriter;
import java.util.List;

import DAO.AnimalsDAO;
import DAO.ShelterDAO;
import DAO.SpeciesDAO;
import DTO.AnimalsDTO;
import DTO.ShelterDTO;
import DTO.SpeciesDTO;

public class AnimalController implements Controller {

    private final AnimalsDAO animalsDAO;
    private final ShelterDAO shelterDAO;
    private final SpeciesDAO speciesDAO;

    public AnimalController() {
        this.animalsDAO = new AnimalsDAO();
        this.shelterDAO = new ShelterDAO();
        this.speciesDAO = new SpeciesDAO();
    }

    @Override
    public void execute(String request, PrintWriter out) {
        String[] parts = request.split(":", 2);
        String command = parts[0];

        try {
            // ★★★ 개선된 부분: 'command' 변수를 사용하도록 통일 ★★★
            if ("GET_ANIMALS".equals(command)) {
                handleGetAllAnimals(out);
            } else if ("GET_ANIMAL_DETAIL".equals(command)) {
                String animalId = parts.length > 1 ? parts[1] : "";
                handleGetAnimalDetail(animalId, out);
            }

        } catch (Exception e) {
            System.err.println("AnimalController 오류: " + e.getMessage());
            e.printStackTrace();
            out.println("ERROR:Animal data processing failed.");
        }
    }

    /** 전체 동물 목록을 클라이언트에 전송 */
    private void handleGetAllAnimals(PrintWriter out) {
        List<AnimalsDTO> animals = animalsDAO.findAllAnimals();
        StringBuilder payload = new StringBuilder();
        for (AnimalsDTO animal : animals) {
            if (payload.length() > 0) {
                payload.append("|");
            }
            // MainListApp에서 기대하는 7개 필드를 순서대로 전송
            payload.append(String.join(",",
                    animal.getAnimalId(),
                    animal.getAnimalName(),
                    animal.getSex(),
                    String.valueOf(animal.getAge()),
                    animal.getImageId(), 
                    animal.getType(),
                    animal.getKindName()
            ));
        }
        out.println("ANIMALS_LIST:" + payload.toString());
    }

    /** 특정 동물 한 마리의 상세 정보를 클라이언트에 전송 */
    private void handleGetAnimalDetail(String animalId, PrintWriter out) {
        if (animalId == null || animalId.trim().isEmpty()) {
            out.println("ERROR:Animal ID is required.");
            return;
        }

        AnimalsDTO animal = animalsDAO.findAnimalById(animalId);
        if (animal == null) {
            out.println("ERROR:Animal not found.");
            return;
        }

        // 연관된 보호소 및 품종 정보 조회
        ShelterDTO shelter = shelterDAO.findShelterById(animal.getShelterId());  
        SpeciesDTO species = speciesDAO.findSpeciesById(animal.getKindId());

        // 정보가 null일 경우 기본값 설정
        String shelterName = (shelter != null) ? shelter.getShelterName() : "정보 없음";
        String shelterAddress = (shelter != null) ? shelter.getAddress() : "정보 없음";
        String shelterTel = (shelter != null) ? shelter.getTelephone() : "정보 없음";
        String kindName = (species != null) ? species.getKindName() : "정보 없음";

        // 클라이언트의 AnimalDetailView에서 사용할 11개 필드를 순서대로 조합
        String payload = String.join(",",
                animal.getAnimalName() != null ? animal.getAnimalName() : "N/A",
                kindName,
                animal.getSex() != null ? animal.getSex() : "N/A",
                String.valueOf(animal.getAge()),
                String.valueOf(animal.getWeight()),
                animal.getNeutered() != null ? animal.getNeutered() : "N/A",
                animal.getStatus() != null ? animal.getStatus() : "N/A",
                shelterName,
                shelterAddress,
                shelterTel,
                animal.getImageId() != null ? animal.getImageId() : "null"
        );
        out.println("ANIMAL_DETAIL:" + payload);
    }
}