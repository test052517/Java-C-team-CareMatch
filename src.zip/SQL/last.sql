CREATE TABLE `review_image` (
   `review_image_id` VARCHAR(64) NOT NULL COLLATE 'utf8mb4_unicode_ci',
   `review_id` VARCHAR(64) NOT NULL COLLATE 'utf8mb4_unicode_ci',
   `file_name` VARCHAR(255) NULL DEFAULT NULL COLLATE 'utf8mb4_unicode_ci',
   `mime_type` VARCHAR(100) NULL DEFAULT NULL COLLATE 'utf8mb4_unicode_ci',
   `image_data` LONGBLOB NULL DEFAULT NULL,
   `created_at` DATETIME NOT NULL DEFAULT (CURRENT_TIMESTAMP),
   PRIMARY KEY (`review_image_id`) USING BTREE,
   INDEX `fk_review_image_review` (`review_id`) USING BTREE,
   CONSTRAINT `fk_review_image_review` FOREIGN KEY (`review_id`) REFERENCES `carematch`.`review` (`review_id`) ON UPDATE CASCADE ON DELETE CASCADE
)
COLLATE='utf8mb4_unicode_ci'
ENGINE=InnoDB
;

ALTER TABLE email_verify
  MODIFY COLUMN fav_id INT NOT NULL AUTO_INCREMENT;

USE careMatch;

-- 좋아요/댓글에서 참조하는 review_id를 VARCHAR(50)로 맞춤
ALTER TABLE review_like    MODIFY review_id VARCHAR(50) NOT NULL;
ALTER TABLE review_comment MODIFY review_id VARCHAR(50) NOT NULL;

USE careMatch;

-- 테이블 단위로 통일 (권장: utf8mb4 + utf8mb4_unicode_ci)
ALTER TABLE review         CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE review_like    CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE review_comment CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- FK 대상/참조 컬럼의 타입/Collation도 명시적으로 동일하게
ALTER TABLE review
  MODIFY review_id VARCHAR(50) NOT NULL
  COLLATE utf8mb4_unicode_ci;

ALTER TABLE review_like
  MODIFY review_id VARCHAR(50) NOT NULL
  COLLATE utf8mb4_unicode_ci;

ALTER TABLE review_comment
  MODIFY review_id VARCHAR(50) NOT NULL
  COLLATE utf8mb4_unicode_ci;
  
ALTER TABLE review_like
  ADD CONSTRAINT fk_review_like_review
  FOREIGN KEY (review_id) REFERENCES review(review_id)
  ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE review_comment
  ADD CONSTRAINT fk_review_comment_review
  FOREIGN KEY (review_id) REFERENCES review(review_id)
  ON DELETE CASCADE ON UPDATE CASCADE;
  
SHOW CREATE TABLE review;
SHOW CREATE TABLE review_like;
SHOW CREATE TABLE review_comment;

-- review_id 타입/Collation 확인
SHOW FULL COLUMNS FROM review          LIKE 'review_id';
SHOW FULL COLUMNS FROM review_like     LIKE 'review_id';
SHOW FULL COLUMNS FROM review_comment  LIKE 'review_id';

-- 1) 읽음 표시용 컬럼 추가
ALTER TABLE chatting_message
  ADD COLUMN read_at DATETIME NULL DEFAULT NULL
  AFTER created_at;

-- 2) 선택: 조회/업데이트 성능을 위한 인덱스
CREATE INDEX idx_cm_room_created        ON chatting_message (room_id, created_at);
CREATE INDEX idx_cm_room_sender_read    ON chatting_message (room_id, sender_id, read_at);