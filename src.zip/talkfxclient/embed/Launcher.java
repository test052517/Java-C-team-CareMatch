package talkfxclient.embed;
import javafx.application.Application; import javafx.stage.Stage;
import talkfxclient.bridge.*; import talkfxclient.model.User; import talkfxclient.ui.ChatListWindow;
import java.io.*; import java.sql.*; import java.util.Properties;
public class Launcher extends Application {
  private static User sMe; private static ChatBackend sBackend;
  public static void open(int userId, String loginId, String name, String role){ sMe=new User(userId, loginId, name, role); sBackend=makeBackend(); Application.launch(Launcher.class); }
  public static void openFromLoginId(String loginId) throws Exception { sMe=findByLoginId(loginId); if(sMe==null) throw new IllegalArgumentException("Unknown login_id: "+loginId); sBackend=makeBackend(); Application.launch(Launcher.class); }
  private static ChatBackend makeBackend(){ try(InputStream in=Launcher.class.getResourceAsStream("/db.properties")){ Properties p=new Properties(); p.load(in); String host=p.getProperty("chat.host","127.0.0.1").trim(); int port=Integer.parseInt(p.getProperty("chat.port","7777").trim()); System.out.println("[Launcher] try socket backend "+host+":"+port); return new LegacySocketBackend(host,port);} catch(Throwable t){ System.err.println("[Launcher] socket backend failed, fallback JDBC: "+t); return new JdbcBackend(); } }
  private static User findByLoginId(String loginId) throws Exception { try(InputStream in=Launcher.class.getResourceAsStream("/db.properties")){ if(in==null) throw new RuntimeException("db.properties not found on classpath"); Properties p=new Properties(); p.load(in);
      try(Connection con=DriverManager.getConnection(p.getProperty("url"), p.getProperty("user"), p.getProperty("password")); PreparedStatement ps=con.prepareStatement("SELECT user_id, login_id, name, role FROM users WHERE login_id=?")){ ps.setString(1, loginId); try(ResultSet rs=ps.executeQuery()){ if(rs.next()) return new User(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)); } } } return null; }
  @Override public void start(Stage primaryStage){ new ChatListWindow(sBackend, sMe).show(); }
}
