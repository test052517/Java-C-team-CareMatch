package talkfxclient.ui;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;

import talkfxclient.model.User;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

/**
 * 대화창(JavaFX). 파일/텍스트 전송, 폴링 로딩 포함.
 * User의 private 필드 접근 오류를 막기 위해 반드시 getter를 사용합니다.
 */
public class DialogWindow extends Stage {
    private final int roomId;
    private final int meUserId;
    private final User peer;

    private final VBox messages = new VBox(6);
    private final ScrollPane scroller = new ScrollPane(messages);
    private final TextArea input = new TextArea();
    private final Button attachBtn = new Button("...");
    private final Button sendBtn = new Button("전송");

    private long lastLoadedMessageId = 0L;
    private Timeline poller;

    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public DialogWindow(Stage owner, int roomId, int meUserId, User peer) {
        this.roomId = roomId;
        this.meUserId = meUserId;
        this.peer = peer;

        setTitle("채팅 - " + peer.getName() + " (" + peer.getLoginId() + ")");
        initOwner(owner);
        initModality(Modality.NONE);

        setMinWidth(600);
        setMinHeight(800);
        setWidth(600);
        setHeight(800);

        BorderPane root = new BorderPane();

        Label header = new Label(peer.getName() + "와의 대화");
        header.getStyleClass().add("header");
        header.setPadding(new Insets(10));
        root.setTop(header);

        messages.setFocusTraversable(false);
        scroller.setFitToWidth(true);
        scroller.setContent(messages);
        root.setCenter(scroller);

        input.setPromptText("메시지를 입력하세요...");
        input.setWrapText(true);
        input.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ENTER && e.isShiftDown()) {
                input.appendText(System.lineSeparator());
            } else if (e.getCode() == KeyCode.ENTER) {
                e.consume();
                sendText();
            }
        });

        attachBtn.setOnAction(e -> pickAndSendImage());
        sendBtn.setDefaultButton(true);
        sendBtn.setOnAction(e -> sendText());

        HBox bottom = new HBox(8, input, attachBtn, sendBtn);
        HBox.setHgrow(input, Priority.ALWAYS);
        bottom.setPadding(new Insets(10));
        root.setBottom(bottom);

        Scene scene = new Scene(root, 720, 560);
        scene.getStylesheets().add("/application/style.css");
        setScene(scene);

        // 최초 로딩 + 폴링
        new Thread(this::loadNewMessages).start();
        poller = new Timeline(new KeyFrame(Duration.seconds(1.5), ev -> new Thread(this::loadNewMessages).start()));
        poller.setCycleCount(Timeline.INDEFINITE);
        poller.play();

        setOnCloseRequest(e -> { if (poller != null) poller.stop(); });
    }

    private void sendText() {
        String txt = input.getText();
        if (txt == null || txt.trim().isEmpty()) return;
        input.clear();
        try (Connection con = Db.get();
             PreparedStatement ps = con.prepareStatement(
                     "INSERT INTO chatting_message(room_id, sender_id, message_type, content, content_type) " +
                             "VALUES (?, ?, 'TEXT', ?, 'TEXT')")) {
            ps.setInt(1, roomId);
            ps.setInt(2, meUserId);
            ps.setString(3, txt.trim());
            ps.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
            Platform.runLater(() -> new Alert(Alert.AlertType.ERROR, "전송 실패\n"+ex.getMessage()).showAndWait());
        }
        new Thread(this::loadNewMessages).start();
    }

    private void pickAndSendImage() {
        FileChooser fc = new FileChooser();
        fc.setTitle("이미지 선택");
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("이미지 파일", "*.png", "*.jpg", "*.jpeg", "*.gif", "*.webp"));
        File f = fc.showOpenDialog(this);
        if (f == null) return;

        try {
            Path uploads = Path.of(System.getProperty("user.home"), "carematch_uploads");
            Files.createDirectories(uploads);
            Path dest = uploads.resolve(System.currentTimeMillis() + "_" + f.getName());
            Files.copy(f.toPath(), dest, StandardCopyOption.REPLACE_EXISTING);

            try (Connection con = Db.get()) {
                long newMsgId = -1;
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO chatting_message(room_id, sender_id, message_type, content, content_type) " +
                                "VALUES (?, ?, 'IMAGE', ?, 'IMAGE')", Statement.RETURN_GENERATED_KEYS)) {
                    ps.setInt(1, roomId);
                    ps.setInt(2, meUserId);
                    ps.setString(3, dest.toString());
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (keys.next()) newMsgId = keys.getLong(1);
                    }
                }
                if (newMsgId > 0) {
                    try (PreparedStatement ps2 = con.prepareStatement(
                            "INSERT INTO chat_image(message_id, file_path, original_name) VALUES (?, ?, ?)")) {
                        ps2.setLong(1, newMsgId);
                        ps2.setString(2, dest.toString());
                        ps2.setString(3, f.getName());
                        ps2.executeUpdate();
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            Platform.runLater(() -> new Alert(Alert.AlertType.ERROR, "이미지 전송 실패\n"+ex.getMessage()).showAndWait());
        }
        new Thread(this::loadNewMessages).start();
    }

    private void loadNewMessages() {
        try (Connection con = Db.get();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT message_id, sender_id, message_type, content, created_at " +
                             "FROM chatting_message WHERE room_id=? AND message_id>? ORDER BY message_id ASC")) {
            ps.setInt(1, roomId);
            ps.setLong(2, lastLoadedMessageId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    long mid = rs.getLong(1);
                    int sender = rs.getInt(2);
                    String type = rs.getString(3);
                    String content = rs.getString(4);
                    Timestamp ts = rs.getTimestamp(5);
                    LocalDateTime when = ts.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();

                    boolean mine = sender == meUserId;
                    if ("IMAGE".equalsIgnoreCase(type)) addImageBubble(content, when, mine);
                    else addTextBubble(content, when, mine);

                    lastLoadedMessageId = mid;
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void addTextBubble(String text, LocalDateTime when, boolean mine) {
        Label bubble = new Label(text);
        bubble.setWrapText(true);
        bubble.setMaxWidth(460);
        bubble.getStyleClass().add(mine ? "bubble-me" : "bubble-peer");
        bubble.setPadding(new Insets(8,10,8,10));

        Label time = new Label(when.format(TS));
        time.getStyleClass().add("timestamp");

        VBox vb = new VBox(2, bubble, time);
        HBox line = new HBox(vb);
        line.setPadding(new Insets(2, 6, 2, 6));
        line.setAlignment(mine ? Pos.CENTER_RIGHT : Pos.CENTER_LEFT);

        Platform.runLater(() -> {
            messages.getChildren().add(line);
            Platform.runLater(() -> scroller.setVvalue(1.0));
        });
    }

    private void addImageBubble(String filepath, LocalDateTime when, boolean mine) {
        ImageView iv;
        try {
            File file = new File(filepath);
            if (file.exists()) {
                Image img = new Image(new FileInputStream(file));
                iv = new ImageView(img);
                iv.setPreserveRatio(true);
                iv.setFitWidth(340);
            } else {
                iv = new ImageView();
                iv.setFitWidth(0);
            }
        } catch (Exception e) {
            iv = new ImageView();
        }

        StackPane bubble = new StackPane(iv);
        bubble.getStyleClass().add(mine ? "bubble-me" : "bubble-peer");
        bubble.setPadding(new Insets(6));

        Label time = new Label(when.format(TS));
        time.getStyleClass().add("timestamp");

        VBox vb = new VBox(2, bubble, time);
        HBox line = new HBox(vb);
        line.setPadding(new Insets(2, 6, 2, 6));
        line.setAlignment(mine ? Pos.CENTER_RIGHT : Pos.CENTER_LEFT);

        Platform.runLater(() -> {
            messages.getChildren().add(line);
            Platform.runLater(() -> scroller.setVvalue(1.0));
        });
    }
}
