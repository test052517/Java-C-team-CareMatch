package talkfxclient.ui;

import javafx.beans.binding.Bindings;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;

/**
 * 빨간 동그라미 숫자 배지 (카톡 스타일).
 * - count == 0 이면 자동으로 보이지 않음(visible/managed=false)
 * - count >= 100 이면 "99+" 로 표시
 */
public class UnreadBadge extends StackPane {

    private final Label text = new Label();
    private final IntegerProperty count = new SimpleIntegerProperty(0);

    public UnreadBadge() {
        getStyleClass().add("unread-badge");
        setPadding(new Insets(0));
        setAlignment(Pos.CENTER);

        text.getStyleClass().add("unread-badge-text");
        getChildren().add(text);

        // 표시 문자열 바인딩
        text.textProperty().bind(Bindings.createStringBinding(() -> {
            int c = count.get();
            if (c <= 0) return "";
            if (c > 99) return "99+";
            return Integer.toString(c);
        }, count));

        // 0이면 감춤
        visibleProperty().bind(count.greaterThan(0));
        managedProperty().bind(visibleProperty());
    }

    public void setCount(int c) {
        count.set(c);
    }

    public int getCount() {
        return count.get();
    }

    public IntegerProperty countProperty() {
        return count;
    }

    /** 외부 IntegerProperty와 바인딩(양방향 아님) */
    public void bind(IntegerProperty source) {
        count.unbind();
        count.bind(source);
    }
}
