package talkfxclient.ui;
import java.io.InputStream;
import java.sql.*; import java.util.Properties;
public final class Db {
  private Db() {}
  public static Connection get() throws Exception {
    try (InputStream in = Db.class.getResourceAsStream("/db.properties")) {
      if (in == null) throw new RuntimeException("db.properties not found on classpath");
      Properties p = new Properties(); p.load(in);
      return DriverManager.getConnection(p.getProperty("url"), p.getProperty("user"), p.getProperty("password"));
    }
  }
  public static String currentUserRole(int userId) throws Exception {
    try (Connection con=get(); PreparedStatement ps=con.prepareStatement("SELECT role FROM users WHERE user_id=?")) {
      ps.setInt(1, userId); try (ResultSet rs=ps.executeQuery()) { if (rs.next()) return rs.getString(1); }
    } return null;
  }
  public static void markAllRead(int roomId, int myUserId) {
    try (Connection con=get(); PreparedStatement ps = con.prepareStatement(
      "UPDATE chatting_message SET read_at=NOW() WHERE room_id=? AND sender_id<>? AND read_at IS NULL")) {
      ps.setInt(1, roomId); ps.setInt(2, myUserId); ps.executeUpdate();
    } catch (Exception ignore) {}
  }
}
