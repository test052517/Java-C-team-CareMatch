package talkfxclient.ui;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;
import talkfxclient.bridge.ChatBackend;
import talkfxclient.model.User;

import java.net.URL;
import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** 대화 목록 (카톡 스타일 미읽음 배지 포함, room_type 칼럼 없이 동작) */
public class ChatListWindow extends Stage {
    private final ChatBackend backend;
    private User me;

    private final ListView<User> listView = new ListView<>();
    private final Button openBtn = new Button("대화 시작하기");

    // ====== 미읽음 카운터 관리 ======
    private final Map<Integer, javafx.beans.property.IntegerProperty> unread = new ConcurrentHashMap<>();
    private Timeline poller;

    public ChatListWindow(ChatBackend backend, User me) {
        this.backend = backend;
        this.me = me;

        setTitle("대화 목록");
        initModality(Modality.NONE);

        BorderPane root = new BorderPane();
        root.getStyleClass().add("chatlist-root");

        Label title = new Label("대화 목록");
        title.getStyleClass().add("title");
        HBox header = new HBox(title);
        header.getStyleClass().add("header-bar");
        header.setAlignment(Pos.CENTER);
        header.setPadding(new Insets(10, 0, 10, 0));
        root.setTop(header);

        listView.setFixedCellSize(44);
        listView.setFocusTraversable(false);
        listView.setPadding(new Insets(12));

        // ====== 셀 구성: 이름 + 배지 ======
        listView.setCellFactory(v -> new ListCell<>() {
            final Label title = new Label();
            final Region spacer = new Region();
            final UnreadBadge badge = new UnreadBadge();
            final HBox rootCell = new HBox(8, title, spacer, badge);
            {
                HBox.setHgrow(spacer, Priority.ALWAYS);
                setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
                title.setFont(Font.font("Malgun Gothic", FontWeight.BOLD, 16));
                title.setPadding(new Insets(6, 12, 6, 12));
            }
            @Override protected void updateItem(User item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setGraphic(null);
                } else {
                    title.setText("ADMIN".equalsIgnoreCase(item.getRole()) ? "관리자" : item.getLoginId());
                    badge.bind(counterFor(item.getUserId()));
                    setGraphic(rootCell);
                }
            }
        });

        listView.setOnMouseClicked(e -> {
            if (e.getButton() == MouseButton.PRIMARY && e.getClickCount() == 2) openSelected();
        });
        root.setCenter(listView);

        openBtn.getStyleClass().add("brown-btn");
        openBtn.setDefaultButton(true);
        openBtn.setOnAction(e -> openSelected());
        openBtn.disableProperty().bind(listView.getSelectionModel().selectedItemProperty().isNull());
        HBox bottom = new HBox(openBtn);
        bottom.setAlignment(Pos.CENTER_RIGHT);
        bottom.setPadding(new Insets(10, 12, 10, 12));
        root.setBottom(bottom);

        Scene scene = new Scene(root, 420, 620);
        addCss(scene);
        setScene(scene);

        // 데이터 로드 + 폴링 시작
        new Thread(this::loadMeAndPeers).start();
        startPollingUnread();
        setOnCloseRequest(e -> { if (poller != null) poller.stop(); });
    }

    /** /application/style.css 없으면 /talkfxclient/ui/badge.css도 함께 붙임 */
    private static void addCss(Scene scene) {
        String[] candidates = { "/application/style.css" };
        for (String p : candidates) {
            URL u = ChatListWindow.class.getResource(p);
            if (u != null) { scene.getStylesheets().add(u.toExternalForm()); break; }
        }
        URL badge = ChatListWindow.class.getResource("/talkfxclient/ui/badge.css");
        if (badge != null) scene.getStylesheets().add(badge.toExternalForm());
    }

    private void openSelected() {
        User peer = listView.getSelectionModel().getSelectedItem();
        if (peer == null) {
            new Alert(Alert.AlertType.INFORMATION, "대상을 선택하세요.").showAndWait();
            return;
        }
        int roomId = ensureDmRoom(me.getUserId(), peer.getUserId());
        if (roomId <= 0) {
            new Alert(Alert.AlertType.ERROR, "대화방 생성/조회 실패").showAndWait();
            return;
        }
        ChatWindow win = new ChatWindow(this, backend, roomId, me, peer);
        win.show();
    }

    private void loadMeAndPeers() {
        try (Connection con = Db.get()) {
            // 사용자 정보 보정
            if (me == null || me.getLoginId() == null || me.getLoginId().isEmpty() || me.getRole() == null) {
                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT user_id, login_id, name, role FROM users WHERE user_id=?")) {
                    ps.setInt(1, me.getUserId());
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            User fixed = new User(rs.getInt("user_id"),
                                    rs.getString("login_id"),
                                    rs.getString("name"),
                                    rs.getString("role"));
                            me = fixed;
                        }
                    }
                }
            }

            List<User> peers = new ArrayList<>();
            if ("USER".equalsIgnoreCase(me.getRole())) {
                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT user_id, login_id, name, role FROM users WHERE role='ADMIN' ORDER BY user_id");
                     ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) peers.add(new User(
                            rs.getInt("user_id"),
                            rs.getString("login_id"),
                            rs.getString("name"),
                            rs.getString("role")
                    ));
                }
            } else {
                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT user_id, login_id, name, role FROM users WHERE role='USER' ORDER BY user_id");
                     ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) peers.add(new User(
                            rs.getInt("user_id"),
                            rs.getString("login_id"),
                            rs.getString("name"),
                            rs.getString("role")
                    ));
                }
            }

            Platform.runLater(() -> listView.getItems().setAll(peers));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // ====== 미읽음 카운터 ======

    private javafx.beans.property.IntegerProperty counterFor(int peerId) {
        return unread.computeIfAbsent(peerId, k -> new javafx.beans.property.SimpleIntegerProperty(0));
    }

    private void startPollingUnread() {
        poller = new Timeline(new KeyFrame(Duration.seconds(1.0), ev -> new Thread(this::refreshUnreadAll).start()));
        poller.setCycleCount(Timeline.INDEFINITE);
        poller.play();
    }

    private void refreshUnreadAll() {
        if (me == null) return;
        List<User> peers = new ArrayList<>(listView.getItems());
        if (peers.isEmpty()) return;
        try (Connection con = Db.get()) {
            for (User p : peers) {
                int cnt = queryUnreadCount(con, me.getUserId(), p.getUserId());
                final int peerId = p.getUserId();
                Platform.runLater(() -> counterFor(peerId).set(cnt));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * room_type 컬럼이 없어도 동작하도록, "같은 방 멤버" 기준으로 미읽음을 계산
     * (1:1만 쓰는 현재 구조에서는 정확 / 그룹방이 있다면 해당 방도 합산될 수 있음)
     */
    private static int queryUnreadCount(Connection con, int meId, int peerId) throws SQLException {
        String sql =
                "SELECT COUNT(*) " +
                "FROM chatting_message cm " +
                "JOIN chatting_room_member mine ON mine.room_id = cm.room_id AND mine.user_id = ? " +
                "JOIN chatting_room_member peer ON peer.room_id = cm.room_id AND peer.user_id = ? " +
                "WHERE cm.sender_id = ? AND cm.read_at IS NULL";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, meId);
            ps.setInt(2, peerId);
            ps.setInt(3, peerId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
                return 0;
            }
        }
    }

    private static boolean hasColumn(Connection con, String table, String column) throws SQLException {
        try (ResultSet rs = con.getMetaData().getColumns(con.getCatalog(), null, table, column)) {
            return rs.next();
        }
    }

    private int ensureDmRoom(int meId, int otherId) {
        String findSql = "SELECT r.room_id " +
                "FROM chatting_room r " +
                "JOIN chatting_room_member m1 ON r.room_id=m1.room_id AND m1.user_id=? " +
                "JOIN chatting_room_member m2 ON r.room_id=m2.room_id AND m2.user_id=? " +
                "ORDER BY r.room_id LIMIT 1";
        try (Connection con = Db.get()) {
            try (PreparedStatement ps = con.prepareStatement(findSql)) {
                ps.setInt(1, meId);
                ps.setInt(2, otherId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return rs.getInt(1);
                }
            }
            // 없으면 생성 (room_type 없어도 동작)
            boolean hasRoomType = hasColumn(con, "chatting_room", "room_type");
            int newRoomId = -1;
            String insert = hasRoomType
                    ? "INSERT INTO chatting_room(room_type) VALUES ('DM')"
                    : "INSERT INTO chatting_room() VALUES ()";
            try (PreparedStatement ps = con.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS)) {
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) newRoomId = keys.getInt(1);
                }
            }
            if (newRoomId <= 0) return -1;
            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO chatting_room_member(room_id, user_id) VALUES(?, ?), (?, ?)")) {
                ps.setInt(1, newRoomId);
                ps.setInt(2, meId);
                ps.setInt(3, newRoomId);
                ps.setInt(4, otherId);
                ps.executeUpdate();
            }
            return newRoomId;
        } catch (Exception ex) {
            ex.printStackTrace();
            return -1;
        }
    }
}
