package talkfxclient.ui;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;

import talkfxclient.bridge.ChatBackend;
import talkfxclient.model.User;

import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ChatWindow – 읽음(1) 표시 + 고정 프레임 이미지 + 스크롤 자동 하단.
 * DB 칼럼: chatting_message.read_at TIMESTAMP NULL
 */
public class ChatWindow extends Stage {

    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("a h:mm", Locale.KOREA);
    private static final double MAX_IMG_W = 360;
    private static final double MAX_IMG_H = 360;

    private final ChatBackend backend;
    private final int roomId;
    private final User me;
    private final User peer;

    private final VBox messages = new VBox(0);
    private final ScrollPane scroller = new ScrollPane(messages);
    private final TextArea input = new TextArea();
    private final Button attachBtn = new Button("사진");
    private final Button sendBtn = new Button("전송");

    // 내 메시지의 읽음 뱃지: message_id -> Label
    private final Map<Long, Label> myBadges = new ConcurrentHashMap<>();
    private long lastLoadedMessageId = 0L;
    private Timeline poller;

    public ChatWindow(Stage owner, ChatBackend backend, int roomId, User me, User peer) {
        this.backend = backend;
        this.roomId = roomId;
        this.me = me;
        this.peer = peer;

        String titleText;
        if (peer.getRole() != null && "ADMIN".equalsIgnoreCase(peer.getRole())) {
            titleText = "관리자";
        } else {
            titleText = (peer.getLoginId() != null ? peer.getLoginId() : "대화");
        }
        setTitle(titleText);
        initModality(Modality.NONE);

        // 목록(대화) 영역 스타일
        messages.setPadding(Insets.EMPTY);
        messages.setSpacing(0);

        scroller.setFitToWidth(true);
        scroller.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroller.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);

        // 입력 영역
        input.setPromptText("메시지를 입력하세요...");
        input.setWrapText(true);
        input.setPrefRowCount(2);

        attachBtn.getStyleClass().add("brown-btn");
        sendBtn.getStyleClass().add("brown-btn");
        sendBtn.setOnAction(e -> doSendText());
        attachBtn.setOnAction(e -> doAttachImage());

        // Enter = 전송, Shift+Enter = 줄바꿈
        input.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ENTER && !e.isShiftDown()) {
                e.consume();
                doSendText();
            }
        });

        HBox bottomBar = new HBox(10, attachBtn, input, sendBtn);
        bottomBar.setAlignment(Pos.CENTER_RIGHT);
        HBox.setHgrow(input, Priority.ALWAYS);
        bottomBar.setPadding(new Insets(10));
        bottomBar.getStyleClass().add("footer-bar");
        input.getStyleClass().add("send-box");

        Label title = new Label(titleText);
        title.getStyleClass().add("title");
        HBox header = new HBox(title);
        header.getStyleClass().add("header-bar");
        header.setAlignment(Pos.CENTER);
        header.setPadding(new Insets(8, 0, 8, 0));

        BorderPane root = new BorderPane(scroller, header, null, bottomBar, null);
        root.getStyleClass().add("dialog-root");

        Scene scene = new Scene(root, 600, 800);
        addCss(scene);
        setScene(scene);

        // 폴링 주기 0.5초
        poller = new Timeline(new KeyFrame(Duration.seconds(0.5), ev -> {
            new Thread(this::loadNewMessages).start();
            new Thread(this::refreshReadBadges).start();
        }));
        poller.setCycleCount(Timeline.INDEFINITE);
        poller.play();

        setOnShown(e -> autoScrollBottom());
        setOnCloseRequest(e -> { if (poller != null) poller.stop(); });
    }

    private static void addCss(Scene scene) {
        String[] candidates = { "/application/style.css", "/talkfxclient/ui/style.css" };
        for (String p : candidates) {
            URL u = ChatWindow.class.getResource(p);
            if (u != null) { scene.getStylesheets().add(u.toExternalForm()); return; }
        }
    }

    /** 레이아웃이 늦게 반영될 때를 대비해 2회 지연으로 확실히 바닥 고정 */
    private void autoScrollBottom() {
        Platform.runLater(() -> {
            Runnable scrollFn = () -> {
                scroller.layout();
                scroller.setVvalue(1.0);
                scroller.setVvalue(scroller.getVmax());
            };
            scrollFn.run(); // 즉시 1회
            PauseTransition p1 = new PauseTransition(Duration.millis(16));
            p1.setOnFinished(e -> scrollFn.run());
            PauseTransition p2 = new PauseTransition(Duration.millis(60));
            p2.setOnFinished(e -> scrollFn.run());
            p1.play();
            p2.play();
        });
    }

    /* --------------- 전송 --------------- */
    private void doSendText() {
        String text = input.getText();
        if (text == null) return;
        String trimmed = text.trim();
        if (trimmed.isEmpty()) return;

        try {
            backend.sendText(roomId, me, trimmed);
        } catch (Exception ex) {
            ex.printStackTrace();
            try { insertTextDirect(trimmed); } catch (Exception ignored) {}
        } finally {
            input.clear();
            new Thread(this::loadNewMessages).start();
            autoScrollBottom(); // 전송 직후 하단 고정
        }
    }

    private void doAttachImage() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("이미지 선택");
        chooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Images", "*.png", "*.jpg", "*.jpeg", "*.gif"));
        File f = chooser.showOpenDialog(this);
        if (f == null) return;

        try {
            backend.sendImage(roomId, me, f);
        } catch (Exception ex) {
            ex.printStackTrace();
            try { insertImageDirect(f); } catch (Exception ignored) {}
        } finally {
            new Thread(this::loadNewMessages).start();
            autoScrollBottom(); // 첨부 후에도 하단 고정
        }
    }

    private void insertTextDirect(String text) throws Exception {
        try (Connection con = Db.get();
             PreparedStatement ps = con.prepareStatement(
                     "INSERT INTO chatting_message(room_id, sender_id, content, content_type) VALUES(?,?,?, 'TEXT')",
                     Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, roomId);
            ps.setInt(2, me.getUserId());
            ps.setString(3, text);
            ps.executeUpdate();
        }
    }

    private void insertImageDirect(File f) throws Exception {
        try (Connection con = Db.get()) {
            con.setAutoCommit(false);
            long mid = -1L;

            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO chatting_message(room_id, sender_id, content, content_type) VALUES(?,?,?, 'IMAGE')",
                    Statement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, roomId);
                ps.setInt(2, me.getUserId());
                ps.setString(3, f.getAbsolutePath());
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) mid = keys.getLong(1);
                }
            }
            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO chat_image(message_id, file_path, original_name, size_bytes) VALUES(?,?,?,?)")) {
                ps.setLong(1, mid);
                ps.setString(2, f.getAbsolutePath());
                ps.setString(3, f.getName());
                ps.setLong(4, f.length());
                ps.executeUpdate();
            }
            con.commit();
        }
    }

    /* --------------- 폴링 로딩 --------------- */
    private void loadNewMessages() {
        try (Connection con = Db.get();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT message_id, sender_id, content, content_type, created_at, read_at " +
                             "FROM chatting_message WHERE room_id=? AND message_id>? ORDER BY message_id ASC")) {
            ps.setInt(1, roomId);
            ps.setLong(2, lastLoadedMessageId);
            boolean added = false;
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    long mid = rs.getLong(1);
                    int sender = rs.getInt(2);
                    String content = rs.getString(3);
                    String ctype = rs.getString(4);
                    Timestamp ts = rs.getTimestamp(5);
                    Timestamp readAt = null;
                    try { readAt = rs.getTimestamp(6); } catch (Throwable ignore) { /* read_at 없음 처리 */ }

                    LocalDateTime when = ts.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
                    boolean mine = sender == me.getUserId();

                    if ("IMAGE".equalsIgnoreCase(ctype)) addImageBubble(mid, content, when, mine, readAt);
                    else addTextBubble(mid, content, when, mine, readAt);

                    lastLoadedMessageId = Math.max(lastLoadedMessageId, mid);
                    added = true;
                }
            }
            if (added) {
                autoScrollBottom();
                markAllRead(); // 상대방 메시지 읽음 처리
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /** 내 창에서 상대가 보낸 메시지를 읽음 처리 */
    private void markAllRead() {
        try (Connection con = Db.get();
             PreparedStatement ps = con.prepareStatement(
                     "UPDATE chatting_message SET read_at=NOW() WHERE room_id=? AND sender_id<>? AND read_at IS NULL")) {
            ps.setInt(1, roomId);
            ps.setInt(2, me.getUserId());
            ps.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /** 내 쪽에서 보낸 메시지들의 읽음 뱃지를 주기적으로 비움 */
    private void refreshReadBadges() {
        try (Connection con = Db.get();
             PreparedStatement ps = con.prepareStatement(
                 "SELECT message_id FROM chatting_message WHERE room_id=? AND sender_id=? AND read_at IS NOT NULL")) {
            ps.setInt(1, roomId);
            ps.setInt(2, me.getUserId());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    long mid = rs.getLong(1);
                    Label badge = myBadges.get(mid);
                    if (badge != null) {
                        Platform.runLater(() -> badge.setText(""));
                    }
                }
            }
        } catch (Exception ignore) { }
    }

    /* --------------- 버블 --------------- */
    private void addTextBubble(long mid, String text, LocalDateTime when, boolean mine, Timestamp readAt) {
        Label bubble = new Label(text);
        bubble.setWrapText(true);
        bubble.setMaxWidth(460);
        bubble.getStyleClass().addAll("bubble", mine ? "bubble-me" : "bubble-peer");
        bubble.setFont(Font.font("Malgun Gothic", FontWeight.NORMAL, 14));

        Label time = new Label(TS.format(when));
        time.getStyleClass().add("bubble-time");

        Label badge = new Label(mine && readAt == null ? "1" : "");
        badge.getStyleClass().add("read-badge");
        if (mine) myBadges.put(mid, badge);

        VBox meta = new VBox(badge, time);
        meta.setAlignment(Pos.CENTER_RIGHT);

        HBox row = new HBox(8);
        row.setPadding(Insets.EMPTY);
        row.setFillHeight(true);
        if (mine) {
            row.setAlignment(Pos.CENTER_RIGHT);
            row.getChildren().addAll(meta, bubble);
        } else {
            row.setAlignment(Pos.CENTER_LEFT);
            row.getChildren().addAll(bubble, meta);
        }
        Platform.runLater(() -> { 
            messages.getChildren().add(row);
            autoScrollBottom();
        });
    }

    private void addImageBubble(long mid, String path, LocalDateTime when, boolean mine, Timestamp readAt) {
        Image img;
        try {
            img = new Image(new FileInputStream(path));
        } catch (Exception e) {
            addTextBubble(mid, "[이미지] " + path, when, mine, readAt);
            return;
        }
        ImageView iv = new ImageView(img);
        iv.setPreserveRatio(true);
        double scale = 1.0;
        if (img.getWidth() > 0 && img.getHeight() > 0) {
            scale = Math.min(MAX_IMG_W / img.getWidth(), MAX_IMG_H / img.getHeight());
            if (scale > 1.0) scale = 1.0;
        }
        iv.setFitWidth(img.getWidth() * scale);

        VBox box = new VBox(iv);
        box.getStyleClass().addAll("bubble", "image-frame", mine ? "bubble-me" : "bubble-peer");
        box.setPadding(new Insets(6));

        Label time = new Label(TS.format(when));
        time.getStyleClass().add("bubble-time");

        Label badge = new Label(mine && readAt == null ? "1" : "");
        badge.getStyleClass().add("read-badge");
        if (mine) myBadges.put(mid, badge);

        VBox meta = new VBox(badge, time);
        meta.setAlignment(Pos.CENTER_RIGHT);

        HBox row = new HBox(8);
        row.setPadding(Insets.EMPTY);
        row.setFillHeight(true);
        if (mine) {
            row.setAlignment(Pos.CENTER_RIGHT);
            row.getChildren().addAll(meta, box);
        } else {
            row.setAlignment(Pos.CENTER_LEFT);
            row.getChildren().addAll(box, meta);
        }
        Platform.runLater(() -> { 
            messages.getChildren().add(row);
            autoScrollBottom();
        });
    }
}
