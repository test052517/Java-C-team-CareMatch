package talkfxclient.bridge;

import talkfxclient.model.User;

import java.io.File;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/**
 * 레거시 소켓 서버로 알림을 날리고,
 * 동시에 DB에도 즉시 기록(JdbcBackend)하여
 * 클라이언트 폴링(UI)이 바로 반영되도록 보장한다.
 */
public class LegacySocketBackend implements ChatBackend {

    private final String host;
    private final int port;
    private final JdbcBackend jdbc = new JdbcBackend();

    public LegacySocketBackend(String host, int port) {
        this.host = host;
        this.port = port;
    }

    private void sendLine(String line) throws Exception {
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(host, port), 1000);
            s.setSoTimeout(1000);
            OutputStream os = s.getOutputStream();
            os.write((line + "\n").getBytes(StandardCharsets.UTF_8));
            os.flush();
        }
    }

    @Override
    public void sendText(int roomId, User from, String text) throws Exception {
        // 1) 서버에 푸시(있으면 실시간 알림)
        try {
            String safe = text.replace("\n", "\\n");
            String line = "SEND_TEXT|" + roomId + "|" + from.getUserId() + "|" + safe;
            System.out.println("[SOCKET] -> " + host + ":" + port + " : " + line);
            sendLine(line);
        } catch (Throwable t) {
            System.err.println("[SOCKET] sendText error: " + t);
        }
        // 2) 항상 DB에도 기록 (UI 폴링이 즉시 보게끔)
        jdbc.sendText(roomId, from, text);
    }

    @Override
    public void sendImage(int roomId, User from, File file) throws Exception {
        try {
            String line = "SEND_IMAGE|" + roomId + "|" + from.getUserId() + "|" + file.getName() + "|" + file.length();
            System.out.println("[SOCKET] -> " + host + ":" + port + " : " + line);
            sendLine(line);
        } catch (Throwable t) {
            System.err.println("[SOCKET] sendImage error: " + t);
        }
        jdbc.sendImage(roomId, from, file);
    }
}