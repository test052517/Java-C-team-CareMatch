package talkfxclient.model;

public class User {
    private final int userId;
    private final String loginId;
    private final String name;
    private final String role;

    public User(int userId, String loginId, String name, String role) {
        this.userId = userId;
        this.loginId = loginId;
        this.name = name;
        this.role = role;
    }
    public int getUserId() { return userId; }
    public String getLoginId() { return loginId; }
    public String getName() { return name; }
    public String getRole() { return role; }
}
