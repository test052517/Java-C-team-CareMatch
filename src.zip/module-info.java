module CareMatch {
	requires javafx.controls;
	requires javafx.graphics;
	requires java.sql;
	requires java.desktop;
	
    requires java.mail;        // javax.mail-1.6.2.jar
    requires java.activation;

    
    
	opens application to javafx.graphics, javafx.fxml;
}
